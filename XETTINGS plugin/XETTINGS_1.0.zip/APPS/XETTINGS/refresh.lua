pad = Pads.get()
Screen.clear()
if backgroundFilter then
    Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
else
    Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
end
thmDrawBKG()
DrawInterface(actualCat,actualOption,true)
if System.doesFileExist("XEBPLUS.ELF") then
    ElfToLaunch = "XEBPLUS.ELF"
elseif System.doesFileExist("XEBPLUS_XMAS.ELF") then
    ElfToLaunch = "XEBPLUS_XMAS.ELF"
end
if System.doesFileExist("mass:/XEBPLUS/XEBPLUS.ELF") then
    ElfToLaunch = "mass:/XEBPLUS/XEBPLUS.ELF"
elseif System.doesFileExist("mass:/XEBPLUS/XEBPLUS_XMAS.ELF") then
    ElfToLaunch = "mass:/XEBPLUS/XEBPLUS_XMAS.ELF"
end
if System.doesFileExist("mass:/PS2/XEBPLUS/XEBPLUS.ELF") then
    ElfToLaunch = "mass:/PS2/XEBPLUS/XEBPLUS.ELF"
elseif System.doesFileExist("mass:/PS2/XEBPLUS/XEBPLUS_XMAS.ELF") then
    ElfToLaunch = "mass:/PS2/XEBPLUS/XEBPLUS_XMAS.ELF"
end
for WaveByeBye = 1, 25 do
    Screen.clear()
    if backgroundFilter then
        Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
    else
        Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
    end
    thmDrawBKG()
    DrawInterface(actualCat,actualOption,true)
    spinDisc()
    thmDrawBKGOL()
    Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,WaveByeBye*10))
    Screen.waitVblankStart()
    Screen.flip()
end
LaunchELF(ElfToLaunch, 0, "Default", false, 1)
spinDisc()
thmDrawBKGOL()
Screen.waitVblankStart()
oldpad = pad;
Screen.flip()