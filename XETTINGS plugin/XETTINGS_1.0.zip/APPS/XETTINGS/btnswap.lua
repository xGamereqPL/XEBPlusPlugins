XEBKeepInApp=true
TransparencyAlpha=0
TempX=840
TempY=32
ContextMenu_AllItems=2
if buttonSettings == "X" then
    ContextMenu_SelectedItem = 2
end
if buttonSettings == "O" then
    ContextMenu_SelectedItem = 1
end
ContextMenu={};
ContextMenu[1] = {};
ContextMenu[1].Name = xebLang[117]
ContextMenu[2] = {};
ContextMenu[2].Name = xebLang[118]

while XEBKeepInApp do
    pad = Pads.get()
    Screen.clear()
    if backgroundFilter then
        Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
    else
        Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
    end
    thmDrawBKG()
    DrawInterface(actualCat,actualOption,true)
    spinDisc()
    thmDrawBKGOL()
    Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, TransparencyAlpha)
    ----------------------------------------------------------------------------
    if TempX >= 540 then
        TempX = TempX - 20
    end
    if TempX < 540 then
        TempX=540
    end
    if TransparencyAlpha <= 255 then
        TransparencyAlpha = TransparencyAlpha + 25
    end
    Graphics.drawImageExtended(themeInUse[-5], TempX, 240, 0, 0, 325, 480, 325, 480, 0, 255)
    TempY=16+ContextMenu_SelectedItem*28
    Graphics.drawImageExtended(themeInUse[-4], TempX, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
    for ItemToDraw = 1,ContextMenu_AllItems do
        TempY=8+ItemToDraw*28
        Font.ftPrint(fontXET, TempX-144, plusYValue+TempY, 0, 512, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
    end
    if ContextMenu_SelectedItem == 2 then
        textToPrint=xetLang[8]
    end
    if ContextMenu_SelectedItem == 1 then
        textToPrint=xetLang[9]
    end
    Font.ftPrint(fontSmall, TempX-144, plusYValue+360, 0, 512, 64, textToPrint, Color.new(255,255,255,255))
    ----------------------------------------------------------------------------
    if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
        XEBKeepInApp=getOut
    end
    if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
        if ContextMenu_SelectedItem == 2 then
            buttonSettings="X"
            XEBBTNACCEPT="¶"
            PAD_ACCEPT=PAD_CROSS
            XEBBTNCANCEL="¬"
            PAD_CANCEL=PAD_CIRCLE
            XEBBTNSUBMEN="¨"
            PAD_SUBMEN=PAD_TRIANGLE
            XEBBTNEXTRAS="¯"
            PAD_EXTRAS=PAD_SQUARE
        elseif ContextMenu_SelectedItem == 1 then
            buttonSettings="O"
            XEBBTNACCEPT="¬"
            PAD_ACCEPT=PAD_CIRCLE
            XEBBTNCANCEL="¶"
            PAD_CANCEL=PAD_CROSS
            XEBBTNSUBMEN="¨"
            PAD_SUBMEN=PAD_TRIANGLE
            XEBBTNEXTRAS="¯"
            PAD_EXTRAS=PAD_SQUARE
        end
        XEBKeepInApp=getOut
    end
    if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
        ContextMenu_SelectedItem = ContextMenu_SelectedItem - 1
        if ContextMenu_SelectedItem < 1 then
            ContextMenu_SelectedItem = ContextMenu_AllItems
        end
    end
    if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
        ContextMenu_SelectedItem = ContextMenu_SelectedItem + 1
        if ContextMenu_SelectedItem > ContextMenu_AllItems then
            ContextMenu_SelectedItem = 1
        end
    end
    Screen.waitVblankStart()
    oldpad = pad;
    Screen.flip()
end
while XEBKeepInApp == getOut do
    pad = Pads.get()
    Screen.clear()
    if backgroundFilter then
        Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
    else
        Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
    end
    thmDrawBKG()
    DrawInterface(actualCat,actualOption,true)
    spinDisc()
    thmDrawBKGOL()
    Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, TransparencyAlpha)
    if TempX <= 840 then
        TempX = TempX + 25
    end
    if TempX >= 840 then
        XEBKeepInApp = false
    end
    if TransparencyAlpha >= 0 then
        TransparencyAlpha = TransparencyAlpha - 32
    end
    if TransparencyAlpha <= 0 then
        TransparencyAlpha = 0
    end
    Graphics.drawImageExtended(themeInUse[-5], TempX, 240, 0, 0, 325, 480, 325, 480, 0, 255)
    TempY=16+ContextMenu_SelectedItem*28
    Graphics.drawImageExtended(themeInUse[-4], TempX, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
    for ItemToDraw = 1,ContextMenu_AllItems do
        TempY=8+ItemToDraw*28
        Font.ftPrint(fontXET, TempX-144, plusYValue+TempY, 0, 512, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
    end
    textToPrint=xetLang[10]
    Font.ftPrint(fontSmall, TempX-144, plusYValue+360, 0, 512, 64, textToPrint, Color.new(255,255,255,255))
    Screen.waitVblankStart()
    oldpad = pad;
    Screen.flip()
end
pad = Pads.get()
Screen.clear()
if backgroundFilter then
    Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
else
    Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
end
thmDrawBKG()
DrawInterface(actualCat,actualOption,true)
spinDisc()
thmDrawBKGOL()
oldpad = pad;

if childproofMode == false then
    childproofText = "false"
elseif childproofMode == true then
    childproofText = "true"
end
if useAMPM == true then
    useAMPMtext = "true"
elseif useAMPM == false then
    useAMPMtext = "false"
end
if monthsBefore == true then
    monthsBeforeText = "true"
elseif monthsBefore == false then
    monthsBeforeText = "false"
end
if XEBPlusLanguageEmulation == true then
    XEBPlusLangText = "true"
elseif XEBPlusLanguageEmulation == false then
    XEBPlusLangText = "false"
end

TextToSave = "--Theme folder's name\nXEBPlusTheme=\""..XEBPlusTheme.."\"\n--\"NTSC\" or \"PAL\"\nXEBVideoMode=\""..XEBVideoMode.."\"\n--\"X\" or \"O\"\nbuttonSettings=\""..buttonSettings.."\"\n--Enable Language Emulation (this setting is exclusive for the Xmas build, in the release build it will be enabled by default thanks to XEB+'s bootloader)\nXEBPlusLanguageEmulation="..XEBPlusLangText.."\n--0JP, 1EN, 2FR, 3ES, 4DE, 5IT, 6DU, 7PT\nsystemLanguage="..systemLanguage.."\n--true or false\nchildproofMode="..childproofText.."\n--2 for new mode, 1 for the classic one, 3 for forced ps2logo (modchips), 4 for smart ps2logo + cdfs, 5 for smart ps2logo + cdrom0\nlaunchPS2CDVD="..launchPS2CDVD.."\n--months before (true) or after days (false)\nmonthsBefore="..monthsBeforeText.."\n--use AM PM or not\nuseAMPM="..useAMPMtext.."\n--0 NoIOPReset / 1 NoUSB-ROM0 / 2 NoUSB-HB / 3 BDMUSB-ROM0 / 4 BDMUSB-HB / 5 2019USB-HB / 6 2019USB-ROM0 / 7 LegacyUSB-ROM0 / 8 LegacyUSB-HB / 9 ExternalUSB-ROM0 / 10 ExternalUSB-HB\ndefaultIOPResetMethod="..defaultIOPResetMethod.."\n                "
xebConfFile=System.openFile("CFG/xebplus.cfg", FCREATE)
System.removeFile(xebConfFile)
System.writeFile(xebConfFile, TextToSave, string.len(TextToSave))
System.closeFile(xebConfFile)