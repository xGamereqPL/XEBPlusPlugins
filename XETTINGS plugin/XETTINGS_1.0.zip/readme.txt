XETTINGS (1.0)

- What is this?
XETTINGS is a plugin for XtremeEliteBoot+. Allows you to change XEB+ settings directly from the dashboard. This feature has been removed from the Xmas Showcase, but you can bring it back with this plugin.

- How to install it?
Extract content of XETTINGS_1.0.zip in the XEBPLUS folder.

- Warning:
Use this plugin only with XEB+ Xmas Showcase.
Do not use this plugin if you run XEB+ from host:/ (PCSX2), it will corrupt the CFG file.

- Credits:
Plugin coded by: xGamer
Translations by: ChelseaFantasy (Spanish), MayconTp (Portuguese)