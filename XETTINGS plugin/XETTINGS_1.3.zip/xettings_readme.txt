XETTINGS (1.3 - 16.03.2025)

- What is this?
XETTINGS is a plugin for XtremeEliteBoot+. Allows you to change XEB+ settings directly from the dashboard. This feature has been removed from the Xmas Showcase, but you can bring it back with this plugin. You also can change XtremeBootloader settings (USB Drivers) that cannot be changed in xebplus.cfg. This plugin also adds some custom features, like more date formats.

- How to install it?
Extract content of XETTINGS_1.3.zip in the XEBPLUS folder.

- Warnings:
Use this plugin only with XEB+ Xmas Showcase.
Do not use this plugin if you run XEB+ from host:/ (PCSX2), it will corrupt the CFG file.
Exit to Browser only works on some console models (I can confirm it works on SCPH-50004 - ROMVER 1.70)
After changing the USB Drivers, the options saves to mc?:/BOOT/XBL.CNF or mc?:/SYS-CONF/XBL.CNF (only if the BOOT or SYS-CONF folder exists). In case of problems after changing the drivers, delete this file.

- Credits:
Plugin created by: xGamereqPL
Spanish translations: Howling Wolf & Chelsea, P4NCHOL1NO
Portuguese translations: MayconTp, nuno6573