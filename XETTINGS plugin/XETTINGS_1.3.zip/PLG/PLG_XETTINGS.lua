-- XETTINGS 1.3 by xGamereqPL
-- This plugin is written for XEB+ Xmas Showcase, these features may not work in the full version.
-- DO NOT use this plugin with the full version of XEB+.

-- save XEB+ configuration
function saveXEBCNF()
    if childproofMode == false then
        childproofText = "false"
    elseif childproofMode == true then
        childproofText = "true"
    end
    if useAMPM == true then
        useAMPMtext = "true"
    elseif useAMPM == false then
        useAMPMtext = "false"
    end
    if monthsBefore == true then
        monthsBeforeText = "true"
    elseif monthsBefore == false then
        monthsBeforeText = "false"
    end
    if XEBPlusLanguageEmulation == true then
        XEBPlusLangText = "true"
    elseif XEBPlusLanguageEmulation == false then
        XEBPlusLangText = "false"
    end
    System.removeFile("CFG/xebplus.cfg")
    TextToSave = "--Theme folder's name\nXEBPlusTheme=\""..XEBPlusTheme.."\"\n--\"NTSC\" or \"PAL\"\nXEBVideoMode=\""..XEBVideoMode.."\"\n--\"X\" or \"O\"\nbuttonSettings=\""..buttonSettings.."\"\n--Enable Language Emulation (this setting is exclusive for the Xmas build, in the release build it will be enabled by default thanks to XEB+'s bootloader)\nXEBPlusLanguageEmulation="..XEBPlusLangText.."\n--0JP, 1EN, 2FR, 3ES, 4DE, 5IT, 6DU, 7PT\nsystemLanguage="..systemLanguage.."\n--true or false\nchildproofMode="..childproofText.."\n--2 for new mode, 1 for the classic one, 3 for forced ps2logo (modchips), 4 for smart ps2logo + cdfs, 5 for smart ps2logo + cdrom0\nlaunchPS2CDVD="..launchPS2CDVD.."\n--months before (true) or after days (false)\nmonthsBefore="..monthsBeforeText.."\n--use AM PM or not\nuseAMPM="..useAMPMtext.."\n--0 NoIOPReset / 1 NoUSB-ROM0 / 2 NoUSB-HB / 3 BDMUSB-ROM0 / 4 BDMUSB-HB / 5 2019USB-HB / 6 2019USB-ROM0 / 7 LegacyUSB-ROM0 / 8 LegacyUSB-HB / 9 ExternalUSB-ROM0 / 10 ExternalUSB-HB\ndefaultIOPResetMethod="..defaultIOPResetMethod.."\n                "
    xebConfFile=System.openFile("CFG/xebplus.cfg", FCREATE)
    System.writeFile(xebConfFile, TextToSave, string.len(TextToSave))
    System.closeFile(xebConfFile)
end

-- save XtremeBootloader (XBL.CNF) configuration
function saveXBLCNF()
    xblCnfPath="CFG/XBL.CNF"
    local listdira = System.listDirectory("mc0:/")
    local listdirb = System.listDirectory("mc1:/")
    local mcinfoa = System.getMCInfo(0)
    local mcinfob = System.getMCInfo(1)

    for i = 1, 4 do
        if i == 1 then tempPath = "mc0:/BOOT"
        elseif i == 2 then tempPath = "mc1:/BOOT"
        elseif i == 3 then tempPath = "mc0:/SYS-CONF"
        elseif i == 4 then tempPath = "mc1:/SYS-CONF"
        end
        if System.doesFileExist(tempPath.."/USBD.IRX")
        or System.doesFileExist(tempPath.."/USBHDFSD.IRX")
        or System.doesFileExist(tempPath.."/sysconf.icn")
        or System.doesFileExist(tempPath.."/icon.sys") then
            xblCnfPath = tempPath.."/XBL.CNF"
        end
    end

	TextToSaveB = "H_USBDrivers = "..H_USBDrivers.."\n  "
	xblCnfFile=System.openFile(xblCnfPath, FCREATE)
	System.removeFile(xblCnfFile)
	System.writeFile(xblCnfFile, TextToSaveB, string.len(TextToSaveB))
	System.closeFile(xblCnfFile)
    changedUSBDrivers=false
end

-- save XETTINGS configuration
function saveXETTINGSCNF()
    System.removeFile("CFG/xettings.cfg")
    TextToSave = "--Date separator: 1 - slash (/), 2 - hyphen (-), 3 - dot (.)\nXETTINGS_DateSeparator = "..XETTINGS_DateSeparator.."\n--Show \"Loading themes list...\" text: 1 - enabled, 2 - disabled\nXETTINGS_LoadingThemesText = "..XETTINGS_LoadingThemesText.."\n--Theme preview mode: 1 - enabled, 2 - enabled wihout \"Loading theme preview...\" text, 3 - disabled\nXETTINGS_ThemePreviewMode = "..XETTINGS_ThemePreviewMode.."\n--Exit to browser configuration: 1 - classic (rom0:OSDSYS), 2 - patch OSDSYS, 3 - mc?:/BOOT/BOOT.ELF\nXETTINGS_ExitToBrowser = "..XETTINGS_ExitToBrowser.."\n                "
    xettingsConfFile=System.openFile("CFG/xettings.cfg", FCREATE)
    System.writeFile(xettingsConfFile, TextToSave, string.len(TextToSave))
    System.closeFile(xettingsConfFile)
end

-- move long text to next line
function XETTINGS_CorrectTextLength(text)
    result = ""
    max_length = 42;
    while string.len(text) > max_length do
        space = max_length
        while space > 0 and text:sub(space, space) ~= ' ' do
            space = space - 1
        end
        if space == 0 then
            space = max_length
        end
        result = result .. text:sub(1, space) .. "\n"
        text = text:sub(space + 1)
    end
    return result..text
end

-- update exit to browser method
function XETTINGS_UpdateExitToBrowserItem()
    if XETTINGS_ExitToBrowser == 1 then -- rom0:OSDSYS
        xebCath[1].Option[2].Type = "LuaCode"
        xebCath[1].Option[2].Value = "Reboot"
    elseif XETTINGS_ExitToBrowser == 2 then -- patch OSDSYS
        xebCath[1].Option[2].Type = "LuaCode"
        xebCath[1].Option[2].Value = "ExitToBrowser"
    else -- method 3: mc?:/BOOT/BOOT.ELF
        xebCath[1].Option[2].Type = "SingleELF"
        xebCath[1].Option[2].ValueA = "mc0:/BOOT/BOOT.ELF"
        xebCath[1].Option[2].ValueB = "mc1:/BOOT/BOOT.ELF"
        xebCath[1].Option[2].ValueC = "rom0:OSDSYS"
    end
end

-- XEB+ Theme setting for submenu (used in themes with theme settings)
if System.doesFileExist("APPS/XETTINGS/set_theme_submenu.lua") then
    dofile("APPS/XETTINGS/set_theme_submenu.lua")
end

-- start
if theXEBPlusVersion == "XEBPLUS-2022-09" then
    -- set XETTINGS version global variable
    XETTINGS_Version = "1.3"

    -- reading XETTINGS configuration
    XETTINGS_DateSeparator = 1
    XETTINGS_LoadingThemesText = 1
    XETTINGS_ThemePreviewMode = 1
    XETTINGS_ExitToBrowser = 2
    if System.doesFileExist("CFG/xettings.cfg") then
        dofile("CFG/xettings.cfg")
    end

    -- replace drawTime() function for custom date separators
    function drawTime(valorXtiempo,valorYtiempo)
        if monthsBefore then
            if XETTINGS_DateSeparator == 3 then
                losMeses = "%m.%d.%Y"
            elseif XETTINGS_DateSeparator == 2 then
                losMeses = "%m-%d-%Y"
            else
                losMeses = "%m/%d/%Y"
            end
        else
            if XETTINGS_DateSeparator == 3 then
                losMeses = "%d.%m.%Y"
            elseif XETTINGS_DateSeparator == 2 then
                losMeses = "%d-%m-%Y"
            else
                losMeses = "%d/%m/%Y"
            end
        end
        if useAMPM then
            la_Hora = "%I:%M:%S %p"
        else
            la_Hora = "%H:%M:%S"
        end
        Graphics.drawImage(themeInUse[-6], valorXtiempo, plusYValue+valorYtiempo)
        Font.ftPrint(fontSmall, valorXtiempo+21, plusYValue+valorYtiempo-2, 0, 256, 32, ""..os.date(losMeses.." "..la_Hora).."", timeColor)
    end

    if XEBPlusLanguage == "en-US" then
        xetLang={}
        xetLang[0]="Refresh"
        xetLang[1]="Reload theme and plugins by restarting XEB+"
        xetLang[2]="Decide how to launch games from physical media"
        xetLang[3]="Change how the date is displayed"
        xetLang[4]="Change how the time is displayed"
        xetLang[5]="Decide what to do before launching an ELF"
        xetLang[6]="Enabled"
        xetLang[7]="Disabled"
        xetLang[8]="The ¶ button will be used to Accept\nand the ¬ button to Cancel." -- Buttons layout: CROSS button will be used to Accept
        xetLang[9]="The ¬ button will be used to Accept\nand the ¶ button to Cancel." -- Buttons layout: CIRCLE button will be used to Accept
        xetLang[10]="The "..XEBBTNACCEPT.." button will be used to Accept\nand the "..XEBBTNCANCEL.." button to Cancel."
        xetLang[11]="Language emulation"
        xetLang[12]="Change the language emulation settings"
        xetLang[13]="Language"
        xetLang[14]="Change the language applied to games"
        xetLang[15]="Applying a forced language will only work\nif language emulation is enabled. If you select\nEnglish, Spanish or Portuguese, XEB+ will\nbe launched using that language."
        xetLang[16]="Directory: " -- Theme
        xetLang[17]="Creator: " -- Theme
        xetLang[18]="Version: " -- Theme
        xetLang[19]="Recommended method"
        xetLang[20]="Recommended for users of MechaPwn 2.0\nwho has issues launching games."
        xetLang[21]="This launch method will only work properly in\nmodchips. Don't use it if your console don't\nhave a modchip installed."
        xetLang[22]="PS2LOGO will only be used when the game\nmatches your console's region.\nElse, Ghost CDFS will be used."
        xetLang[23]="PS2LOGO will only be used when the game\nmatches your console's region.\nElse, Direct CDROM0 will be used."
        xetLang[24]="Don't ever change this unless you have issues launching\napplications. This is only for troubleshooting purposes."
        xetLang[25]="Don't reset the IOP"
        xetLang[26]="Reset the IOP and loads the system drivers\nwith no USB support"
        xetLang[27]="Reset the IOP and loads the homebrew drivers\nwith no USB support"
        xetLang[28]="Reset the IOP and loads the system drivers\nand the BDM drivers"
        xetLang[29]="Reset the IOP and loads the homebrew drivers\nand the BDM drivers"
        xetLang[30]="Reset the IOP and loads the homebrew drivers\nand the USB drivers from 2019"
        xetLang[31]="Reset the IOP and loads the system drivers\nand the USB drivers from 2019"
        xetLang[32]="Reset the IOP and loads the system drivers\nand the USB drivers from circa 2012"
        xetLang[33]="Reset the IOP and loads the homebrew drivers\nand the USB drivers from circa 2012"
        xetLang[34]="Reset the IOP and loads the system drivers\nand loads the USB drivers from:\nmc0:/SYS-CONF/USBD.IRX and\nmc0:/SYS-CONF/USBHDFSD.IRX"
        xetLang[35]="Reset the IOP and loads the homebrew drivers\nand loads the USB drivers from:\nmc0:/SYS-CONF/USBD.IRX and\nmc0:/SYS-CONF/USBHDFSD.IRX"
        xetLang[36]="Select the USB drivers"
        xetLang[37]="You must restart XEB+ to apply these changes"
        xetLang[38]="Press "..XEBBTNEXTRAS.." to save settings and restart XEB+"
        xetLang[39]="USB Drivers"
        xetLang[40]="Select the USB drivers to use with XEB+"
        xetLang[41]="Uses the modern BDM USB drivers.\nSupports FAT32 and exFAT."
        xetLang[42]="Uses the USB drivers from 2019.\nSupports FAT32 only."
        xetLang[43]="Uses the USB drivers from circa 2012.\nSupports FAT32 only."
        xetLang[44]="Loads the drivers located at:\nmc0:/SYS-CONF/USBD.IRX and\nmc0:/SYS-CONF/USBHDFSD.IRX\nSupports whatever files you place there."
        xetLang[45]="Make sure the selected USB driver is supported by your\nUSB drive. Delete mc?:/BOOT/XBL.CNF or\nmc?:/SYS-CONF/XBL.CNF to restore default settings."
        xetLang[46]="Do you want to save this video mode?"
        xetLang[47]="Yes, save changes"
        xetLang[48]="No, restore the previous setting"
        xetLang[49]="If the screen remains black after changing\nthe video mode, the previous video mode\nwill be restored in 10 seconds"
        xetLang[50]="The previous video mode will be restored in "
        xetLang[51]=" seconds"
        xetLang[52]="To disable the childproof mode, you must\ninsert this code: Up, Up, Down, Down, Left,\nRight, Left, Right, Cross, Circle, Start"
        xetLang[53]="Default"
        xetLang[54]="English"
        xetLang[55]="French"
        xetLang[56]="Spanish"
        xetLang[57]="German"
        xetLang[58]="Italian"
        xetLang[59]="Dutch"
        xetLang[60]="Portuguese"
        xetLang[61]="Japanese"
        xetLang[62]="Time format"
        xetLang[63]="XETTINGS configuration"
        xetLang[64]="Configure XETTINGS plugin"
        xetLang[65]="Loading themes list..."
        xetLang[66]="Loading theme preview..."
        xetLang[67]="Classic"
        xetLang[68]="Classic method of exit to Browser.\nLaunches rom0:OSDSYS."
        xetLang[69]="Patch OSDSYS"
        xetLang[70]="Experimental method. Patches OSDSYS\nand adds button to go back to XEB+."
        xetLang[71]="mc?:/BOOT/BOOT.ELF"
        xetLang[72]="Launches mc?:/BOOT/BOOT.ELF."
        xetLang[73]="Enabled without \"Loading theme preview...\""
        xetLang[74]="Selected option will work only when\nXETTINGS plugin is installed.\nSelected option may not work with some\nthemes."
        xetLang[75]="Loading themes list progress"
        xetLang[76]="Enable or disable \"Loading themes list...\" text"
        xetLang[77]="Theme preview settings"
        xetLang[78]="Adjust theme preview settings"
        xetLang[79]="Configure \"Exit to browser\""
        xetLang[80]="Select \"Exit to browser\" button behavior"
    end
    if XEBPlusLanguage == "pt-BR" then
        xetLang={}
        xetLang[0]="Atualizar"
        xetLang[1]="Recarregue o tema e os plugins reiniciando o XEB+"
        xetLang[2]="Decida como lançar jogos a partir de mídia física"
        xetLang[3]="Alterar como a data é exibida"
        xetLang[4]="Alterar como a hora é exibida"
        xetLang[5]="Decida o que fazer antes de lançar um ELF"
        xetLang[6]="Habilitado"
        xetLang[7]="Desabilitado"
        xetLang[8]="O botão ¶ será usado para Aceitar\neo botão ¬ para Cancelar." -- Buttons layout: CROSS button will be used to Accept
        xetLang[9]="O botão ¬ será usado para Aceitar\neo botão ¶ para Cancelar." -- Buttons layout: CIRCLE button will be used to Accept
        xetLang[10]="O botão "..XEBBTNACCEPT.." será usado para Aceitar\neo botão "..XEBBTNCANCEL.." para Cancelar." -- Buttons layout
        xetLang[11]="Emulação de idioma"
        xetLang[12]="Alterar as configurações de emulação de idioma"
        xetLang[13]="Idioma"
        xetLang[14]="Alterar o idioma aplicado aos jogos"
        xetLang[15]="Aplicar um idioma forçado só funcionará\nse a emulação de idioma estiver habilitada.\nSe selecionar inglês, espanhol ou português,\no XEB+ será iniciado usando esse idioma."
        xetLang[16]="Diretório: " -- Theme
        xetLang[17]="Criador: " -- Theme
        xetLang[18]="Versão: " -- Theme
        xetLang[19]="Método recomendado"
        xetLang[20]="Recomendado para usuários do MechaPwn\n2.0 who têm problemas para iniciar jogos."
        xetLang[21]="Este método de inicialização só funcionará\ncorretamente em modchips. Não use se seu\nconsole não tiver um modchip instalado."
        xetLang[22]="O PS2LOGO só será usado quando o jogo\ncorresponder à região do seu console.\nCaso contrário, o Ghost CDFS será usado."
        xetLang[23]="O PS2LOGO só será usado quando o jogo\ncorresponder à região do seu console.\nCaso contrário, o Direct CDROM0 será usado."
        xetLang[24]="Nunca altere isso, a menos que você tenha problemas\npara iniciar aplicativos. Isso é apenas para fins de\nsolução de problemas."
        xetLang[25]="Não redefina o IOP"
        xetLang[26]="Redefina o IOP e carregue os drivers do\nsistema sem suporte a USB"
        xetLang[27]="Redefina o IOP e carregue os drivers\nhomebrew sem suporte a USB"
        xetLang[28]="Redefina o IOP e carregue os drivers do\nsistema e os drivers BDM"
        xetLang[29]="Redefina o IOP e carregue os drivers\nhomebrew e os drivers BDM"
        xetLang[30]="Redefina o IOP e carregue os drivers\nhomebrewe os drivers USB de 2019"
        xetLang[31]="Redefina o IOP e carregue os drivers do\nsistema e os drivers USB de 2019"
        xetLang[32]="Redefina o IOP e carregue os drivers do\nsistema e os drivers USB de cerca de 2012"
        xetLang[33]="Redefina o IOP e carregue os drivers\nhomebrew e os drivers USB de cerca de 2012"
        xetLang[34]="Redefina o IOP e carregue os drivers do\nsistema e carregue os drivers USB de:\nmc0:/SYS-CONF/USBD.IRX e\nmc0:/SYS-CONF/USBHDFSD.IRX"
        xetLang[35]="Redefina o IOP e carregue os drivers\nhomebrew e carregue os drivers USB de:\nmc0:/SYS-CONF/USBD.IRX e\nmc0:/SYS-CONF/USBHDFSD.IRX"
        xetLang[36]="Selecione os drivers USB"
        xetLang[37]="Você deve reiniciar o XEB+ para aplicar essas alterações"
        xetLang[38]="Pressione "..XEBBTNEXTRAS.." para salvar as configurações e reiniciar o XEB+"
        xetLang[39]="Drivers USB"
        xetLang[40]="Selecione os drivers USB para usar com o XEB+"
        xetLang[41]="Usar os drivers USB modernos (BDM).\nSuporta FAT32 e exFAT."
        xetLang[42]="Usar os drivers USB de 2019.\nSuporta somente FAT32."
        xetLang[43]="Usar os drivers USB de por volta de 2012.\nSuporta somente FAT32."
        xetLang[44]="Carregar os drivers localizados em:\nmc0:/SYS-CONF/USBD.IRX e\nmc0:/SYS-CONF/USBHDFSD.IRX. Suporta\nqualquer ficheiro que colocar neste caminho."
        xetLang[45]="Certifique-se de que o driver USB selecionado\né suportado pela sua unidade USB. Exclua\nmc?:/BOOT/XBL.CNF ou mc?:/SYS-CONF/XBL.CNF\npara restaurar as configurações padrão."
        xetLang[46]="Salvar este modo de video?"
        xetLang[47]="Sim, salvar configurações."
        xetLang[48]="Não, restaurar as configurações anteriores."
        xetLang[49]="Se a tela ficar negra após a mudança do\nmodo de video, o anterior modo de video\nserá restaurado em 10 segundos."
        xetLang[50]="O modo de video anterior será restaurado em "
        xetLang[51]=" segundos."
        xetLang[52]="Para desativar o modo de segurança, você\ndeve inserir este código: Cima, Cima, Baixo,\nBaixo, Esquerda, Direita, Esquerda, Direita,\nCruz, Círculo, Iniciar."
        xetLang[53]="Padrão"
        xetLang[54]="Inglês"
        xetLang[55]="Francês"
        xetLang[56]="Espanhol"
        xetLang[57]="Alemão"
        xetLang[58]="Italiano"
        xetLang[59]="Holandês"
        xetLang[60]="Português"
        xetLang[61]="Japonês"
        xetLang[62]="Formato da hora"
        xetLang[63]="Configuração de XETTINGS"
        xetLang[64]="Configurar o plug-in XETTINGS"
        xetLang[65]="A carregar lista de temas..."
        xetLang[66]="A carregar visualização do tema..."
        xetLang[67]="Clássico"
        xetLang[68]="Método clássico de saída para o browser.\nInicia rom0:OSDSYS."
        xetLang[69]="Patchear OSDSYS"
        xetLang[70]="Método experimental. Patcheia o OSDSYS\ne adiciona botão para voltar ao XEB+."
        xetLang[71]="mc?:/BOOT/BOOT.ELF"
        xetLang[72]="Inicia mc?:/BOOT/BOOT.ELF."
        xetLang[73]="Ativado sem \"A carregar visualização do tema...\""
        xetLang[74]="A opção selecionada funcionará somente\nquando o plugin XETTINGS estiver instalado.\nA opção selecionada pode não funcionar\ncom alguns temas."
        xetLang[75]="Carregando o progresso da lista de temas"
        xetLang[76]="Habilitar ou desabilitar o texto \"Carregando lista de temas...\""
        xetLang[77]="Configurações de visualização do tema"
        xetLang[78]="Ajustar as configurações de visualização do tema"
        xetLang[79]="Configurar \"Sair para o navegador\""
        xetLang[80]="Selecione o comportamento do botão \"Sair para o navegador\""
    end
    if XEBPlusLanguage == "es-419" then
        xetLang={}
        xetLang[0]="Refrescar"
        xetLang[1]="Reinicia XEB+ para recargar el tema y los plugins"
        xetLang[2]="Decide cómo cargar los juegos desde medios físicos"
        xetLang[3]="Cambiar cómo se muestra la fecha"
        xetLang[4]="Cambiar cómo se muestra la hora"
        xetLang[5]="Decide qué hacer antes de ejecutar un ELF"
        xetLang[6]="Habilitado"
        xetLang[7]="Deshabilitado"
        xetLang[8]="El botón ¶ será usado para Aceptar\ny el botón ¬ para Cancelar." -- Buttons layout: CROSS será usado para Aceptar
        xetLang[9]="El botón ¬ será usado para Aceptar\ny el botón ¶ para Cancelar." -- Buttons layout: CIRCLE será usado para Aceptar
        xetLang[10]="El botón "..XEBBTNACCEPT.." será usado para Aceptar\ny el botón "..XEBBTNCANCEL.." para Cancelar." -- Buttons layout
        xetLang[11]="Emulación de idioma"
        xetLang[12]="Cambia los ajustes de emulación de idioma"
        xetLang[13]="Idioma"
        xetLang[14]="Cambia el idioma que se aplicará a los juegos"
        xetLang[15]="Aplicar un idioma forzado solo funcionará\nsi la emulación de idioma está habilitada. Si\nselecciona inglés, español o portugués, XEB+\nse iniciará usando ese idioma."
        xetLang[16]="Carpeta: " -- Theme
        xetLang[17]="Creador: " -- Theme
        xetLang[18]="Versión: " -- Theme
        xetLang[19]="Método recomendado"
        xetLang[20]="Recomendado para usuarios de\nMechaPwn 2.0 que tengan problemas\npara iniciar juegos."
        xetLang[21]="Este método de carga solo funcionará\ncorrectamente en modchips. No lo uses si tu\nconsola no tiene uno instalado."
        xetLang[22]="PS2LOGO será usado solamente si la región\ndel juego concuerda con la consola.\nDe lo contrario, Ghost CDFS se usará."
        xetLang[23]="PS2LOGO será usado solamente si la región\ndel juego concuerda con la consola.\nDe lo contrario, Direct CDROM0 se usará."
        xetLang[24]="Nunca cambies esto a no ser que tengas problemas\nejecutando aplicaciones. Esto es solo para intentar\nsolventar problemas."
        xetLang[25]="No reinicia el IOP"
        xetLang[26]="Reinicia el IOP y carga los drivers del sistema\nsin soporte USB"
        xetLang[27]="Reinicia el IOP y carga los drivers homebrew\nsin soporte USB"
        xetLang[28]="Reinicia el IOP y carga los drivers del sistema\ny los drivers BDM"
        xetLang[29]="Reinicia el IOP y carga los drivers homebrew\ny los drivers BDM"
        xetLang[30]="Reinicia el IOP y carga los drivers homebrew\ny los drivers USB del 2019"
        xetLang[31]="Reinicia el IOP y carga los drivers del sistema\ny los drivers USB del 2019"
        xetLang[32]="Reinicia el IOP y carga los drivers del sistema\ny los drivers USB de cerca del 2012"
        xetLang[33]="Reinicia el IOP y carga los drivers homebrew\ny los drivers USB de cerca del 2012"
        xetLang[34]="Reinicia el IOP y carga los drivers del sistema\ny carga los drivers USB de:\nmc0:/SYS-CONF/USBD.IRX y\nmc0:/SYS-CONF/USBHDFSD.IRX"
        xetLang[35]="Reinicia el IOP y carga los drivers homebrew\ny carga los drivers USB de:\nmc0:/SYS-CONF/USBD.IRX y\nmc0:/SYS-CONF/USBHDFSD.IRX"
        xetLang[36]="Selecciona los drivers USB"
        xetLang[37]="Debes reiniciar XEB+ para aplicar estos cambios"
        xetLang[38]="Presiona "..XEBBTNEXTRAS.." para salvar la configuración y reiniciar XEB+"
        xetLang[39]="Drivers USB"
        xetLang[40]="Selecciona los drivers USB a usar en XEB+"
        xetLang[41]="Usa los drivers USB modernos (BDM).\nSoporta FAT32 y exFAT."
        xetLang[42]="Usa los drivers USB de 2019.\nSoporta FAT32 solamente."
        xetLang[43]="Usa los drivers USB de alrededor del 2012.\nSoporta FAT32 solamente."
        xetLang[44]="Carga los drivers ubicados en:\nmc0:/SYS-CONF/USBD.IRX y\nmc0:/SYS-CONF/USBHDFSD.IRX\nAcepta cualquier driver que le pongas ahí."
        xetLang[45]="Asegúrese de que el controlador USB seleccionado sea\ncompatible con su unidad USB. Elimine\nmc?:/BOOT/XBL.CNF o mc?:/SYS-CONF/XBL.CNF\nPara restaurar la configuración predeterminada."
        if isPALRegion then
            xetLang[46]="¿Quieres salvar este modo de vídeo?"
        else
            xetLang[46]="¿Quieres salvar este modo de video?"
        end
        xetLang[47]="Sí, salva los cambios."
        xetLang[48]="No, restaura la configuración anterior"
        if isPALRegion then
            xetLang[49]="Si la pantalla se queda en negro luego de\ncambiar la salida de vídeo, la anterior será\nrestaurada tras pasar 10 segundos"
            xetLang[50]="El modo anterior de vídeo será restaurado en "
        else
            xetLang[49]="Si la pantalla se queda en negro luego de\ncambiar la salida de video, la anterior será\nrestaurada tras pasar 10 segundos"
            xetLang[50]="El modo anterior de video será restaurado en "
        end
        xetLang[51]=" segundos"
        xetLang[52]="El modo infantil se deshabilita con el\nsiguiente código: Arriba, Arriba, Abajo,\nAbajo, Izquierda, Derecha, Izquierda,\nDerecha, Equis, Círculo, Start"
        xetLang[53]="Predeterminado"
        xetLang[54]="Inglés"
        xetLang[55]="Francés"
        xetLang[56]="Español"
        xetLang[57]="Alemán"
        xetLang[58]="Italiano"
        xetLang[59]="Holandés"
        xetLang[60]="Portugués"
        xetLang[61]="Japonés"
        xetLang[62]="Formato de hora"
        xetLang[63]="Configuración de XETTINGS"
        xetLang[64]="Configurar el complemento XETTINGS"
        xetLang[65]="Cargando lista de temas..."
        xetLang[66]="Cargando vista previa del tema"
        xetLang[67]="Clásico"
        xetLang[68]="Método clásico de salida al navegador.\nInicia rom0:OSDSYS."
        xetLang[69]="Parchear OSDSYS"
        xetLang[70]="Método experimental. Parchea OSDSYS\n y agrega un botón para volver a XEB+."
        xetLang[71]="mc?:/BOOT/BOOT.ELF"
        xetLang[72]="Inicia mc?:/BOOT/BOOT.ELF."
        xetLang[73]="Habilitado sin \"Cargar vista previa del tema...\""
        xetLang[74]="La opción seleccionada funcionará solo cuando el complemento\nXETTINGS esté instalado.\nEs posible que la opción seleccionada no funcione con algunos\ntemas."
        xetLang[75]="Progreso de la carga de la lista de temas"
        xetLang[76]="Habilitar o deshabilitar el texto \"Cargando lista de temas...\""
        xetLang[77]="Configuración de la vista previa del tema"
        xetLang[78]="Ajustar la configuración de la vista previa del tema"
        xetLang[79]="Configurar \"Salir al navegador\""
        xetLang[80]="Seleccionar el comportamiento del botón \"Salir al navegador\""
    end

    xebCath[1] = {}
    xebCath[1].Default = 2
    xebCath[1].Icon = 2
    xebCath[1].Amount = 5
    catStoreCount[1]=6
    xebCath[1].Option = {}
    xebCath[1].Option[1] = {}
    xebCath[1].Option[1].Type = "SingleELF" -- refresh
    xebCath[1].Option[1].Name = xetLang[0]
    xebCath[1].Option[1].Description = xetLang[1]
    xebCath[1].Option[1].Icon = 133
    xebCath[1].Option[1].Safe = true
    xebCath[1].Option[1].ValueA = "XEBPLUS.ELF"
    xebCath[1].Option[1].ValueB = "XEBPLUS_XMAS.ELF"
    xebCath[1].Option[1].ValueC = "BOOT.ELF"
    xebCath[1].Option[2] = {}
    xebCath[1].Option[2].Name = xebLang[4] -- exit to browser
    xebCath[1].Option[2].Description = xebLang[44]
    xebCath[1].Option[2].Icon = 131
    xebCath[1].Option[2].Safe = true
    XETTINGS_UpdateExitToBrowserItem()
    xebCath[1].Option[3] = {}
    xebCath[1].Option[3].Type = "LuaCode" -- reboot
    xebCath[1].Option[3].Name = xebLang[5]
    xebCath[1].Option[3].Description = xebLang[45]
    xebCath[1].Option[3].Icon = 134
    xebCath[1].Option[3].Safe = true
    xebCath[1].Option[3].Value = "Reboot"
    xebCath[1].Option[4] = {}
    xebCath[1].Option[4].Type = "LuaCode" -- shutdown
    xebCath[1].Option[4].Name = xebLang[6]
    xebCath[1].Option[4].Description = xebLang[46]
    xebCath[1].Option[4].Icon = 132
    xebCath[1].Option[4].Safe = true
    xebCath[1].Option[4].Value = "Shutdown"
    xebCath[1].Option[5] = {}
    xebCath[1].Option[5].Type = "LuaCode" -- about
    xebCath[1].Option[5].Name = xebLang[2]
    xebCath[1].Option[5].Description = xebLang[42]
    xebCath[1].Option[5].Icon = 120
    xebCath[1].Option[5].Safe = true
    xebCath[1].Option[5].Value = "About"

    xebCath[2].Default = 1
    xebCath[2].Icon = 6
    xebCath[2].Amount = 8
    catStoreCount[2]=9
    xebCath[2].Option = {}
    xebCath[2].Option[1] = {}
    xebCath[2].Option[1].Name=xebLang[115] -- buttons
    xebCath[2].Option[1].Description=xebLang[116]
    xebCath[2].Option[1].Type = "LuaScript"
    xebCath[2].Option[1].Icon = 69
    xebCath[2].Option[1].ValueA = "APPS/XETTINGS/xettings_contextmenu.lua"
    xebCath[2].Option[1].ValueB = "NONE"
    xebCath[2].Option[1].ValueC = "NONE"
    xebCath[2].Option[1].XETTINGSID = "buttons"
    xebCath[2].Option[2] = {}
    xebCath[2].Option[2].Name=xetLang[13] -- language (system)
    xebCath[2].Option[2].Description=xetLang[14]
    xebCath[2].Option[2].Type = "LuaScript"
    xebCath[2].Option[2].Icon = 75
    xebCath[2].Option[2].ValueA = "APPS/XETTINGS/xettings_contextmenu.lua"
    xebCath[2].Option[2].ValueB = "NONE"
    xebCath[2].Option[2].ValueC = "NONE"
    xebCath[2].Option[2].XETTINGSID = "langsys"
    xebCath[2].Option[3] = {}
    xebCath[2].Option[3].Name=xetLang[11] -- language emulation
    xebCath[2].Option[3].Description=xetLang[12]
    xebCath[2].Option[3].Type = "LuaScript"
    xebCath[2].Option[3].Icon = 75
    xebCath[2].Option[3].ValueA = "APPS/XETTINGS/xettings_contextmenu.lua"
    xebCath[2].Option[3].ValueB = "NONE"
    xebCath[2].Option[3].ValueC = "NONE"
    xebCath[2].Option[3].XETTINGSID = "langemu"
    xebCath[2].Option[4] = {}
    xebCath[2].Option[4].Name=xebLang[10] -- theme
    xebCath[2].Option[4].Description=xebLang[50]
    xebCath[2].Option[4].Type = "LuaScript"
    xebCath[2].Option[4].Icon = 77
    xebCath[2].Option[4].ValueA = "APPS/XETTINGS/xettings_contextmenu.lua"
    xebCath[2].Option[4].ValueB = "NONE"
    xebCath[2].Option[4].ValueC = "NONE"
    xebCath[2].Option[4].XETTINGSID = "theme"
    xebCath[2].Option[5] = {}
    xebCath[2].Option[5].Name=xebLang[7] -- video mode
    xebCath[2].Option[5].Description=xebLang[47]
    xebCath[2].Option[5].Type = "LuaScript"
    xebCath[2].Option[5].Icon = 71
    xebCath[2].Option[5].ValueA = "APPS/XETTINGS/xettings_contextmenu.lua"
    xebCath[2].Option[5].ValueB = "NONE"
    xebCath[2].Option[5].ValueC = "NONE"
    xebCath[2].Option[5].XETTINGSID = "videomode"
    xebCath[2].Option[6] = {}
    xebCath[2].Option[6].Name=xebLang[11] -- childproof mode
    xebCath[2].Option[6].Description=xebLang[51]
    xebCath[2].Option[6].Type = "LuaScript"
    xebCath[2].Option[6].Icon = 76
    xebCath[2].Option[6].ValueA = "APPS/XETTINGS/xettings_contextmenu.lua"
    xebCath[2].Option[6].ValueB = "NONE"
    xebCath[2].Option[6].ValueC = "NONE"
    xebCath[2].Option[6].XETTINGSID = "childproof"
    xebCath[2].Option[7] = {}
    xebCath[2].Option[7].Name=xebLang[12] -- XEB+ configuration
    xebCath[2].Option[7].Description=xebLang[52]
    xebCath[2].Option[7].Type = "LuaScript"
    xebCath[2].Option[7].Icon = 78
    xebCath[2].Option[7].ValueA = "APPS/XETTINGS/xettings_submenu.lua"
    xebCath[2].Option[7].ValueB = "NONE"
    xebCath[2].Option[7].ValueC = "NONE"
    xebCath[2].Option[7].XETTINGSID = "xebconf"
    xebCath[2].Option[8] = {}
    xebCath[2].Option[8].Name=xetLang[63] -- XETTINGS configuration
    xebCath[2].Option[8].Description=xetLang[64]
    xebCath[2].Option[8].Type = "LuaScript"
    xebCath[2].Option[8].Icon = 70
    xebCath[2].Option[8].ValueA = "APPS/XETTINGS/xettings_submenu.lua"
    xebCath[2].Option[8].ValueB = "NONE"
    xebCath[2].Option[8].ValueC = "NONE"
    xebCath[2].Option[8].XETTINGSID = "xettingsconf"
    
    -- adding FreeMCBoot Configurator
    addFMCBCFG=false
    if System.doesFileExist("mc0:/SYS-CONF/FMCB_CFG.ELF") then
        addFMCBCFG=true
    elseif System.doesFileExist("mc1:/SYS-CONF/FMCB_CFG.ELF") then
        addFMCBCFG=true
    elseif System.doesFileExist("mass:/PS2/APPS/FMCB_CFG/FMCB_CFG.ELF") then
        addFMCBCFG=true
    end
    if addFMCBCFG then
        xebCath[2].Amount = 9
        xebCath[2].Option[9] = {}
        xebCath[2].Option[9].Type = "SingleELF"
        xebCath[2].Option[9].Category = 3
        xebCath[2].Option[9].Name = xebLang[97]
        xebCath[2].Option[9].Description = xebLang[98]
        xebCath[2].Option[9].Icon = 74
        xebCath[2].Option[9].Safe = false
        xebCath[2].Option[9].ValueA = "mass:/PS2/APPS/FMCB_CFG/FMCB_CFG.ELF"
        xebCath[2].Option[9].ValueB = "mc0:/SYS-CONF/FMCB_CFG.ELF"
        xebCath[2].Option[9].ValueC = "mc1:/SYS-CONF/FMCB_CFG.ELF"
        catStoreCount[2]=10
    end
end