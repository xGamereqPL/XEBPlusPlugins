-- XETTINGS 1.3 [SubMenu] by xGamereqPL

GoToSubMenuIcon(actualCat,actualOption,true)
XEBKeepInSubMenu=true

-----------------------------------------------------------------
---------------------- SUBMENU OPTIONS LIST ---------------------
-----------------------------------------------------------------

SubMenuItem = nil
SubMenuItem = {}
SubMenuItemSelected = 1
changedXEBsettings = false
changedXBLsettings = false
changedXETTINGSsettings = false

if xebCath[actualCat].Option[actualOption].XETTINGSID == "xebconf" then
	SubMenuItem[1] = {}
	SubMenuItem[1].Name = xebLang[220] -- disc launch behavior
	SubMenuItem[1].Description = xetLang[2]
	SubMenuItem[1].Icon = 78
	SubMenuItem[1].ContextMenuID = "xebconf_disclaunch"
	SubMenuItem[2] = {}
	SubMenuItem[2].Name = xebLang[214] -- date format
	SubMenuItem[2].Description = xetLang[3]
	SubMenuItem[2].Icon = 78
	SubMenuItem[2].ContextMenuID = "xebconf_dateformat"
	SubMenuItem[3] = {}
	SubMenuItem[3].Name = xetLang[62] -- time format
	SubMenuItem[3].Description = xetLang[4]
	SubMenuItem[3].Icon = 78
	SubMenuItem[3].ContextMenuID = "xebconf_timeformat"
	SubMenuItem[4] = {}
	SubMenuItem[4].Name = xebLang[213] -- default IOP reset method
	SubMenuItem[4].Description = xetLang[5]
	SubMenuItem[4].Icon = 78
	SubMenuItem[4].ContextMenuID = "xebconf_defaultiopreset"
	SubMenuItem[5] = {}
	SubMenuItem[5].Name = xetLang[39] -- USB Drivers
	SubMenuItem[5].Description = xetLang[40]
	SubMenuItem[5].Icon = 78
	SubMenuItem[5].ContextMenuID = "xebconf_usbdrivers"
end

if xebCath[actualCat].Option[actualOption].XETTINGSID == "xettingsconf" then
	SubMenuItem[1] = {}
	SubMenuItem[1].Name = xetLang[75]
	SubMenuItem[1].Description = xetLang[76]
	SubMenuItem[1].Icon = 70
	SubMenuItem[1].ContextMenuID = "xettingsconf_loadingthemestext"
	SubMenuItem[2] = {}
	SubMenuItem[2].Name = xetLang[77]
	SubMenuItem[2].Description = xetLang[78]
	SubMenuItem[2].Icon = 70
	SubMenuItem[2].ContextMenuID = "xettingsconf_themepreview"
	SubMenuItem[3] = {}
	SubMenuItem[3].Name = xetLang[79]
	SubMenuItem[3].Description = xetLang[80]
	SubMenuItem[3].Icon = 70
	SubMenuItem[3].ContextMenuID = "xettingsconf_exittobrowser"
end

SubMenuItemTotal = #SubMenuItem

-----------------------------------------------------------------
-------------------------- SUBMENU CODE -------------------------
-----------------------------------------------------------------

function xetSubMenu_DrawXEBUIInSubMenu()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ItemPosition = -5
	for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
		SubMenu_iB_Y = SubMenu_ItemPosition*71
		if SubMenu_iB == SubMenuItemSelected then
			xetSubMenu_DrawItem(152, 206, false, SubMenuItem[SubMenu_iB].Name, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		else
			xetSubMenu_DrawItem(152, SubMenu_iB_Y+135, true, SubMenuItem[SubMenu_iB].Name, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		end
		SubMenu_ItemPosition=SubMenu_ItemPosition+1
	end
end

function xetSubMenu_DrawItem(SubMenu_TempX, SubMenu_TempY, SubMenu_TempFaded, SubMenu_TempName, SubMenu_TempIcon, SubMenu_TempDescription) -- int, int, boolean, string, string
	SubMenu_IconToDraw = SubMenu_TempIcon
	if SubMenu_TempFaded then
		if SubMenu_TempName ~= "" then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, columnsFade)
			if SubMenu_IconToDraw == SubMenu_TempIcon then
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFaded)
			else
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFaded)
			end
		end
		Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, baseColorFaded)
	else
		if SubMenu_TempName ~= "" then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY)
			if SubMenu_IconToDraw == SubMenu_TempIcon then
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFull)
			else
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFull)
			end
		end
		Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, baseColorFull)
	end
end

function xetSubMenu_DrawItemFrame(SubMenu_TempX, SubMenu_TempY, SubMenu_TempFaded, SubMenu_TempName, SubMenu_TempTheFrame, SubMenu_TempTheColorA, SubMenu_TempTheColorB, SubMenu_TempIcon, SubMenu_TempDescription) -- int, int, boolean/int, string, int, u32 color, u32 color, string
	SubMenu_IconToDraw = SubMenu_TempIcon
	if SubMenu_TempName ~= "" then
		if SubMenu_TempFaded == true then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, xetSubMenu_SpriteGetAnimationAlphaMin(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == false then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, xetSubMenu_SpriteGetAnimationAlphaMinMax(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == 2 then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, xetSubMenu_SpriteGetAnimationAlphaMax(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == 3 then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, xetSubMenu_SpriteGetAnimationAlphaMaxFade(SubMenu_TempTheFrame))
		end
		if SubMenu_IconToDraw == SubMenu_TempIcon then
			Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, xetSubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
		else
			Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, xetSubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
		end
	end
	Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, xetSubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
end

function xetSubMenu_ColorGetAnimationAlpha(SubMenu_TempFrame,SubMenu_TempColorA,SubMenu_TempColorB) -- int, u32 color, u32 color
	SubMenu_TempColorAA=Color.getA(SubMenu_TempColorA)
	SubMenu_TempColorBA=Color.getA(SubMenu_TempColorB)
	SubMenu_TempColorAR=Color.getR(SubMenu_TempColorA)
	SubMenu_TempColorBR=Color.getR(SubMenu_TempColorB)
	SubMenu_TempColorAG=Color.getG(SubMenu_TempColorA)
	SubMenu_TempColorBG=Color.getG(SubMenu_TempColorB)
	SubMenu_TempColorAB=Color.getB(SubMenu_TempColorA)
	SubMenu_TempColorBB=Color.getB(SubMenu_TempColorB)
	SubMenu_TempAlphaC=SubMenu_TempColorAA-SubMenu_TempColorBA
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC
	SubMenu_TempAlphaC=SubMenu_TempColorBA+SubMenu_TempAlphaC
	SubMenu_TempNextColorA=XEBMathRound(SubMenu_TempAlphaC)
	SubMenu_TempAlphaC=SubMenu_TempColorAR-SubMenu_TempColorBR
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC
	SubMenu_TempAlphaC=SubMenu_TempColorBR+SubMenu_TempAlphaC
	SubMenu_TempNextColorR=XEBMathRound(SubMenu_TempAlphaC)
	SubMenu_TempAlphaC=SubMenu_TempColorAG-SubMenu_TempColorBG
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC
	SubMenu_TempAlphaC=SubMenu_TempColorBG+SubMenu_TempAlphaC
	SubMenu_TempNextColorG=XEBMathRound(SubMenu_TempAlphaC)
	SubMenu_TempAlphaC=SubMenu_TempColorAB-SubMenu_TempColorBB
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC
	SubMenu_TempAlphaC=SubMenu_TempColorBB+SubMenu_TempAlphaC
	SubMenu_TempNextColorB=XEBMathRound(SubMenu_TempAlphaC)
	SubMenu_TempNewColor=Color.new(SubMenu_TempNextColorR,SubMenu_TempNextColorG,SubMenu_TempNextColorB,SubMenu_TempNextColorA)
	return SubMenu_TempNewColor
end

function xetSubMenu_SpriteGetAnimationAlphaMin(SubMenu_TempFrame)
	SubMenu_TempAlpha=columnsFade
	SubMenu_TempAlpha=SubMenu_TempAlpha/4
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha)
	return SubMenu_TempAlpha
end

function xetSubMenu_SpriteGetAnimationAlphaMax(SubMenu_TempFrame)
	SubMenu_TempAlpha=255
	SubMenu_TempAlpha=SubMenu_TempAlpha-columnsFade
	SubMenu_TempAlpha=SubMenu_TempAlpha/4
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha
	SubMenu_TempAlpha=columnsFade+SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha)
	return SubMenu_TempAlpha
end

function xetSubMenu_SpriteGetAnimationAlphaMaxFade(SubMenu_TempFrame)
	SubMenu_TempAlpha=columnsFade
	SubMenu_TempAlpha=SubMenu_TempAlpha-255
	SubMenu_TempAlpha=SubMenu_TempAlpha/4
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha
	SubMenu_TempAlpha=255+SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha)
	return SubMenu_TempAlpha
end

function xetSubMenu_SpriteGetAnimationAlphaMinMax(SubMenu_TempFrame)
	if SubMenu_TempFrame == 4 then
		SubMenu_TempAlpha=255
	else
		SubMenu_TempAlpha=SubMenu_TempFrame*64
	end
	return SubMenu_TempAlpha
end

SubMenu_ColorFullZero=Color.new(Color.getR(baseColorFull),Color.getG(baseColorFull),Color.getB(baseColorFull),0)
SubMenu_ColorFadedZero=Color.new(Color.getR(baseColorFaded),Color.getG(baseColorFaded),Color.getB(baseColorFaded),0)

for SubMenu_i = -7, 0 do
	SubMenuItem[SubMenu_i] = {}
	SubMenuItem[SubMenu_i].Name = ""
	SubMenuItem[SubMenu_i].Description = ""
end	
for SubMenu_i = SubMenuItemTotal+1, SubMenuItemTotal+7 do
	SubMenuItem[SubMenu_i] = {}
	SubMenuItem[SubMenu_i].Name = ""
	SubMenuItem[SubMenu_i].Description = ""
end

for SubMenu_i = 1, 3 do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ItemPosition = -5
	for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
		SubMenu_iB_Y = SubMenu_ItemPosition*71
		if SubMenu_iB == SubMenuItemSelected then
			xetSubMenu_DrawItemFrame(152, 206, false, SubMenuItem[SubMenu_iB].Name, SubMenu_i, baseColorFull, SubMenu_ColorFullZero, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		else
			xetSubMenu_DrawItemFrame(152, SubMenu_iB_Y+135, true, SubMenuItem[SubMenu_iB].Name, SubMenu_i, baseColorFaded, SubMenu_ColorFadedZero, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		end
		SubMenu_ItemPosition=SubMenu_ItemPosition+1
	end
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end

SubMenu_HoldingUp=99
SubMenu_HoldingUpDash=0
SubMenu_HoldingDown=99
SubMenu_HoldingDownDash=0

function xetSubMenu_AnimateUp()
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
	for SubMenu_Move = 1, 3 do
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_PositionUp = XEBMathRound(SubMenu_Move * 17.75)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SubMenuItemSelected then
				xetSubMenu_DrawItemFrame(152, SubMenu_iB_Y+135+SubMenu_PositionUp, 3, SubMenuItem[SubMenu_iB].Name, SubMenu_Move, baseColorFaded, baseColorFull, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			elseif SubMenu_iB == SubMenuItemSelected-1 then
				xetSubMenu_DrawItemFrame(152, SubMenu_iB_Y+135+SubMenu_PositionUp, 2, SubMenuItem[SubMenu_iB].Name, SubMenu_Move, baseColorFull, baseColorFaded, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			else
				xetSubMenu_DrawItem(152, SubMenu_iB_Y+135+SubMenu_PositionUp, true, SubMenuItem[SubMenu_iB].Name, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		if not Pads.check(pad, PAD_UP) then
			SubMenu_HoldingUp=99
			SubMenu_HoldingUpDash=0
		end
		if SubMenu_Move ~= 3 then
			spinDisc()
			thmDrawBKGOL()
			Screen.waitVblankStart()
			oldpad = pad
			Screen.flip()
		end
	end
end

function xetSubMenu_AnimateDown()
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
	for SubMenu_Move = 1, 3 do
		SubMenu_MoveBack=4-SubMenu_Move
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_PositionDown = XEBMathRound(SubMenu_Move * 17.75)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SubMenuItemSelected then
				xetSubMenu_DrawItemFrame(152, SubMenu_iB_Y+135-SubMenu_PositionDown, 2, SubMenuItem[SubMenu_iB].Name, SubMenu_MoveBack, baseColorFull, baseColorFaded, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			elseif SubMenu_iB == SubMenuItemSelected+1 then
				xetSubMenu_DrawItemFrame(152, SubMenu_iB_Y+135-SubMenu_PositionDown, 3, SubMenuItem[SubMenu_iB].Name, SubMenu_MoveBack, baseColorFaded, baseColorFull, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			else
				xetSubMenu_DrawItem(152, SubMenu_iB_Y+135-SubMenu_PositionDown, true, SubMenuItem[SubMenu_iB].Name, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		if not Pads.check(oldpad, PAD_DOWN) then
			SubMenu_HoldingDown=99
			SubMenu_HoldingDownDash=0
		end
		if not Pads.check(pad, PAD_DOWN) then
			SubMenu_HoldingDown=99
			SubMenu_HoldingDownDash=0
		end
		if SubMenu_Move ~= 3 then
			spinDisc()
			thmDrawBKGOL()
			Screen.waitVblankStart()
			oldpad = pad
			Screen.flip()
		end
	end
end

function xetContextMenu_GetTempScrollingValues()
	if ContextMenuItemSelected == ContextMenuItemTotal then
		AdjustItemY=(ContextMenuItemSelected-ContextMenuMaxItemsOnScreen+1)*24-24
		ItemNrFirst = 1 + ContextMenuItemSelected - ContextMenuMaxItemsOnScreen
		ItemNrLast = ContextMenuItemSelected
	elseif ContextMenuItemSelected >= ContextMenuMaxItemsOnScreen then
		AdjustItemY=(ContextMenuItemSelected-ContextMenuMaxItemsOnScreen+1)*24
		ItemNrFirst = 2 + ContextMenuItemSelected - ContextMenuMaxItemsOnScreen
		ItemNrLast = ContextMenuItemSelected + 1
	else
		AdjustItemY=0
		ItemNrFirst = 1
		ItemNrLast = ContextMenuMaxItemsOnScreen
	end
	if ContextMenuMaxItemsOnScreen > ContextMenuItemTotal then
		AdjustItemY=0
		ItemNrFirst = 1
		ItemNrLast = ContextMenuItemTotal
	end
end

while XEBKeepInSubMenu do
	pad = Pads.get()
	Screen.clear()
	xetSubMenu_DrawXEBUIInSubMenu()
	if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
		-- CONTEXT MENU
		XEBKeepInContextMenu="true"

		ContextMenu = nil
		ContextMenu = {}
		ContextMenuItemSelected = 1
		ContextMenu[0] = {}

		-- XEB+ configuration: disc launch behavior
		if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_disclaunch" then
			ContextMenu[0].UseDescriptions = true

			for i = 1, 5 do
				ContextMenu[i] = {}
			end
	
			ContextMenu[1].Name = xebLang[221]
			ContextMenu[1].Description = xetLang[19]
			ContextMenu[2].Name = xebLang[222]
			ContextMenu[2].Description = xetLang[20]
			ContextMenu[3].Name = xebLang[223]
			ContextMenu[3].Description = xetLang[21]
			ContextMenu[4].Name = xebLang[224]
			ContextMenu[4].Description = xetLang[22]
			ContextMenu[5].Name = xebLang[225]
			ContextMenu[5].Description = xetLang[23]

			ContextMenuItemSelected = launchPS2CDVD
		end

		-- XEB+ configuration: date format
		if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_dateformat" then
			ContextMenu[0].UseDescriptions = true

			for i = 1, 6 do
				ContextMenu[i] = {}
			end

			ContextMenu[1].Name = xebLang[215] -- DD/MM/YYYY
			ContextMenu[1].Description = ""
			ContextMenu[2].Name = xebLang[216] -- MM/DD/YYYY
			ContextMenu[2].Description = ""
			ContextMenu[3].Name = string.sub(xebLang[215], 1, 2).."-"..string.sub(xebLang[215], 4, 5).."-"..string.sub(xebLang[215], 7, 10) -- DD-MM-YYYY
			ContextMenu[3].Description = xetLang[74]
			ContextMenu[4].Name = string.sub(xebLang[216], 1, 2).."-"..string.sub(xebLang[216], 4, 5).."-"..string.sub(xebLang[216], 7, 10) -- MM-MD-YYYY
			ContextMenu[4].Description = xetLang[74]
			ContextMenu[5].Name = string.sub(xebLang[215], 1, 2).."."..string.sub(xebLang[215], 4, 5).."."..string.sub(xebLang[215], 7, 10) -- DD.MM.YYYY
			ContextMenu[5].Description = xetLang[74]
			ContextMenu[6].Name = string.sub(xebLang[216], 1, 2).."."..string.sub(xebLang[216], 4, 5).."."..string.sub(xebLang[216], 7, 10) -- MM.DD.YYYY
			ContextMenu[6].Description = xetLang[74]

			if monthsBefore == false then
				if XETTINGS_DateSeparator == 1 then ContextMenuItemSelected = 1 end
				if XETTINGS_DateSeparator == 2 then ContextMenuItemSelected = 3 end
				if XETTINGS_DateSeparator == 3 then ContextMenuItemSelected = 5 end
			else
				if XETTINGS_DateSeparator == 1 then ContextMenuItemSelected = 2 end
				if XETTINGS_DateSeparator == 2 then ContextMenuItemSelected = 4 end
				if XETTINGS_DateSeparator == 3 then ContextMenuItemSelected = 6 end
			end
		end

		-- XEB+ configuration: time format
		if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_timeformat" then
			ContextMenu[0].UseDescriptions = false

			for i = 1, 2 do
				ContextMenu[i] = {}
			end

			ContextMenu[1].Name = xebLang[218] -- 12 hours
			ContextMenu[2].Name = xebLang[219] -- 24 hours
	
			if useAMPM then
				ContextMenuItemSelected = 1
			else
				ContextMenuItemSelected = 2
			end
		end

		-- XEB+ configuration: default IOP reset method
		if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_defaultiopreset" then
			ContextMenu[0].UseDescriptions = true
			ContextMenu[0].Warning = xetLang[24]

			for i = 1, 11 do
				ContextMenu[i] = {}
			end

			ContextMenu[1].Name = "NoIOPReset"
			ContextMenu[1].Description = xetLang[25]
			ContextMenu[2].Name = "NoUSB-ROM0"
			ContextMenu[2].Description = xetLang[26]
			ContextMenu[3].Name = "NoUSB-HB"
			ContextMenu[3].Description = xetLang[27]
			ContextMenu[4].Name = "BDMUSB-ROM0"
			ContextMenu[4].Description = xetLang[28]
			ContextMenu[5].Name = "BDMUSB-HB"
			ContextMenu[5].Description = xetLang[29]
			ContextMenu[6].Name = "2019USB-ROM0"
			ContextMenu[6].Description = xetLang[31] -- this is not mistake!
			ContextMenu[7].Name = "2019USB-HB"
			ContextMenu[7].Description = xetLang[30] -- this is not mistake!
			ContextMenu[8].Name = "LegacyUSB-ROM0"
			ContextMenu[8].Description = xetLang[32]
			ContextMenu[9].Name = "LegacyUSB-HB"
			ContextMenu[9].Description = xetLang[33]
			ContextMenu[10].Name = "ExternalUSB-ROM0"
			ContextMenu[10].Description = xetLang[34]
			ContextMenu[11].Name = "ExternalUSB-HB"
			ContextMenu[11].Description = xetLang[35]

			-- in XEB+ cfg:
			-- ... 3 BDMUSB-ROM0 / 4 BDMUSB-HB / 5 2019USB-HB / 6 2019USB-ROM0 / 7 LegacyUSB-ROM0 / 8 LegacyUSB-HB ...
			-- in this menu:
			-- ... 4 BDMUSB-ROM0 / 5 BDMUSB-HB / 7 2019USB-HB / 6 2019USB-ROM0 / 8 LegacyUSB-ROM0 / 9 LegacyUSB-HB ...

			if defaultIOPResetMethod == 5 then
				ContextMenuItemSelected = 7
			elseif defaultIOPResetMethod == 6 then
				ContextMenuItemSelected = 6
			else
				ContextMenuItemSelected = defaultIOPResetMethod + 1
			end
		end

		-- XEB+ configuration: USB drivers
		if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_usbdrivers" then
			ContextMenu[0].UseDescriptions = true
			ContextMenu[0].Warning = xetLang[45]

			for i = 1, 4 do
				ContextMenu[i] = {}
			end

			ContextMenu[1].Name = "BDM"
			ContextMenu[1].Description = xetLang[41]
			ContextMenu[2].Name = "NEO"
			ContextMenu[2].Description = xetLang[42]
			ContextMenu[3].Name = "OLD"
			ContextMenu[3].Description = xetLang[43]
			ContextMenu[4].Name = "EXT"
			ContextMenu[4].Description = xetLang[44]

			if H_USBDrivers == "BDM" then
				ContextMenuItemSelected = 1
			elseif H_USBDrivers == "NEO" then
				ContextMenuItemSelected = 2
			elseif H_USBDrivers == "OLD" then
				ContextMenuItemSelected = 3
			elseif H_USBDrivers == "EXT" then
				ContextMenuItemSelected = 4
			end
		end

		-- XETTINGS configuration: themes list
		if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xettingsconf_loadingthemestext" then
			ContextMenu[0].UseDescriptions = false

			for i = 1, 2 do
				ContextMenu[i] = {}
			end

			ContextMenu[1].Name = xetLang[6] -- enabled
			ContextMenu[2].Name = xetLang[7] -- disabled

			ContextMenuItemSelected = XETTINGS_LoadingThemesText
		end

		-- XETTINGS configuration: theme preview settings
		if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xettingsconf_themepreview" then
			ContextMenu[0].UseDescriptions = false
			for i = 1, 3 do
				ContextMenu[i] = {}
			end

			ContextMenu[1].Name = xetLang[6]
			ContextMenu[2].Name = xetLang[73]
			ContextMenu[3].Name = xetLang[7]

			ContextMenuItemSelected = XETTINGS_ThemePreviewMode
		end

		-- XETTINGS configuration: Configure Exit to browser
		if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xettingsconf_exittobrowser" then
			ContextMenu[0].UseDescriptions = true

			for i = 1, 3 do
				ContextMenu[i] = {}
			end

			ContextMenu[1].Name = xetLang[67]
			ContextMenu[1].Description = xetLang[68]
			ContextMenu[2].Name = xetLang[69]
			ContextMenu[2].Description = xetLang[70]
			ContextMenu[3].Name = xetLang[71]
			ContextMenu[3].Description = xetLang[72]

			ContextMenuItemSelected = XETTINGS_ExitToBrowser
		end

		ContextMenuItemTotal = #ContextMenu
		OldContextMenuItemSelected = ContextMenuItemSelected
		DefaultContextMenuItemSelected = ContextMenuItemSelected
		if ContextMenu[0].UseDescriptions then
			ContextMenuMaxItemsOnScreen = 13
			for i = 1, ContextMenuItemTotal do
				if ContextMenu[i].Description == nil then
					ContextMenu[i].Description = ""
				end
			end
		else
			ContextMenuMaxItemsOnScreen = 19
			for i = 1, ContextMenuItemTotal do
				ContextMenu[i].Description = ""
			end
		end
		xetContextMenu_GetTempScrollingValues()

		for move = 1, 10 do
			pad = Pads.get()
			Screen.clear()
			xetSubMenu_DrawXEBUIInSubMenu()
			spinDisc()
			thmDrawBKGOL()
		
			moveb=move*25
			movec=310-move*31
		
			for i = 1, howMuchRedrawTransparencyLayer do
				Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, moveb)
			end
			----------------------------------------------------------------------------
			Graphics.drawImageExtended(themeInUse[-5], 542+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
			Graphics.drawImageExtended(themeInUse[-4], 542+movec, ContextMenuItemSelected*24+2, 0, 0, 325, 22, 325, 22, 0, 255)
			for ItemToDraw = ItemNrFirst,ItemNrLast do
				TempItemY=ItemToDraw*24-8
				Font.ftPrint(fontSmall, 400+movec, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
			end
			Font.ftPrint(fontSmall, 400+movec, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)

			if ContextMenu[0].Warning ~= nil then
				Graphics.drawRect(198, 420, 342, 80, Color.new(220,0,0,move*9))
				Font.ftPrint(fontSmall, 30, plusYValue+383, 0, 512, 64, ContextMenu[0].Warning, Color.new(255,255,255,move*12))
			end
			----------------------------------------------------------------------------
			Screen.waitVblankStart()
			oldpad = pad
			Screen.flip()
		end
		while XEBKeepInContextMenu == "true" do
			pad = Pads.get()
			Screen.clear()
			xetSubMenu_DrawXEBUIInSubMenu()
			spinDisc()
			thmDrawBKGOL()
			for i = 1, howMuchRedrawTransparencyLayer do
				Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
			end
			----------------------------------------------------------------------------
			Graphics.drawImageExtended(themeInUse[-5], 542, 240, 0, 0, 325, 480, 325, 480, 0, 255)
			Graphics.drawImageExtended(themeInUse[-4], 542, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
			for ItemToDraw = ItemNrFirst,ItemNrLast do
				TempItemY=ItemToDraw*24-AdjustItemY-8
				Font.ftPrint(fontSmall, 400, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
			end
			Font.ftPrint(fontSmall, 400, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)

			if ContextMenu[0].Warning ~= nil then
				Graphics.drawRect(198, 420, 342, 80, Color.new(220,0,0,100))
				Font.ftPrint(fontSmall, 30, plusYValue+383, 0, 512, 64, ContextMenu[0].Warning, Color.new(255,255,255,128))
			end
			----------------------------------------------------------------------------
			if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
				-- ACCEPT SETTINGS

				-- XEB+ configuration: disc launch behavior
				if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_disclaunch" then
					if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
						changedXEBsettings = true
					end
					launchPS2CDVD = ContextMenuItemSelected
				end

				-- XEB configuration: date format
				if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_dateformat" then
					if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
						changedXEBsettings = true
						changedXETTINGSsettings = true
					end
					if ContextMenuItemSelected == 1 then
						monthsBefore = false
						XETTINGS_DateSeparator = 1
					elseif ContextMenuItemSelected == 2 then
						monthsBefore = true
						XETTINGS_DateSeparator = 1
					elseif ContextMenuItemSelected == 3 then
						monthsBefore = false
						XETTINGS_DateSeparator = 2
					elseif ContextMenuItemSelected == 4 then
						monthsBefore = true
						XETTINGS_DateSeparator = 2
					elseif ContextMenuItemSelected == 5 then
						monthsBefore = false
						XETTINGS_DateSeparator = 3
					elseif ContextMenuItemSelected == 6 then
						monthsBefore = true
						XETTINGS_DateSeparator = 3
					end
				end

				-- XEB+ configuration: time format
				if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_timeformat" then
					if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
						changedXEBsettings = true
					end
					if ContextMenuItemSelected == 1 then
						useAMPM = true
					else
						useAMPM = false
					end
				end

				-- XEB+ configuration: default IOP reset method
				if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_defaultiopreset" then
					if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
						changedXEBsettings = true
					end

					if ContextMenuItemSelected == 7 then
						defaultIOPResetMethod = 5
					elseif ContextMenuItemSelected == 6 then
						defaultIOPResetMethod = 6
					else
						defaultIOPResetMethod = ContextMenuItemSelected - 1
					end
				end

				-- XEB+ configuration: USB drivers
				if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xebconf_usbdrivers" then
					if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
						changedXBLsettings = true
					end
					if ContextMenuItemSelected == 1 then
						H_USBDrivers = "BDM"
					elseif ContextMenuItemSelected == 2 then
						H_USBDrivers = "NEO"
					elseif ContextMenuItemSelected == 3 then
						H_USBDrivers = "OLD"
					elseif ContextMenuItemSelected == 4 then
						H_USBDrivers = "EXT"
					end
				end

				-- XETTINGS configuration: Themes list
				if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xettingsconf_loadingthemestext" then
					if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
						changedXETTINGSsettings = true
					end
					XETTINGS_LoadingThemesText = ContextMenuItemSelected
				end

				-- XETTINGS configuration: Theme preview mode
				if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xettingsconf_themepreview" then
					if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
						changedXETTINGSsettings = true
					end
					XETTINGS_ThemePreviewMode = ContextMenuItemSelected
				end

				-- XETTINGS configuration: Configure Exit to browser
				if SubMenuItem[SubMenuItemSelected].ContextMenuID == "xettingsconf_exittobrowser" then
					if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
						changedXETTINGSsettings = true
					end
					XETTINGS_ExitToBrowser = ContextMenuItemSelected
					XETTINGS_UpdateExitToBrowserItem()
				end

				XEBKeepInContextMenu="exit"
			end
			if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
				if ContextMenuItemSelected > 1 then
					ContextMenuItemSelected=ContextMenuItemSelected-1
					xetContextMenu_GetTempScrollingValues()
				end
			end
			if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
				if ContextMenuItemSelected < ContextMenuItemTotal then
					ContextMenuItemSelected=ContextMenuItemSelected+1
					xetContextMenu_GetTempScrollingValues()
				end
			end
			if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
				XEBKeepInContextMenu="exit"
			end
			OldContextMenuItemSelected = ContextMenuItemSelected

			Screen.waitVblankStart()
			oldpad = pad
			Screen.flip()
		end
		if XEBKeepInContextMenu == "exit" then
			for move = 1, 10 do
				pad = Pads.get()
				Screen.clear()
				xetSubMenu_DrawXEBUIInSubMenu()
				spinDisc()
				thmDrawBKGOL()

				moveb=move*25
				movec=move*31
		
				for i = 1, howMuchRedrawTransparencyLayer do
					Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255-moveb)
				end
				----------------------------------------------------------------------------
				Graphics.drawImageExtended(themeInUse[-5], 542+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
				Graphics.drawImageExtended(themeInUse[-4], 542+movec, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
				for ItemToDraw = ItemNrFirst,ItemNrLast do
					TempItemY=ItemToDraw*24-AdjustItemY-8
					Font.ftPrint(fontSmall, 400+movec, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
				end
				Font.ftPrint(fontSmall, 400+movec, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)

				if ContextMenu[0].Warning ~= nil then
					Graphics.drawRect(198, 420, 342, 80, Color.new(220,0,0,100-move*9))
					Font.ftPrint(fontSmall, 30, plusYValue+383, 0, 512, 64, ContextMenu[0].Warning, Color.new(255,255,255,128-move*12))
				end
				----------------------------------------------------------------------------
				Screen.waitVblankStart()
				oldpad = pad
				Screen.flip()
			end
		end
		ContextMenu = nil
		pad = Pads.get()
		Screen.clear()
		xetSubMenu_DrawXEBUIInSubMenu()
	elseif Pads.check(pad, PAD_UP) then
		if not Pads.check(oldpad, PAD_UP) then
			if SubMenuItemSelected ~= 1 then
				SubMenu_HoldingUp=1
				SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1
				xetSubMenu_AnimateUp()
				SubMenuItemSelected = SubMenuItemSelected - 1
			end
		elseif SubMenu_HoldingUp==17 and Pads.check(oldpad, PAD_UP) then
			if SubMenuItemSelected ~= 1 then
				SubMenu_HoldingUp=1
				SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1
				xetSubMenu_AnimateUp()
				SubMenuItemSelected = SubMenuItemSelected - 1
			end
		elseif SubMenu_HoldingUpDash>1 and Pads.check(oldpad, PAD_UP) then
			if SubMenuItemSelected ~= 1 then
				SubMenu_HoldingUp=1
				SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1
				xetSubMenu_AnimateUp()
				SubMenuItemSelected = SubMenuItemSelected - 1
			end
		end
		SubMenu_HoldingUp=SubMenu_HoldingUp+1
	elseif Pads.check(pad, PAD_DOWN) then
		if not Pads.check(oldpad, PAD_DOWN) then
			if SubMenuItemSelected ~= SubMenuItemTotal then
				SubMenu_HoldingDown=1
				SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1
				xetSubMenu_AnimateDown()
				SubMenuItemSelected = SubMenuItemSelected + 1
			end
		elseif SubMenu_HoldingDown==17 and Pads.check(oldpad, PAD_DOWN) then
			if SubMenuItemSelected ~= SubMenuItemTotal then
				SubMenu_HoldingUp=1
				SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1
				xetSubMenu_AnimateDown()
				SubMenuItemSelected = SubMenuItemSelected + 1
			end
		elseif SubMenu_HoldingDownDash>1 and Pads.check(oldpad, PAD_DOWN) then
			if SubMenuItemSelected ~= SubMenuItemTotal then
				SubMenu_HoldingDown=1
				SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1
				xetSubMenu_AnimateDown()
				SubMenuItemSelected = SubMenuItemSelected + 1
			end
		end
		SubMenu_HoldingDown=SubMenu_HoldingDown+1
	elseif Pads.check(pad, PAD_LEFT) and not Pads.check(oldpad, PAD_LEFT) then
		XEBKeepInSubMenu=false
	end
	if not Pads.check(pad, PAD_UP) then
		SubMenu_HoldingUp=99
		SubMenu_HoldingUpDash=0
	end
	if not Pads.check(pad, PAD_DOWN) then
		SubMenu_HoldingDown=99
		SubMenu_HoldingDownDash=0
	end
	if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
		XEBKeepInSubMenu=false
	end
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end

for SubMenu_i = 1, 3 do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ReverseFrame=4-SubMenu_i
	SubMenu_ItemPosition = -5
	for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
		SubMenu_iB_Y = SubMenu_ItemPosition*71
		if SubMenu_iB == SubMenuItemSelected then
			xetSubMenu_DrawItemFrame(152, 206, false, SubMenuItem[SubMenu_iB].Name, SubMenu_ReverseFrame, baseColorFull, SubMenu_ColorFullZero, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		else
			xetSubMenu_DrawItemFrame(152, SubMenu_iB_Y+135, true, SubMenuItem[SubMenu_iB].Name, SubMenu_ReverseFrame, baseColorFaded, SubMenu_ColorFadedZero, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		end
		SubMenu_ItemPosition=SubMenu_ItemPosition+1
	end
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end

TempSubMenuStore = nil

BackFromSubMenuIcon(actualCat,actualOption,true)
pad = Pads.get()
Screen.clear()
if backgroundFilter then
	Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
else
	Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
end
thmDrawBKG()
DrawInterface(actualCat,actualOption,true)
spinDisc()
thmDrawBKGOL()
oldpad = pad

if changedXEBsettings then saveXEBCNF() end
if changedXBLsettings then saveXBLCNF() end
if changedXETTINGSsettings then saveXETTINGSCNF() end