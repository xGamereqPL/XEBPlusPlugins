-- fadeToBlack()
fadeToBlackItem()
if System.doesFileExist("XEBPLUS.ELF") then
    ElfToLaunch = "XEBPLUS.ELF"
elseif System.doesFileExist("XEBPLUS_XMAS.ELF") then
    ElfToLaunch = "XEBPLUS_XMAS.ELF"
elseif System.doesFileExist("mass:/XEBPLUS/XEBPLUS.ELF") then
    ElfToLaunch = "mass:/XEBPLUS/XEBPLUS.ELF"
elseif System.doesFileExist("mass:/XEBPLUS/XEBPLUS_XMAS.ELF") then
    ElfToLaunch = "mass:/XEBPLUS/XEBPLUS_XMAS.ELF"
elseif System.doesFileExist("mass:/PS2/XEBPLUS/XEBPLUS.ELF") then
    ElfToLaunch = "mass:/PS2/XEBPLUS/XEBPLUS.ELF"
elseif System.doesFileExist("mass:/PS2/XEBPLUS/XEBPLUS_XMAS.ELF") then
    ElfToLaunch = "mass:/PS2/XEBPLUS/XEBPLUS_XMAS.ELF"
end
LaunchELF(ElfToLaunch, 0, "Default", false, 1)