XEBKeepInApp=true
TransparencyAlpha=0
TempX=840
TempY=0
ContextMenu_AllItems=2
ContextMenu_SelectedItem=1
if XEBPlusLanguageEmulation == false then
    ContextMenu_SelectedItem = 1
end
if XEBPlusLanguageEmulation == true then
    ContextMenu_SelectedItem = 2
end

ContextMenu={};
ContextMenu[1] = {};
ContextMenu[1].Name = xetLang[7]
ContextMenu[2] = {};
ContextMenu[2].Name = xetLang[6]

while XEBKeepInApp do
    pad = Pads.get()
    Screen.clear()
    if backgroundFilter then
        Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
    else
        Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
    end
    thmDrawBKG()
    DrawInterface(actualCat,actualOption,true)
    spinDisc()
    thmDrawBKGOL()
    Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, TransparencyAlpha)
    ----------------------------------------------------------------------------
    if TempX >= 540 then
        TempX = TempX - 20
    end
    if TempX < 540 then
        TempX=540
    end
    if TransparencyAlpha <= 255 then
        TransparencyAlpha = TransparencyAlpha + 25
    end
    Graphics.drawImageExtended(themeInUse[-5], TempX, 240, 0, 0, 325, 480, 325, 480, 0, 255)
    TempY=8+ContextMenu_SelectedItem*28
    Graphics.drawImageExtended(themeInUse[-4], TempX, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
    for ItemToDraw = 1,ContextMenu_AllItems do
        TempY=ItemToDraw*28
        Font.ftPrint(fontXET, TempX-144, plusYValue+TempY, 0, 512, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
    end
    Font.ftPrint(fontSmall, TempX-144, plusYValue+330, 0, 512, 64, xetLang[15], Color.new(255,255,255,255))
    ----------------------------------------------------------------------------
    if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
        XEBKeepInApp=getOut
    end
    if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
        if ContextMenu_SelectedItem == 1 then
            XEBPlusLanguageEmulation = false
        end
        if ContextMenu_SelectedItem == 2 then
            XEBPlusLanguageEmulation = true
            System.setSystemLanguage(XEBTheLanguage);
            LoadInternalLanguage()
        end
        XEBKeepInApp=getOut
    end
    if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
        ContextMenu_SelectedItem = ContextMenu_SelectedItem - 1
        if ContextMenu_SelectedItem < 1 then
            ContextMenu_SelectedItem = ContextMenu_AllItems
        end
    end
    if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
        ContextMenu_SelectedItem = ContextMenu_SelectedItem + 1
        if ContextMenu_SelectedItem > ContextMenu_AllItems then
            ContextMenu_SelectedItem = 1
        end
    end
    Screen.waitVblankStart()
    oldpad = pad;
    Screen.flip()
end
while XEBKeepInApp == getOut do
    pad = Pads.get()
    Screen.clear()
    if backgroundFilter then
        Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
    else
        Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
    end
    thmDrawBKG()
    DrawInterface(actualCat,actualOption,true)
    spinDisc()
    thmDrawBKGOL()
    Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, TransparencyAlpha)
    if TempX <= 840 then
        TempX = TempX + 25
    end
    if TempX >= 840 then
        XEBKeepInApp = false
    end
    if TransparencyAlpha >= 0 then
        TransparencyAlpha = TransparencyAlpha - 32
    end
    if TransparencyAlpha <= 0 then
        TransparencyAlpha = 0
    end
    Graphics.drawImageExtended(themeInUse[-5], TempX, 240, 0, 0, 325, 480, 325, 480, 0, 255)
    TempY=8+ContextMenu_SelectedItem*28
    Graphics.drawImageExtended(themeInUse[-4], TempX, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
    for ItemToDraw = 1,ContextMenu_AllItems do
        TempY=ItemToDraw*28
        Font.ftPrint(fontXET, TempX-144, plusYValue+TempY, 0, 512, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
    end
    textToPrint=xetLang[15]
    Font.ftPrint(fontSmall, TempX-144, plusYValue+330, 0, 512, 64, textToPrint, Color.new(255,255,255,255))
    Screen.waitVblankStart()
    oldpad = pad;
    Screen.flip()
end
pad = Pads.get()
Screen.clear()
if backgroundFilter then
    Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
else
    Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
end
thmDrawBKG()
DrawInterface(actualCat,actualOption,true)
spinDisc()
thmDrawBKGOL()
oldpad = pad;

saveXEBCNF()