XEBKeepInApp=true
TransparencyAlpha=0
Timer1=0
TempX=840
TempY=32
listdir = System.listDirectory("THM/")
ContextMenu_AllItems=#listdir
ContextMenu = {};
for nr =1, #listdir do
    thmLoad = false
    tempFile="THM/"..listdir[nr].name.."/theme.lua"
    dofile(tempFile)
	ContextMenu[nr] = {};
	ContextMenu[nr].Name = thmName
    ContextMenu[nr].Folder = listdir[nr].name
    ContextMenu[nr].Version = thmVersion
    ContextMenu[nr].Author = thmCreator
    thmLoad = true
end
table.sort(ContextMenu, function (TempTabA, TempTabB) return TempTabA.Name < TempTabB.Name end)
ContextMenu_SelectedItem = 1
for nra =1, #listdir do
    if ContextMenu[nra].Folder == XEBPlusTheme then
        ContextMenu_SelectedItem = nra
    end
end
olditem=ContextMenu_SelectedItem

while XEBKeepInApp do
    pad = Pads.get()
    Screen.clear()
    if backgroundFilter then
        Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
    else
        Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
    end
    thmDrawBKG()
    DrawInterface(actualCat,actualOption,true)
    spinDisc()
    thmDrawBKGOL()
    Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, TransparencyAlpha)
    ----------------------------------------------------------------------------
    if TempX >= 540 then
        TempX = TempX - 20
    end
    if TempX < 540 then
        TempX=540
    end
    if TransparencyAlpha <= 255 then
        TransparencyAlpha = TransparencyAlpha + 25
    end
    Graphics.drawImageExtended(themeInUse[-5], TempX, 240, 0, 0, 325, 480, 325, 480, 0, 255)
    TempY=8+ContextMenu_SelectedItem*28
    if ContextMenu_SelectedItem >= 16 then
        TempA=ContextMenu_SelectedItem-15
        AdjustY=TempA*28
    else
        AdjustY=0
    end
    Graphics.drawImageExtended(themeInUse[-4], TempX, TempY-AdjustY, 0, 0, 310, 22, 310, 22, 0, 255)
    for ItemToDraw = 1,ContextMenu_AllItems do
        TempY=ItemToDraw*28-AdjustY
        Font.ftPrint(fontXET, TempX-144, plusYValue+TempY, 0, 512, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
    end
    TempXb=TempX*1.2
    textToPrint=xetLang[17]..ContextMenu[ContextMenu_SelectedItem].Author
    Font.ftPrint(fontSmall, 704-TempXb, plusYValue+360, 0, 340, 64, textToPrint, baseColorFull)
    textToPrint=xetLang[16]..ContextMenu[ContextMenu_SelectedItem].Folder
    Font.ftPrint(fontSmall, 704-TempXb, plusYValue+375, 0, 340, 64, textToPrint, baseColorFull)
    textToPrint=xetLang[18]..ContextMenu[ContextMenu_SelectedItem].Version
    Font.ftPrint(fontSmall, 704-TempXb, plusYValue+390, 0, 340, 64, textToPrint, baseColorFull)
    ----------------------------------------------------------------------------
    if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
        XEBKeepInApp=getOut
    end
    if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
        XEBPlusTheme=ContextMenu[ContextMenu_SelectedItem].Folder
        XEBKeepInApp=getOut
    end
    if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
        ContextMenu_SelectedItem = ContextMenu_SelectedItem - 1
        if ContextMenu_SelectedItem < 1 then
            ContextMenu_SelectedItem = ContextMenu_AllItems
        end
    end
    if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
        ContextMenu_SelectedItem = ContextMenu_SelectedItem + 1
        if ContextMenu_SelectedItem > ContextMenu_AllItems then
            ContextMenu_SelectedItem = 1
        end
    end
    if ContextMenu_SelectedItem == olditem then
        Timer1=Timer1+1
    else
        Timer1=0
    end
    if Timer1 == 16 then
        themeToUse=ContextMenu[ContextMenu_SelectedItem].Folder
        themeInUse[-8] = Graphics.loadImage("THM/"..themeToUse.."/thm_preview.png")
    end
    if Timer1 >= 18 then
        TempVar1=Timer1-18
        TempVar2=TempVar1*52
        if Timer1 >= 23 then
            Timer1 = 23
        end
        if TempVar2 >= 255 then
            TempVar2=255
        end
        Graphics.drawImageExtended(themeInUse[-8], 200, plusYValue+240, 0, 0, 352, 240, 352, 240, 0, TempVar2)
    end
    Screen.waitVblankStart()
    oldpad = pad;
    Screen.flip()
    olditem=ContextMenu_SelectedItem
end
while XEBKeepInApp == getOut do
    pad = Pads.get()
    Screen.clear()
    if backgroundFilter then
        Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
    else
        Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
    end
    thmDrawBKG()
    DrawInterface(actualCat,actualOption,true)
    spinDisc()
    thmDrawBKGOL()
    Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, TransparencyAlpha)
    if TempX <= 840 then
        TempX = TempX + 25
    end
    if TempX >= 840 then
        XEBKeepInApp = false
    end
    if TransparencyAlpha >= 0 then
        TransparencyAlpha = TransparencyAlpha - 32
    end
    if TransparencyAlpha <= 0 then
        TransparencyAlpha = 0
    end
    Graphics.drawImageExtended(themeInUse[-5], TempX, 240, 0, 0, 325, 480, 325, 480, 0, 255)
    TempY=8+ContextMenu_SelectedItem*28
    Graphics.drawImageExtended(themeInUse[-4], TempX, TempY-AdjustY, 0, 0, 310, 22, 310, 22, 0, 255)
    for ItemToDraw = 1,ContextMenu_AllItems do
        TempY=ItemToDraw*28-AdjustY
        Font.ftPrint(fontXET, TempX-144, plusYValue+TempY, 0, 512, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
    end
    TempXb=TempX*1.2
    textToPrint=xetLang[17]..ContextMenu[ContextMenu_SelectedItem].Author
    Font.ftPrint(fontSmall, 704-TempXb, plusYValue+360, 0, 340, 64, textToPrint, baseColorFull)
    textToPrint=xetLang[16]..ContextMenu[ContextMenu_SelectedItem].Folder
    Font.ftPrint(fontSmall, 704-TempXb, plusYValue+375, 0, 340, 64, textToPrint, baseColorFull)
    textToPrint=xetLang[18]..ContextMenu[ContextMenu_SelectedItem].Version
    Font.ftPrint(fontSmall, 704-TempXb, plusYValue+390, 0, 340, 64, textToPrint, baseColorFull)
    Screen.waitVblankStart()
    oldpad = pad;
    Screen.flip()
end
pad = Pads.get()
Screen.clear()
if backgroundFilter then
    Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
else
    Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
end
thmDrawBKG()
DrawInterface(actualCat,actualOption,true)
spinDisc()
thmDrawBKGOL()
oldpad = pad;

saveXEBCNF()