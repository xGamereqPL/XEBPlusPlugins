XETTINGS (1.1 - 22.04.2023)

- What is this?
XETTINGS is a plugin for XtremeEliteBoot+. Allows you to change XEB+ settings directly from the dashboard. This feature has been removed from the Xmas Showcase, but you can bring it back with this plugin.

- How to install it?
Extract content of XETTINGS_1.1.zip in the XEBPLUS folder.

- Warnings:
Use this plugin only with XEB+ Xmas Showcase.
Do not use this plugin if you run XEB+ from host:/ (PCSX2), it will corrupt the CFG file.
Exit to Browser only works on some console models (I can confirm it works on SCPH-50004 - ROMVER 1.70)
After changing the USB Drivers, the options save to mc?:/SYS-CONF/XBL.CNF (only if the SYS-CONF folder exists). In case of problems after changing the drivers, delete this file.

- Credits:
Plugin coded by: xGamer
Spanish translations: Howling Wolf & Chelsea
Portuguese translations: MayconTp, nuno6573