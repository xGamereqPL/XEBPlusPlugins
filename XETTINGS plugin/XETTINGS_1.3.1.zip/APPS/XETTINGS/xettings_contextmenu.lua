-- XETTINGS 1.3.1 [ContextMenu] by xGamereqPL

-- draw XEB+ interface
function xetContextMenu_drawXEBUI()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawInterface(actualCat,actualOption,true)
	spinDisc()
	thmDrawBKGOL()
end

-----------------------------------------------------------------
------------------- CONTEXT MENU OPTIONS LIST -------------------
-----------------------------------------------------------------

ContextMenu = nil
ContextMenu = {}
ContextMenuItemSelected = 1
changedXEBsettings = false
changedXETTINGSsettings = false
ContextMenu[0] = {}

if xebCath[actualCat].Option[actualOption].XETTINGSID == "buttons" then
	ContextMenu[0].UseDescriptions = true
	
	for i = 1, 2 do
		ContextMenu[i] = {}
	end

	ContextMenu[1].Name = xebLang[117]
	ContextMenu[1].Description = xetLang[9]
	ContextMenu[2].Name = xebLang[118]
	ContextMenu[2].Description = xetLang[8]

	if buttonSettings == "O" then
		ContextMenuItemSelected = 1
	else
		ContextMenuItemSelected = 2
	end
end

if xebCath[actualCat].Option[actualOption].XETTINGSID == "langsys" then
	ContextMenu[0].UseDescriptions = true

	for i = 1, 8 do
		ContextMenu[i] = {}
		ContextMenu[i].Description = xetLang[15]
	end

	ContextMenu[1].Name = xetLang[54]
	ContextMenu[2].Name = xetLang[55]
	ContextMenu[3].Name = xetLang[56]
	ContextMenu[4].Name = xetLang[57]
	ContextMenu[5].Name = xetLang[58]
	ContextMenu[6].Name = xetLang[59]
	ContextMenu[7].Name = xetLang[60]
	ContextMenu[8].Name = xetLang[61]

	if systemLanguage == 0 then
		ContextMenuItemSelected = 8
	else
		ContextMenuItemSelected = systemLanguage
	end
end

if xebCath[actualCat].Option[actualOption].XETTINGSID == "langemu" then
	ContextMenu[0].UseDescriptions = false
	
	for i = 1, 2 do
		ContextMenu[i] = {}
	end

	ContextMenu[1].Name = xetLang[7]
	ContextMenu[2].Name = xetLang[6]

	if XEBPlusLanguageEmulation then
		ContextMenuItemSelected = 2
	else
		ContextMenuItemSelected = 1
	end
end

if xebCath[actualCat].Option[actualOption].XETTINGSID == "theme" then
	ContextMenu[0].UseDescriptions = true

	if XETTINGS_LoadingThemesText == 1 then
		Screen.clear()
		xetContextMenu_drawXEBUI()
		Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[65].." (0%)", Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25)))
		Screen.waitVblankStart()
		Screen.flip()
		Screen.clear()
		xetContextMenu_drawXEBUI()
		Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[65].." (0%)", Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
		Screen.waitVblankStart()
		Screen.flip()
	end

	-- loading themes list
	themeslist = System.listDirectory("THM/")
	thmCounter = 0

	if XETTINGS_LoadingThemesText == 1 then
		Screen.clear()
		xetContextMenu_drawXEBUI()
		Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[65].." (1%)", Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75)))
		Screen.waitVblankStart()
		Screen.flip()
	end

	for i = 1, #themeslist do
		if XETTINGS_LoadingThemesText == 1 then
			Screen.clear()
			xetContextMenu_drawXEBUI()
			Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[65].." ("..1+XEBMathRound(i/#themeslist*98).."%)", infoColor)
			Screen.waitVblankStart()
			Screen.flip()
		end

		if string.sub(themeslist[i].name, 1, 1) ~= "." then
			tempThemeFile="THM/"..themeslist[i].name.."/theme.lua"
			if System.doesFileExist(tempThemeFile) then
				thmLoad = false
				dofile(tempThemeFile)
				if thmforXEBPlus == theXEBPlusVersion then
					thmCounter = thmCounter + 1
					ContextMenu[thmCounter] = {}
					ContextMenu[thmCounter].Name = thmName
					ContextMenu[thmCounter].Folder = themeslist[i].name
					ContextMenu[thmCounter].Description = xetLang[16]..themeslist[i].name.."\n"..xetLang[18]..thmVersion.."\n"..XETTINGS_CorrectTextLength(xetLang[17]..thmCreator)
				end
				thmLoad = true
			end
		end
	end

	Screen.clear()
	xetContextMenu_drawXEBUI()
	if XETTINGS_LoadingThemesText == 1 then
		Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[65].." (100%)", Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75)))
	end
	Screen.waitVblankStart()
	Screen.flip()
	-- text fade out continued in "opening context menu"

	table.sort(ContextMenu, function (TempTabA, TempTabB) return string.upper(TempTabA.Name) < string.upper(TempTabB.Name) end)

	ContextMenuItemSelected = 1
	for i = 1, #ContextMenu do
		if ContextMenu[i].Folder == XEBPlusTheme then
			ContextMenuItemSelected = i
		end
	end
	ThemePreviewLoaded = false
	ThemePreviewFile = nil
	ThemePreviewTimer = 0
end

if xebCath[actualCat].Option[actualOption].XETTINGSID == "videomode" then
	ContextMenu[0].UseDescriptions = true
	
	for i = 1, 2 do
		ContextMenu[i] = {}
		ContextMenu[i].Description = xetLang[49]
	end

	ContextMenu[1].Name = "NTSC"
	ContextMenu[2].Name = "PAL"

	if XEBVideoMode == "NTSC" then
		ContextMenuItemSelected = 1
	else
		ContextMenuItemSelected = 2
	end
end

if xebCath[actualCat].Option[actualOption].XETTINGSID == "childproof" then
	ContextMenu[0].UseDescriptions = true
	
	for i = 1, 2 do
		ContextMenu[i] = {}
	end

	ContextMenu[1].Name = xetLang[7]
	ContextMenu[1].Description = xetLang[52]

	ContextMenu[2].Name = xetLang[6]
	ContextMenu[2].Description = xetLang[52]

	if childproofMode then
		ContextMenuItemSelected = 2
	else
		ContextMenuItemSelected = 1
	end
end

ContextMenuItemTotal = #ContextMenu
OldContextMenuItemSelected = ContextMenuItemSelected
DefaultContextMenuItemSelected = ContextMenuItemSelected

-----------------------------------------------------------------
------------------------ CONTEXTMENU CODE -----------------------
-----------------------------------------------------------------

if ContextMenu[0].UseDescriptions then
	ContextMenuMaxItemsOnScreen = 13
	for i = 1, ContextMenuItemTotal do
		if ContextMenu[i].Description == nil then
			ContextMenu[i].Description = ""
		end
	end
else
	ContextMenuMaxItemsOnScreen = 19
	for i = 1, ContextMenuItemTotal do
		ContextMenu[i].Description = ""
	end
end

-- set video mode ("NTSC" or "PAL")
function XETTINGS_SetVideoMode(vmode)
	if vmode == "NTSC" then
		XEBVideoMode = "NTSC"
		Screen.setMode(NTSC, 704, 480)
        plusYValue=0
        maxYvalue=480
	elseif vmode == "PAL" then
		XEBVideoMode = "PAL"
		Screen.setMode(PAL, 704, 480)
		plusYValue=0
		maxYvalue=480
	end
    videoMode=XEBVideoMode
end

-- confirm video mode change (10 seconds)
function XETTINGS_ChangeVideoModeConfirm(modeid)
	-- set new video mode
	if modeid == 1 then
		XETTINGS_SetVideoMode("NTSC")
	else
		XETTINGS_SetVideoMode("PAL")
	end
    videoMode=XEBVideoMode

	-- opening animation
    for i = 1, 10 do
        pad = Pads.get()
        Screen.clear()

        ib=i*12
		ic=i*6
		
        xetContextMenu_drawXEBUI()
		
		for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		end
		
		Graphics.drawImageExtended(themeInUse[-5], 542, 240, 0, 0, 325, 480, 325, 480, 0, 255)
		Graphics.drawImageExtended(themeInUse[-4], 542, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
		for ItemToDraw = ItemNrFirst,ItemNrLast do
			TempItemY=ItemToDraw*24-AdjustItemY-8
			Font.ftPrint(fontSmall, 400, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
		end
		Font.ftPrint(fontSmall, 400, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
		
        for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, i*25)
		end
		
        Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,i*10))
        Graphics.drawRect(352, 82, 704, 2, Color.new(255,255,255,ib))
        Graphics.drawRect(352, 120, 704, 2, Color.new(255,255,255,ib))
        Graphics.drawRect(352, 200, 704, 2, Color.new(255,255,255,ib))
		Font.ftPrint(fontBig, 352, 102, 11, 512, 64, xetLang[46], Color.new(255,255,255,ib))
        Font.ftPrint(fontBig, 352, 140, 11, 512, 64, xetLang[47], Color.new(255,255,255,ic))
        Font.ftPrint(fontBig, 352, 170, 11, 512, 64, xetLang[48], Color.new(255,255,255,ib))
		
        Screen.waitVblankStart()
        Screen.flip()
        oldpad = pad
    end
	-- creating timer and variables
	VmodeTimer = Timer.new()
    vmodeConfirmSelectedItem=2
    keepInVmodeConfirmMenu=true
	-- confirm video mode screen (loop)
    while keepInVmodeConfirmMenu do
		pad = Pads.get()
        Screen.clear()

        waitingTime = Timer.getTime(VmodeTimer)
        if waitingTime >= 9000 then
            timeLeft="1"
		elseif waitingTime >= 8000 then
            timeLeft="2"
		elseif waitingTime >= 7000 then
            timeLeft="3"
        elseif waitingTime >= 6000 then
            timeLeft="4"
        elseif waitingTime >= 5000 then
            timeLeft="5"
        elseif waitingTime >= 4000 then
            timeLeft="6"
        elseif waitingTime >= 3000 then
            timeLeft="7"
        elseif waitingTime >= 2000 then
            timeLeft="8"
        elseif waitingTime >= 1000 then
            timeLeft="9"
        else
            timeLeft="10"
        end
        
		xetContextMenu_drawXEBUI()
        
		for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		end
		
		Graphics.drawImageExtended(themeInUse[-5], 542, 240, 0, 0, 325, 480, 325, 480, 0, 255)
		Graphics.drawImageExtended(themeInUse[-4], 542, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
		for ItemToDraw = ItemNrFirst,ItemNrLast do
			TempItemY=ItemToDraw*24-AdjustItemY-8
			Font.ftPrint(fontSmall, 400, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
		end
		Font.ftPrint(fontSmall, 400, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
		
        for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		end
		
        Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,100))
        Graphics.drawRect(352, 82, 704, 2, Color.new(255,255,255,128))
        Graphics.drawRect(352, 120, 704, 2, Color.new(255,255,255,128))
        Graphics.drawRect(352, 200, 704, 2, Color.new(255,255,255,128))
        Font.ftPrint(fontBig, 352, 102, 11, 512, 64, xetLang[46], Color.new(255,255,255,128))
        if vmodeConfirmSelectedItem == 1 then
            Font.ftPrint(fontBig, 352, 140, 11, 512, 64, xetLang[47], Color.new(255,255,255,128))
            Font.ftPrint(fontBig, 352, 170, 11, 512, 64, xetLang[48], Color.new(255,255,255,64))
        else
            Font.ftPrint(fontBig, 352, 140, 11, 512, 64, xetLang[47], Color.new(255,255,255,64))
            Font.ftPrint(fontBig, 352, 170, 11, 512, 64, xetLang[48], Color.new(255,255,255,128))
        end
        Font.ftPrint(fontBig, 352, 228, 11, 704, 64, xetLang[50]..timeLeft..xetLang[51], Color.new(255,255,255,128))
		
        if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
            vmodeConfirmSelectedItem=1
        end
        if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
            vmodeConfirmSelectedItem=2
        end
        if waitingTime >= 10000 then
            -- restore old video mode
			if DefaultContextMenuItemSelected == 1 then
				XETTINGS_SetVideoMode("NTSC")
			else
				XETTINGS_SetVideoMode("PAL")
			end
            keepInVmodeConfirmMenu=false
        end
        if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
            -- restore old video mode
			if DefaultContextMenuItemSelected == 1 then
				XETTINGS_SetVideoMode("NTSC")
			else
				XETTINGS_SetVideoMode("PAL")
			end
            keepInVmodeConfirmMenu=false
        end
        if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
            if vmodeConfirmSelectedItem == 2 then
                -- restore old video mode
				if DefaultContextMenuItemSelected == 1 then
					XETTINGS_SetVideoMode("NTSC")
				else
					XETTINGS_SetVideoMode("PAL")
				end
                keepInVmodeConfirmMenu=false
            else
                videoModeChanged = true
                keepInVmodeConfirmMenu=false
            end
        end
		
        Screen.waitVblankStart()
        Screen.flip()
        oldpad = pad
    end

	-- destroy timer, closing animation
    Timer.destroy(VmodeTimer)
    for i = 1, 10 do
        pad = Pads.get()
        Screen.clear()
        ib=i*12
        ic=i*6
        id=i*10
		moveb=i*25
		movec=i*31

		xetContextMenu_drawXEBUI()
		for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255-moveb)
		end
		
		Graphics.drawImageExtended(themeInUse[-5], 542+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
		Graphics.drawImageExtended(themeInUse[-4], 542+movec, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
		for ItemToDraw = ItemNrFirst,ItemNrLast do
			TempItemY=ItemToDraw*24-AdjustItemY-8
			Font.ftPrint(fontSmall, 400+movec, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
		end
		Font.ftPrint(fontSmall, 400+movec, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)

        for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255-moveb)
		end

        Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,100-id))
        Graphics.drawRect(352, 82, 704, 2, Color.new(255,255,255,128-ib))
        Graphics.drawRect(352, 120, 704, 2, Color.new(255,255,255,128-ib))
        Graphics.drawRect(352, 200, 704, 2, Color.new(255,255,255,128-ib))
        Font.ftPrint(fontBig, 352, 102, 11, 512, 64, xetLang[46], Color.new(255,255,255,128-ib))
        if vmodeConfirmSelectedItem == 1 then
            Font.ftPrint(fontBig, 352, 140, 11, 512, 64, xetLang[47], Color.new(255,255,255,128-ib))
            Font.ftPrint(fontBig, 352, 170, 11, 512, 64, xetLang[48], Color.new(255,255,255,64-ic))
        else
            Font.ftPrint(fontBig, 352, 140, 11, 512, 64, xetLang[47], Color.new(255,255,255,64-ic))
            Font.ftPrint(fontBig, 352, 170, 11, 512, 64, xetLang[48], Color.new(255,255,255,128-ib))
        end
		Font.ftPrint(fontBig, 352, 228, 11, 704, 64, xetLang[50].."0"..xetLang[51], Color.new(255,255,255,128-ib))
        Screen.waitVblankStart()
        Screen.flip()
        oldpad = pad
    end

	if videoModeChanged then
		return true
	else
		return false
	end
end

function xetContextMenu_GetTempScrollingValues()
	if ContextMenuItemSelected == ContextMenuItemTotal then
		AdjustItemY=(ContextMenuItemSelected-ContextMenuMaxItemsOnScreen+1)*24-24
		ItemNrFirst = 1 + ContextMenuItemSelected - ContextMenuMaxItemsOnScreen
		ItemNrLast = ContextMenuItemSelected
	elseif ContextMenuItemSelected >= ContextMenuMaxItemsOnScreen then
		AdjustItemY=(ContextMenuItemSelected-ContextMenuMaxItemsOnScreen+1)*24
		ItemNrFirst = 2 + ContextMenuItemSelected - ContextMenuMaxItemsOnScreen
		ItemNrLast = ContextMenuItemSelected + 1
	else
		AdjustItemY=0
		ItemNrFirst = 1
		ItemNrLast = ContextMenuMaxItemsOnScreen
	end
	if ContextMenuMaxItemsOnScreen > ContextMenuItemTotal then
		AdjustItemY=0
		ItemNrFirst = 1
		ItemNrLast = ContextMenuItemTotal
	end
end

-- opening context menu
xetContextMenu_GetTempScrollingValues()
XEBKeepInContextMenu="true"
for move = 1, 10 do
	pad = Pads.get()
	Screen.clear()
	xetContextMenu_drawXEBUI()

	moveb=move*25
	movec=310-move*31

	for i = 1, howMuchRedrawTransparencyLayer do
		Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, moveb)
	end
	
	Graphics.drawImageExtended(themeInUse[-5], 542+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
	Graphics.drawImageExtended(themeInUse[-4], 542+movec, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
	for ItemToDraw = ItemNrFirst,ItemNrLast do
		TempItemY=ItemToDraw*24-AdjustItemY-8
		Font.ftPrint(fontSmall, 400+movec, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
	end
	Font.ftPrint(fontSmall, 400+movec, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)

	if ContextMenu[0].Warning ~= nil then
		Graphics.drawRect(198, 420, 342, 80, Color.new(220,0,0,move*9))
		Font.ftPrint(fontSmall, 30, plusYValue+383, 0, 512, 64, ContextMenu[0].Warning, Color.new(255,255,255,move*12))
	end

	if xebCath[actualCat].Option[actualOption].XETTINGSID == "theme" and XETTINGS_LoadingThemesText == 1 then
		if (move == 1) then
			Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[65].." (100%)", Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
		elseif (move == 2) then
			Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[65].." (100%)", Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25)))
		end
	end
	
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end
-- context menu loop
while XEBKeepInContextMenu == "true" do
	pad = Pads.get()
	Screen.clear()
	xetContextMenu_drawXEBUI()
	
	for i = 1, howMuchRedrawTransparencyLayer do
		Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	end
	
	Graphics.drawImageExtended(themeInUse[-5], 542, 240, 0, 0, 325, 480, 325, 480, 0, 255)
	Graphics.drawImageExtended(themeInUse[-4], 542, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
	for ItemToDraw = ItemNrFirst,ItemNrLast do
		TempItemY=ItemToDraw*24-AdjustItemY-8
		Font.ftPrint(fontSmall, 400, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
	end
	Font.ftPrint(fontSmall, 400, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)

	if ContextMenu[0].Warning ~= nil then
		Graphics.drawRect(198, 420, 342, 80, Color.new(220,0,0,100))
		Font.ftPrint(fontSmall, 30, plusYValue+383, 0, 512, 64, ContextMenu[0].Warning, Color.new(255,255,255,128))
	end

	if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
		-- ACCEPT SETTINGS
		XEBKeepInContextMenu="exit"

		-- buttons layout
		if xebCath[actualCat].Option[actualOption].XETTINGSID == "buttons" then
			if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
				changedXEBsettings = true
			end
			if ContextMenuItemSelected == 1 then
				buttonSettings="O"
			else
				buttonSettings="X"
			end
		end

		-- language (system)
		if xebCath[actualCat].Option[actualOption].XETTINGSID == "langsys" then
			if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
				changedXEBsettings = true
			end
			if ContextMenuItemSelected == 8 then
				systemLanguage = 0
			else
				systemLanguage = ContextMenuItemSelected
			end
		end

		-- language emulation
		if xebCath[actualCat].Option[actualOption].XETTINGSID == "langemu" then
			if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
				changedXEBsettings = true
			end
			if ContextMenuItemSelected == 1 then
				XEBPlusLanguageEmulation = false
			else
				XEBPlusLanguageEmulation = true
			end
		end

		-- theme
		if xebCath[actualCat].Option[actualOption].XETTINGSID == "theme" then
			if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
				changedXEBsettings = true
			end
			XEBPlusTheme = ContextMenu[ContextMenuItemSelected].Folder
		end

		-- video mode
		if xebCath[actualCat].Option[actualOption].XETTINGSID == "videomode" then
			if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
				if XETTINGS_ChangeVideoModeConfirm(ContextMenuItemSelected) == true then
					changedXEBsettings = true
					XEBKeepInContextMenu="none"
				end
				pad = Pads.get()
				Screen.clear()
				xetContextMenu_drawXEBUI()
			end
		end

		-- childproof mode
		if xebCath[actualCat].Option[actualOption].XETTINGSID == "childproof" then
			if DefaultContextMenuItemSelected ~= ContextMenuItemSelected then
				changedXEBsettings = true
			end
			if ContextMenuItemSelected == 1 then
				childproofMode = false
			else
				childproofMode = true
			end
		end
	end
	if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
		if ContextMenuItemSelected > 1 then
			ContextMenuItemSelected=ContextMenuItemSelected-1
			xetContextMenu_GetTempScrollingValues()
		end
	end
	if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
		if ContextMenuItemSelected < ContextMenuItemTotal then
			ContextMenuItemSelected=ContextMenuItemSelected+1
			xetContextMenu_GetTempScrollingValues()
		end
	end
	if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
		XEBKeepInContextMenu="exit"
	end

	-- theme preview
	if xebCath[actualCat].Option[actualOption].XETTINGSID == "theme" and XETTINGS_ThemePreviewMode ~= 3 then
		if ContextMenuItemSelected == OldContextMenuItemSelected then
			if ThemePreviewTimer < 24 then
				ThemePreviewTimer=ThemePreviewTimer+1
			end
		else -- if changed item in last frame
			if ThemePreviewTimer < 0 then
				ThemePreviewTimer=ThemePreviewTimer+1
			end
			if not ThemePreviewLoaded then
				ThemePreviewTimer = 0
			end
			if ThemePreviewLoaded and not ThemePreviewFadesOut then
				ThemePreviewTimer = -3
				ThemePreviewFadesOut = true
			end
			if ThemePreviewLoaded and ThemePreviewTimer >= 0 then
				ThemePreviewLoaded = false
				Graphics.freeImage(ThemePreviewFile)
			end
		end
		if ThemePreviewTimer >= 0 then
			ThemePreviewFadesOut = false
		end
		if ThemePreviewTimer == 0 and ThemePreviewLoaded then
			ThemePreviewLoaded = false
			Graphics.freeImage(ThemePreviewFile)
		end
		if System.doesFileExist("THM/"..ContextMenu[ContextMenuItemSelected].Folder.."/thm_preview.png") then
			if XETTINGS_ThemePreviewMode == 1 and ThemePreviewTimer == 15 then
				Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[66], Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25)))
			elseif XETTINGS_ThemePreviewMode == 1 and ThemePreviewTimer == 16 then
				Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[66], Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
			elseif XETTINGS_ThemePreviewMode == 1 and ThemePreviewTimer == 17 then
				Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[66], Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75)))
			elseif ThemePreviewTimer == 18 then
				if XETTINGS_ThemePreviewMode == 1 then
					Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[66], infoColor)
				end
				ThemePreviewFile = Graphics.loadImage("THM/"..ContextMenu[ContextMenuItemSelected].Folder.."/thm_preview.png")
				ThemePreviewLoaded = true
			elseif XETTINGS_ThemePreviewMode == 1 and ThemePreviewTimer == 19 then
				Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[66], Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75)))
			elseif XETTINGS_ThemePreviewMode == 1 and ThemePreviewTimer == 20 then
				Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[66], Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
			elseif XETTINGS_ThemePreviewMode == 1 and ThemePreviewTimer == 21 then
				Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xetLang[66], Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25)))
			end
		end
		if ThemePreviewLoaded then
			if ThemePreviewTimer >= 20 then
				if ThemePreviewTimer < 23 then
					ThemePreviewAlpha = (ThemePreviewTimer-19)*64
				else
					ThemePreviewAlpha = 255
				end
				Graphics.drawImageExtended(ThemePreviewFile, 200, plusYValue+240, 0, 0, 352, 240, 352, 240, 0, ThemePreviewAlpha)
			elseif ThemePreviewTimer == -3 then
				Graphics.drawImageExtended(ThemePreviewFile, 200, plusYValue+240, 0, 0, 352, 240, 352, 240, 0, 192)
			elseif ThemePreviewTimer == -2 then
				Graphics.drawImageExtended(ThemePreviewFile, 200, plusYValue+240, 0, 0, 352, 240, 352, 240, 0, 128)
			elseif ThemePreviewTimer == -1 then
				Graphics.drawImageExtended(ThemePreviewFile, 200, plusYValue+240, 0, 0, 352, 240, 352, 240, 0, 64)
			end
		end
	end
	OldContextMenuItemSelected = ContextMenuItemSelected
	
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end
-- closing context menu
if XEBKeepInContextMenu == "exit" then
	for move = 1, 10 do
		pad = Pads.get()
		Screen.clear()
		xetContextMenu_drawXEBUI()

		moveb=move*25
		movec=move*31

		for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255-moveb)
		end
		
		Graphics.drawImageExtended(themeInUse[-5], 542+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
		Graphics.drawImageExtended(themeInUse[-4], 542+movec, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
		for ItemToDraw = ItemNrFirst,ItemNrLast do
			TempItemY=ItemToDraw*24-AdjustItemY-8
			Font.ftPrint(fontSmall, 400+movec, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
		end
		Font.ftPrint(fontSmall, 400+movec, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)

		if ContextMenu[0].Warning ~= nil then
			Graphics.drawRect(198, 420, 342, 80, Color.new(220,0,0,100-move*9))
			Font.ftPrint(fontSmall, 30, plusYValue+383, 0, 512, 64, ContextMenu[0].Warning, Color.new(255,255,255,128-move*12))
		end
		
		-- theme preview
		if xebCath[actualCat].Option[actualOption].XETTINGSID == "theme" and XETTINGS_ThemePreviewMode ~= 3 then
			if ThemePreviewLoaded then
				if move == 1 then
					Graphics.drawImageExtended(ThemePreviewFile, 200, plusYValue+240, 0, 0, 352, 240, 352, 240, 0, 192)
				elseif move == 2 then
					Graphics.drawImageExtended(ThemePreviewFile, 200, plusYValue+240, 0, 0, 352, 240, 352, 240, 0, 128)
				elseif move == 3 then
					Graphics.drawImageExtended(ThemePreviewFile, 200, plusYValue+240, 0, 0, 352, 240, 352, 240, 0, 64)
				elseif move == 4 then
					Graphics.freeImage(ThemePreviewFile)
					ThemePreviewFile = nil
					ThemePreviewLoaded = false
					ThemePreviewTimer = 0
					ThemePreviewFadesOut = false
				end
			end
		end

		Screen.waitVblankStart()
		oldpad = pad
		Screen.flip()
	end
end
ContextMenu = nil
pad = Pads.get()
Screen.clear()
xetContextMenu_drawXEBUI()
oldpad = pad

-- save configuration files
if changedXEBsettings then saveXEBCNF() end
if changedXETTINGSsettings then saveXETTINGSCNF() end