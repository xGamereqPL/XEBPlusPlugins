-- Context menu plugin (23.04.2023)
-- Created by: xGamer

XEBKeepInApp=true
TransparencyAlpha=0
TempX=850
TempY=32

-- CUSTOM SETTINGS
ContextMenu_AllItems=3
ContextMenu_SelectedItem=3
ContextMenu= {};
ContextMenu[1]= {};
ContextMenu[1].Name = "1.0.0";
ContextMenu[1].File = "mass:/XEBPLUS/APPS/OPL/OPL_1.0.0.ELF";
ContextMenu[2]= {};
ContextMenu[2].Name = "1.1.0";
ContextMenu[2].File = "mass:/XEBPLUS/APPS/OPL/OPL_1.1.0.ELF";
ContextMenu[3]= {};
ContextMenu[3].Name = "1.2.0 Beta";
ContextMenu[3].File = "mass:/XEBPLUS/APPS/OPL/OPL_1.2.0.ELF";

while XEBKeepInApp do
    pad = Pads.get()
    Screen.clear()
    if backgroundFilter then
        Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
    else
        Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
    end
    thmDrawBKG()
    DrawInterface(actualCat,actualOption,true)
    spinDisc()
    thmDrawBKGOL()
    for i = 1, howMuchRedrawTransparencyLayer do
        Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, TransparencyAlpha)
    end
    ----------------------------------------------------------------------------
    if TempX >= 560 then
        TempX = TempX - 20
    end
    if TransparencyAlpha <= 255 then
        TransparencyAlpha = TransparencyAlpha + 25
    end
    Graphics.drawImageExtended(themeInUse[-5], TempX, 240, 0, 0, 325, 480, 325, 480, 0, 255)
    TempY=8+ContextMenu_SelectedItem*24
    Graphics.drawImageExtended(themeInUse[-4], TempX, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
    for ItemToDraw = 1,ContextMenu_AllItems do
        TempY=ItemToDraw*24
        Font.ftPrint(fontSmall, TempX-144, plusYValue+TempY, 0, 140, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
    end
    ----------------------------------------------------------------------------
    if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
        XEBKeepInApp=getOut
    end
    if TempX <= 560 then
        if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
            for ContextMenu_WaveByeBye = 1, 25 do
                Screen.clear()
                if backgroundFilter then
                    Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
                else
                    Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
                end
                thmDrawBKG()
                DrawInterface(actualCat,actualOption,true)
                spinDisc()
                thmDrawBKGOL()
                for i = 1, howMuchRedrawTransparencyLayer do
                    Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, TransparencyAlpha)
                end
                Graphics.drawImageExtended(themeInUse[-5], TempX, 240, 0, 0, 325, 480, 325, 480, 0, 255)
                TempY=8+ContextMenu_SelectedItem*24
                Graphics.drawImageExtended(themeInUse[-4], TempX, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
                for ItemToDraw = 1,ContextMenu_AllItems do
                    TempY=ItemToDraw*24
                    Font.ftPrint(fontSmall, TempX-144, plusYValue+TempY, 0, 140, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
                end
                Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,ContextMenu_WaveByeBye*10))
                Screen.waitVblankStart()
                Screen.flip()
            end
            LaunchELF(ContextMenu[ContextMenu_SelectedItem].File, 0, "Default", false, 1)
        end
        if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
            ContextMenu_SelectedItem = ContextMenu_SelectedItem - 1
            if ContextMenu_SelectedItem < 1 then
                ContextMenu_SelectedItem = ContextMenu_AllItems
            end
        end
        if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
            ContextMenu_SelectedItem = ContextMenu_SelectedItem + 1
            if ContextMenu_SelectedItem > ContextMenu_AllItems then
                ContextMenu_SelectedItem = 1
            end
        end
    end
    Screen.waitVblankStart()
    oldpad = pad;
    Screen.flip()
end
while XEBKeepInApp == getOut do
    pad = Pads.get()
    Screen.clear()
    if backgroundFilter then
        Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
    else
        Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
    end
    thmDrawBKG()
    DrawInterface(actualCat,actualOption,true)
    spinDisc()
    thmDrawBKGOL()
    for i = 1, howMuchRedrawTransparencyLayer do
        Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, TransparencyAlpha)
    end
    if TempX <= 840 then
        TempX = TempX + 24
    end
    if TempX >= 840 then
        XEBKeepInApp = false
    end
    if TransparencyAlpha >= 0 then
        TransparencyAlpha = TransparencyAlpha - 32
    end
    if TransparencyAlpha <= 0 then
        TransparencyAlpha = 0
    end
    Graphics.drawImageExtended(themeInUse[-5], TempX, 240, 0, 0, 325, 480, 325, 480, 0, 255)
    TempY=8+ContextMenu_SelectedItem*24
    Graphics.drawImageExtended(themeInUse[-4], TempX, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
    for ItemToDraw = 1,ContextMenu_AllItems do
        TempY=ItemToDraw*24
        Font.ftPrint(fontSmall, TempX-144, plusYValue+TempY, 0, 140, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
    end
    Screen.waitVblankStart()
    oldpad = pad;
    Screen.flip()
end
pad = Pads.get()
Screen.clear()
if backgroundFilter then
    Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
else
    Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
end
thmDrawBKG()
DrawInterface(actualCat,actualOption,true)
spinDisc()
thmDrawBKGOL()
oldpad = pad;