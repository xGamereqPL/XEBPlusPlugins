-- ContextMenu plugin 1.3 by xGamereqPL
PluginData = {}
PluginData.Type = "LuaScript"
PluginData.Category = 6
PluginData.Name = "ContextMenu"
PluginData.Description = "Applications group"
PluginData.Icon = 49
PluginData.Safe = true
PluginData.ValueA = "mass:/XEBPLUS/APPS/ContextMenu/contextmenu.lua"
PluginData.ValueB = "APPS/ContextMenu/contextmenu.lua"
PluginData.ValueC = "NONE"

--[[
ContextMenu plugin 1.3 (2025-03-16)

ContextMenu plugin creates item in XEB+ interface, after selecting this item it goes into ContextMenu with more items.
You don't have to edit APPS/ContextMenu/contextmenu.lua, it automatically reads values from PLG file.

ContextMenu plugin supports 2 item types: ELF and LUA.

You can add descriptions to items in context menu, but remember to enable UseDescriptions in configuration and use \n for new line.

IOPReset, IOPDisc and Loader values are optional, only for ELF items.
If you set IOPReset/IOPDisc/Loader for ContextMenu, all items in this ContextMenu will use these settings,
but if any item in ContextMenu have custom IOPReset/IOPDisc/Loader, it will use its own settings.

# ContextMenu configuration:
 PluginData.ContextMenu = {}
 PluginData.ContextMenu[0] = {}
 PluginData.ContextMenu[0].Default = 1 ------------- item selected after opening context menu
 PluginData.ContextMenu[0].UseDescriptions = true -- enable or disable item descriptions at the bottom of the context menu
 PluginData.ContextMenu[0].IOPReset = "Default" ---- OPTIONAL: IOP reset method for all ELFs in context menu
 PluginData.ContextMenu[0].IOPDisc = false --------- OPTIONAL: load CDVD driver after IOP reset for all ELFs in context menu
 PluginData.ContextMenu[0].Loader = "Default" ------ OPTIONAL: ELF loader for all ELFs in context menu


# ELF item template:
 PluginData.ContextMenu[1] = {}
 PluginData.ContextMenu[1].Name = "App name" --------------------- item name
 PluginData.ContextMenu[1].Type = "ELF" -------------------------- item type
 PluginData.ContextMenu[1].Description = "App description" ------- OPTIONAL: item description
 PluginData.ContextMenu[1].Value = {"APPS/ContextMenu/APP.ELF"} -- file path
 PluginData.ContextMenu[1].IOPReset = "Default" ------------------ OPTIONAL: IOP reset method for this item
 PluginData.ContextMenu[1].IOPDisc = false ----------------------- OPTIONAL: load CDVD driver after IOP reset for this item
 PluginData.ContextMenu[1].Loader = "Default" -------------------- OPTIONAL: ELF loader for this item


# LUA item template:
 PluginData.ContextMenu[1] = {}
 PluginData.ContextMenu[1].Name = "App name" --------------------- item name
 PluginData.ContextMenu[1].Type = "LUA" -------------------------- item type
 PluginData.ContextMenu[1].Description = "App description" ------- OPTIONAL: item description
 PluginData.ContextMenu[1].Value = {"APPS/ContextMenu/APP.lua"} -- file path


Every item in ContextMenu can have multiple paths, for example:
 PluginData.ContextMenu[1].Value = {"APPS/ContextMenu/APP.lua", "mass:/XEBPLUS/APPS/ContextMenu/APP.lua"}
Alternative syntax:
 PluginData.ContextMenu[1].Value = {}
 PluginData.ContextMenu[1].Value[1] = "APPS/ContextMenu/APP.lua"
 PluginData.ContextMenu[1].Value[2] = "mass:/XEBPLUS/APPS/ContextMenu/APP.lua"
]]--

-- ContextMenu configuration
PluginData.ContextMenu = {}
PluginData.ContextMenu[0] = {}
PluginData.ContextMenu[0].Default = 1
PluginData.ContextMenu[0].UseDescriptions = true

PluginData.ContextMenu[1] = {}
PluginData.ContextMenu[1].Name = "Test script"
PluginData.ContextMenu[1].Type = "LUA"
PluginData.ContextMenu[1].Description = "Test lua script"
PluginData.ContextMenu[1].Value = {"APPS/ContextMenu/test.lua"}