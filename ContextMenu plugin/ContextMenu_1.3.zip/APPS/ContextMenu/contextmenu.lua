-- ContextMenu plugin 1.3 by xGamereqPL

-----------------------------------------------------------------
----------- LOADING CONTEXTMENU CONFIGURATION FROM PLG ----------
-----------------------------------------------------------------

ContextMenu = nil
ContextMenu = {}
ContextMenu = xebCath[actualCat].Option[actualOption].ContextMenu
ContextMenuItemTotal = #ContextMenu
ContextMenuItemSelected = ContextMenu[0].Default

-----------------------------------------------------------------
-------------------- CONTEXTMENU PLUGIN CODE --------------------
-----------------------------------------------------------------

if ContextMenu[0].UseDescriptions then
	ContextMenuMaxItemsOnScreen = 13
	for i = 1, ContextMenuItemTotal do
		if ContextMenu[i].Description == nil then
			ContextMenu[i].Description = ""
		end
	end
else
	ContextMenuMaxItemsOnScreen = 19
	for i = 1, ContextMenuItemTotal do
		ContextMenu[i].Description = ""
	end
end

function ContextMenu_drawXEBUI()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawInterface(actualCat,actualOption,true)
	spinDisc()
	thmDrawBKGOL()
end

function ContextMenu_fadeToBlack()
	for fade = 1, 25 do
		pad = Pads.get()
		Screen.clear()
		ContextMenu_drawXEBUI()
		for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		end
		----------------------------------------------------------------------------
		Graphics.drawImageExtended(themeInUse[-5], 542, 240, 0, 0, 325, 480, 325, 480, 0, 255)
		ContextMenu_GetTempScrollingValues()
		Graphics.drawImageExtended(themeInUse[-4], 542, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
		for ItemToDraw = ItemNrFirst,ItemNrLast do
			TempItemY=ItemToDraw*24-AdjustItemY-8
			Font.ftPrint(fontSmall, 400, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
		end
		Font.ftPrint(fontSmall, 400, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
		----------------------------------------------------------------------------
		Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,fade*10))
		Screen.waitVblankStart()
		oldpad = pad
		Screen.flip()
	end
end

function ContextMenu_VerifyThenLaunch(filesToLoad, tempIOPResetMethod, tempIOPDisc, tempELFLoader)
	fileToLoadAlt = "NONE"
	tmpid = 1
	while fileToLoadAlt == "NONE" and tmpid <= #filesToLoad do
		if filesToLoad[tmpid] ~= "NONE" and filesToLoad[tmpid] ~= "" and filesToLoad[tmpid] ~= nil then
			if System.doesFileExist(System.currentDirectory()..filesToLoad[tmpid]) then
				fileToLoadAlt = System.currentDirectory()..filesToLoad[tmpid]
			else
				if string.sub(filesToLoad[tmpid],3,3) == "?" then
					X_MCA = filesToLoad[tmpid]
					X_MCB = filesToLoad[tmpid]
					X_MCA = X_MCA:gsub("mc?", "mc0")
					X_MCB = X_MCB:gsub("mc?", "mc1")
					if System.doesFileExist(X_MCA) then
						fileToLoadAlt = X_MCA
					elseif System.doesFileExist(X_MCB) then
						fileToLoadAlt = X_MCB
					end
				elseif System.doesFileExist(filesToLoad[tmpid]) then
					fileToLoadAlt = filesToLoad[tmpid]
				end
			end
		end
		tmpid = tmpid + 1
	end
	if fileToLoadAlt ~= "NONE" then
		if tempELFLoader == "AlternativeA" then
			LaunchELFAltA(fileToLoadAlt,0)
		elseif tempELFLoader == "AlternativeB" then
			LaunchELFAltB(fileToLoadAlt,0)
		elseif tempELFLoader == "AlternativeC" then
			LaunchELFAltC(fileToLoadAlt,0)
		elseif tempELFLoader == "AlternativeD" then
			LaunchELF(fileToLoadAlt,0,tempIOPReset,tempIOPDisc, 2)
		elseif tempELFLoader == "Default" then
			LaunchELF(fileToLoadAlt,0,tempIOPReset,tempIOPDisc, 1)
		else
			if string.sub(tempELFLoader,1,11) == "Alternative" then
				TempErrorMessageID = 142
			else
				TempErrorMessageID = 143
			end
			LaunchELF(fileToLoadAlt,0,tempIOPReset,tempIOPDisc, 1)
		end
	else
		ShowError(xebLang[36])
		fadeFromBlack()
	end
end

function ContextMenu_VerifyThenLaunchLua(filesToLoad)
	fileToLoadAlt = "NONE"
	tmpid = 1

	while fileToLoadAlt == "NONE" and tmpid <= #filesToLoad do
		if filesToLoad[tmpid] ~= "NONE" and filesToLoad[tmpid] ~= "" and filesToLoad[tmpid] ~= nil then
			if System.doesFileExist(System.currentDirectory()..filesToLoad[tmpid]) then
				fileToLoadAlt = System.currentDirectory()..filesToLoad[tmpid]
			else
				if string.sub(filesToLoad[tmpid],3,3) == "?" then
					X_MCA = filesToLoad[tmpid]
					X_MCB = filesToLoad[tmpid]
					X_MCA = X_MCA:gsub("mc?", "mc0")
					X_MCB = X_MCB:gsub("mc?", "mc1")
					if System.doesFileExist(X_MCA) then
						fileToLoadAlt = X_MCA
					elseif System.doesFileExist(X_MCB) then
						fileToLoadAlt = X_MCB
					end
				elseif System.doesFileExist(filesToLoad[tmpid]) then
					fileToLoadAlt = filesToLoad[tmpid]
				end
			end
		end
		tmpid = tmpid + 1
	end

	if fileToLoadAlt ~= "NONE" then
		Screen.waitVblankStart()
		oldpad = pad
		Screen.flip()
		fileToLoadAlt = fileToLoadAlt:gsub("\\", "/")
		xebLua_AppWorkingPath,xebLua_AppFilename,xebLua_AppExtension=SplitPath(fileToLoadAlt)
		dofile(fileToLoadAlt)
	else
		fadeToBlack()
		ShowError(xebLang[36])
		fadeFromBlack()
	end
end

function ContextMenu_GetTempScrollingValues()
	if ContextMenuItemSelected == ContextMenuItemTotal then
		AdjustItemY=(ContextMenuItemSelected-ContextMenuMaxItemsOnScreen+1)*24-24
		ItemNrFirst = 1 + ContextMenuItemSelected - ContextMenuMaxItemsOnScreen
		ItemNrLast = ContextMenuItemSelected
	elseif ContextMenuItemSelected >= ContextMenuMaxItemsOnScreen then
		AdjustItemY=(ContextMenuItemSelected-ContextMenuMaxItemsOnScreen+1)*24
		ItemNrFirst = 2 + ContextMenuItemSelected - ContextMenuMaxItemsOnScreen
		ItemNrLast = ContextMenuItemSelected + 1
	else
		AdjustItemY=0
		ItemNrFirst = 1
		ItemNrLast = ContextMenuMaxItemsOnScreen
	end
	if ContextMenuMaxItemsOnScreen > ContextMenuItemTotal then
		AdjustItemY=0
		ItemNrFirst = 1
		ItemNrLast = ContextMenuItemTotal
	end
end

ContextMenu_GetTempScrollingValues()

XEBContextMenuDoFile=false
XEBKeepInContextMenu="true"
		
for move = 1, 10 do
	pad = Pads.get()
	Screen.clear()
	ContextMenu_drawXEBUI()

	moveb=move*25
	movec=310-move*31

	for i = 1, howMuchRedrawTransparencyLayer do
		Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, moveb)
	end
	----------------------------------------------------------------------------
	Graphics.drawImageExtended(themeInUse[-5], 542+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
	Graphics.drawImageExtended(themeInUse[-4], 542+movec, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
	for ItemToDraw = ItemNrFirst,ItemNrLast do
		TempItemY=ItemToDraw*24-AdjustItemY-8
		Font.ftPrint(fontSmall, 400+movec, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
	end
	Font.ftPrint(fontSmall, 400+movec, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
	----------------------------------------------------------------------------
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end
while XEBKeepInContextMenu == "true" do
	pad = Pads.get()
	Screen.clear()
	ContextMenu_drawXEBUI()
	for i = 1, howMuchRedrawTransparencyLayer do
		Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	end
	----------------------------------------------------------------------------
	Graphics.drawImageExtended(themeInUse[-5], 542, 240, 0, 0, 325, 480, 325, 480, 0, 255)
	Graphics.drawImageExtended(themeInUse[-4], 542, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
	for ItemToDraw = ItemNrFirst,ItemNrLast do
		TempItemY=ItemToDraw*24-AdjustItemY-8
		Font.ftPrint(fontSmall, 400, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
	end
	Font.ftPrint(fontSmall, 400, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
	----------------------------------------------------------------------------
	if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
		if ContextMenu[ContextMenuItemSelected].Type == "ELF" then
			ContextMenu_fadeToBlack()
			XEBKeepInContextMenu="none"

			-- IOP reset method
			if ContextMenu[ContextMenuItemSelected].IOPReset == nil and ContextMenu[0].IOPReset == nil then
				tempIOPResetMethod = "Default"
			elseif ContextMenu[0].IOPReset == nil then
				tempIOPResetMethod = ContextMenu[ContextMenuItemSelected].IOPReset
			else
				tempIOPResetMethod = ContextMenu[0].IOPReset
			end
			-- loader
			if ContextMenu[ContextMenuItemSelected].Loader == nil and ContextMenu[0].Loader == nil then
				tempLoader = "Default"
			elseif ContextMenu[0].Loader == nil then
				tempLoader = ContextMenu[ContextMenuItemSelected].Loader
			else
				tempLoader = ContextMenu[0].Loader
			end
			-- IOP disc
			if ContextMenu[ContextMenuItemSelected].IOPDisc == nil and ContextMenu[0].IOPDisc == nil then
				tempIOPDisc = false
			elseif ContextMenu[0].IOPDisc == nil then
				tempIOPDisc = ContextMenu[ContextMenuItemSelected].IOPDisc
			else
				tempIOPDisc = ContextMenu[0].IOPDisc
			end

			-- launch
			ContextMenu_VerifyThenLaunch(ContextMenu[ContextMenuItemSelected].Value, tempIOPResetMethod, tempIOPDisc, tempLoader)
		else
			XEBKeepInContextMenu="exit"
			XEBContextMenuDoFile=true
			XEBContextMenuDoFileB=ContextMenu[ContextMenuItemSelected].Value
		end
	end
	if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
		if ContextMenuItemSelected > 1 then
			ContextMenuItemSelected=ContextMenuItemSelected-1
			ContextMenu_GetTempScrollingValues()
		end
	end
	if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
		if ContextMenuItemSelected < ContextMenuItemTotal then
			ContextMenuItemSelected=ContextMenuItemSelected+1
			ContextMenu_GetTempScrollingValues()
		end
	end
	if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
		XEBKeepInContextMenu="exit"
	end
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end
if XEBKeepInContextMenu == "exit" then
	for move = 1, 10 do
		pad = Pads.get()
		Screen.clear()
		ContextMenu_drawXEBUI()
		
		moveb=move*25
		movec=move*31

		for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255-moveb)
		end
		----------------------------------------------------------------------------
		Graphics.drawImageExtended(themeInUse[-5], 542+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
		Graphics.drawImageExtended(themeInUse[-4], 542+movec, ContextMenuItemSelected*24+2-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
		for ItemToDraw = ItemNrFirst,ItemNrLast do
			TempItemY=ItemToDraw*24-AdjustItemY-8
			Font.ftPrint(fontSmall, 400+movec, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
		end
		Font.ftPrint(fontSmall, 400+movec, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
		----------------------------------------------------------------------------
		Screen.waitVblankStart()
		oldpad = pad
		Screen.flip()
	end
end
ContextMenu = nil
pad = Pads.get()
Screen.clear()
ContextMenu_drawXEBUI()
oldpad = pad

if XEBContextMenuDoFile then
	ContextMenu_VerifyThenLaunchLua(XEBContextMenuDoFileB)
end