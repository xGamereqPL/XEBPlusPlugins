-- SubMenu plugin 1.3 by xGamereqPL
-- Based on POPSY-X

GoToSubMenuIcon(actualCat,actualOption,true)
XEBKeepInSubMenu=true

-----------------------------------------------------------------
------------- LOADING SUBMENU CONFIGURATION FROM PLG ------------
-----------------------------------------------------------------

TempSubMenuStore = nil
TempSubMenuStore = xebCath[actualCat].Option[actualOption].SubMenu
SubMenuItemTotal = #TempSubMenuStore
SubMenuItemSelected = TempSubMenuStore[0].Default

SubMenuItem = nil
SubMenuItem = {}
for i = 1, #TempSubMenuStore do
	SubMenuItem[i] = {}
	SubMenuItem[i].IOPReset = xebCath[actualCat].Option[actualOption].IOPReset
	SubMenuItem[i].Loader = xebCath[actualCat].Option[actualOption].Loader
	SubMenuItem[i].IOPDisc = xebCath[actualCat].Option[actualOption].IOPDisc

	SubMenuItem[i] = TempSubMenuStore[i]

	if SubMenuItem[i].Comment == nil then
		SubMenuItem[i].Comment = "";
	end
	
	if SubMenuItem[i].Type == "ELF" or SubMenuItem[i].Type == "ContextMenu" then
		if SubMenuItem[i].IOPReset == nil or SubMenuItem[i].IOPReset == "" then
			SubMenuItem[i].IOPReset = "Default";
		end
		if SubMenuItem[i].Loader == nil or SubMenuItem[i].Loader == "" then
			SubMenuItem[i].Loader = "Default";
		end
		if SubMenuItem[i].IOPDisc == nil then
			SubMenuItem[i].IOPDisc = false;
		end
	end

	if SubMenuItem[i].Type == "ContextMenu" then
		for j = 1, #SubMenuItem[i].Value do
			if SubMenuItem[i].Value[j].Type == "ELF" then
				if SubMenuItem[i].Value[j].IOPReset == nil or SubMenuItem[i].Value[j].IOPReset == "" then
					SubMenuItem[i].Value[j].IOPReset = SubMenuItem[i].IOPReset;
				end
				if SubMenuItem[i].Value[j].Loader == nil or SubMenuItem[i].Value[j].Loader == "" then
					SubMenuItem[i].Value[j].Loader = SubMenuItem[i].Loader;
				end
				if SubMenuItem[i].Value[j].IOPDisc == nil then
					SubMenuItem[i].Value[j].IOPDisc = SubMenuItem[i].IOPDisc;
				end
			end
		end
	end
end

-----------------------------------------------------------------
---------------------- SUBMENU PLUGIN CODE ----------------------
-----------------------------------------------------------------

function SubMenu_DrawXEBUIInSubMenu()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ItemPosition = -5
	for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
		SubMenu_iB_Y = SubMenu_ItemPosition*71
		if SubMenu_iB == SubMenuItemSelected then
			SubMenu_DrawItem(152, 206, false, SubMenuItem[SubMenu_iB].Name, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		else
			SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, SubMenuItem[SubMenu_iB].Name, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		end
		SubMenu_ItemPosition=SubMenu_ItemPosition+1
	end
end

function SubMenu_BottomInfoText()
	Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
end

function SubMenu_DrawItem(SubMenu_TempX, SubMenu_TempY, SubMenu_TempFaded, SubMenu_TempName, SubMenu_TempIcon, SubMenu_TempDescription) -- int, int, boolean, string, string
	SubMenu_IconToDraw = SubMenu_TempIcon
	if SubMenu_TempFaded then
		if SubMenu_TempName ~= "" then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, columnsFade)
			if SubMenu_IconToDraw == SubMenu_TempIcon then
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFaded)
			else
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFaded)
			end
		end
		Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, baseColorFaded)
	else
		if SubMenu_TempName ~= "" then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY)
			if SubMenu_IconToDraw == SubMenu_TempIcon then
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFull)
			else
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFull)
			end
		end
		Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, baseColorFull)
	end
end

function SubMenu_DrawItemFrame(SubMenu_TempX, SubMenu_TempY, SubMenu_TempFaded, SubMenu_TempName, SubMenu_TempTheFrame, SubMenu_TempTheColorA, SubMenu_TempTheColorB, SubMenu_TempIcon, SubMenu_TempDescription) -- int, int, boolean/int, string, int, u32 color, u32 color, string
	SubMenu_IconToDraw = SubMenu_TempIcon
	if SubMenu_TempName ~= "" then
		if SubMenu_TempFaded == true then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMin(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == false then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMinMax(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == 2 then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMax(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == 3 then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMaxFade(SubMenu_TempTheFrame))
		end
		if SubMenu_IconToDraw == SubMenu_TempIcon then
			Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, SubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
		else
			Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, SubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
		end
	end
	Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, SubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
end

function SubMenu_ColorGetAnimationAlpha(SubMenu_TempFrame,SubMenu_TempColorA,SubMenu_TempColorB) -- int, u32 color, u32 color
	SubMenu_TempColorAA=Color.getA(SubMenu_TempColorA)
	SubMenu_TempColorBA=Color.getA(SubMenu_TempColorB)
	SubMenu_TempColorAR=Color.getR(SubMenu_TempColorA)
	SubMenu_TempColorBR=Color.getR(SubMenu_TempColorB)
	SubMenu_TempColorAG=Color.getG(SubMenu_TempColorA)
	SubMenu_TempColorBG=Color.getG(SubMenu_TempColorB)
	SubMenu_TempColorAB=Color.getB(SubMenu_TempColorA)
	SubMenu_TempColorBB=Color.getB(SubMenu_TempColorB)
	SubMenu_TempAlphaC=SubMenu_TempColorAA-SubMenu_TempColorBA
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC
	SubMenu_TempAlphaC=SubMenu_TempColorBA+SubMenu_TempAlphaC
	SubMenu_TempNextColorA=XEBMathRound(SubMenu_TempAlphaC)
	SubMenu_TempAlphaC=SubMenu_TempColorAR-SubMenu_TempColorBR
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC
	SubMenu_TempAlphaC=SubMenu_TempColorBR+SubMenu_TempAlphaC
	SubMenu_TempNextColorR=XEBMathRound(SubMenu_TempAlphaC)
	SubMenu_TempAlphaC=SubMenu_TempColorAG-SubMenu_TempColorBG
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC
	SubMenu_TempAlphaC=SubMenu_TempColorBG+SubMenu_TempAlphaC
	SubMenu_TempNextColorG=XEBMathRound(SubMenu_TempAlphaC)
	SubMenu_TempAlphaC=SubMenu_TempColorAB-SubMenu_TempColorBB
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC
	SubMenu_TempAlphaC=SubMenu_TempColorBB+SubMenu_TempAlphaC
	SubMenu_TempNextColorB=XEBMathRound(SubMenu_TempAlphaC)
	SubMenu_TempNewColor=Color.new(SubMenu_TempNextColorR,SubMenu_TempNextColorG,SubMenu_TempNextColorB,SubMenu_TempNextColorA)
	return SubMenu_TempNewColor
end

function SubMenu_SpriteGetAnimationAlphaMin(SubMenu_TempFrame)
	SubMenu_TempAlpha=columnsFade
	SubMenu_TempAlpha=SubMenu_TempAlpha/4
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha)
	return SubMenu_TempAlpha
end

function SubMenu_SpriteGetAnimationAlphaMax(SubMenu_TempFrame)
	SubMenu_TempAlpha=255
	SubMenu_TempAlpha=SubMenu_TempAlpha-columnsFade
	SubMenu_TempAlpha=SubMenu_TempAlpha/4
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha
	SubMenu_TempAlpha=columnsFade+SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha)
	return SubMenu_TempAlpha
end

function SubMenu_SpriteGetAnimationAlphaMaxFade(SubMenu_TempFrame)
	SubMenu_TempAlpha=columnsFade
	SubMenu_TempAlpha=SubMenu_TempAlpha-255
	SubMenu_TempAlpha=SubMenu_TempAlpha/4
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha
	SubMenu_TempAlpha=255+SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha)
	return SubMenu_TempAlpha
end

function SubMenu_SpriteGetAnimationAlphaMinMax(SubMenu_TempFrame)
	if SubMenu_TempFrame == 4 then
		SubMenu_TempAlpha=255
	else
		SubMenu_TempAlpha=SubMenu_TempFrame*64
	end
	return SubMenu_TempAlpha
end

SubMenu_ColorFullZero=Color.new(Color.getR(baseColorFull),Color.getG(baseColorFull),Color.getB(baseColorFull),0)
SubMenu_ColorFadedZero=Color.new(Color.getR(baseColorFaded),Color.getG(baseColorFaded),Color.getB(baseColorFaded),0)

for SubMenu_i = -7, 0 do
	SubMenuItem[SubMenu_i] = {}
	SubMenuItem[SubMenu_i].Name = ""
	SubMenuItem[SubMenu_i].Description = ""
end	
for SubMenu_i = SubMenuItemTotal+1, SubMenuItemTotal+7 do
	SubMenuItem[SubMenu_i] = {}
	SubMenuItem[SubMenu_i].Name = ""
	SubMenuItem[SubMenu_i].Description = ""
end

SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)

for SubMenu_i = 1, 3 do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ItemPosition = -5
	for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
		SubMenu_iB_Y = SubMenu_ItemPosition*71
		if SubMenu_iB == SubMenuItemSelected then
			SubMenu_DrawItemFrame(152, 206, false, SubMenuItem[SubMenu_iB].Name, SubMenu_i, baseColorFull, SubMenu_ColorFullZero, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		else
			SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135, true, SubMenuItem[SubMenu_iB].Name, SubMenu_i, baseColorFaded, SubMenu_ColorFadedZero, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		end
		SubMenu_ItemPosition=SubMenu_ItemPosition+1
	end
	spinDisc()
	thmDrawBKGOL()
	if SubMenu_i == 3 then
		Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
	end
	if SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" then
		if SubMenu_i == 1 then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
		elseif SubMenu_i == 2 then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
		else
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
		end
	end
	SubMenu_BottomInfoText()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end

SubMenu_HoldingUp=99
SubMenu_HoldingUpDash=0
SubMenu_HoldingDown=99
SubMenu_HoldingDownDash=0

function SubMenu_AnimateUp()
	spinDisc()
	thmDrawBKGOL()
	Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, infoColor)
	SubMenu_BottomInfoText()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
	for SubMenu_Move = 1, 3 do
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_PositionUp = XEBMathRound(SubMenu_Move * 17.75)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SubMenuItemSelected then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135+SubMenu_PositionUp, 3, SubMenuItem[SubMenu_iB].Name, SubMenu_Move, baseColorFaded, baseColorFull, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			elseif SubMenu_iB == SubMenuItemSelected-1 then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135+SubMenu_PositionUp, 2, SubMenuItem[SubMenu_iB].Name, SubMenu_Move, baseColorFull, baseColorFaded, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			else
				SubMenu_DrawItem(152, SubMenu_iB_Y+135+SubMenu_PositionUp, true, SubMenuItem[SubMenu_iB].Name, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		if SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" and SubMenuItem[SubMenuItemSelected-1].Type == "ContextMenu" then
			SubMenu_infoColor = infoColor
		elseif SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" and SubMenuItem[SubMenuItemSelected-1].Type ~= "ContextMenu" then
			if SubMenu_Move == 1 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			elseif SubMenu_Move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			end
		elseif SubMenuItem[SubMenuItemSelected].Type ~= "ContextMenu" and SubMenuItem[SubMenuItemSelected-1].Type == "ContextMenu" then
			if SubMenu_Move == 1 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			elseif SubMenu_Move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			end
		else
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)
		end
		
		SubMenu_BottomInfoText()
		if not Pads.check(pad, PAD_UP) then
			SubMenu_HoldingUp=99
			SubMenu_HoldingUpDash=0
		end
		if SubMenu_Move ~= 3 then
			spinDisc()
			thmDrawBKGOL()
			if SubMenu_Move == 1 then
				Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
			elseif SubMenu_Move == 3 then
				Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected-1].Comment, Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
			end
			SubMenu_BottomInfoText()
			Screen.waitVblankStart()
			oldpad = pad
			Screen.flip()
		end
	end
end

function SubMenu_AnimateDown()
	spinDisc()
	thmDrawBKGOL()
	Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, infoColor)
	SubMenu_BottomInfoText()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
	for SubMenu_Move = 1, 3 do
		SubMenu_MoveBack=4-SubMenu_Move
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_PositionDown = XEBMathRound(SubMenu_Move * 17.75)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SubMenuItemSelected then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135-SubMenu_PositionDown, 2, SubMenuItem[SubMenu_iB].Name, SubMenu_MoveBack, baseColorFull, baseColorFaded, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			elseif SubMenu_iB == SubMenuItemSelected+1 then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135-SubMenu_PositionDown, 3, SubMenuItem[SubMenu_iB].Name, SubMenu_MoveBack, baseColorFaded, baseColorFull, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			else
				SubMenu_DrawItem(152, SubMenu_iB_Y+135-SubMenu_PositionDown, true, SubMenuItem[SubMenu_iB].Name, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		if SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" and SubMenuItem[SubMenuItemSelected+1].Type == "ContextMenu" then
			SubMenu_infoColor = infoColor
		elseif SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" and SubMenuItem[SubMenuItemSelected+1].Type ~= "ContextMenu" then
			if SubMenu_Move == 1 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			elseif SubMenu_Move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			end
		elseif SubMenuItem[SubMenuItemSelected].Type ~= "ContextMenu" and SubMenuItem[SubMenuItemSelected+1].Type == "ContextMenu" then
			if SubMenu_Move == 1 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			elseif SubMenu_Move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			end
		else
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)
		end
		
		SubMenu_BottomInfoText()
		if not Pads.check(oldpad, PAD_DOWN) then
			SubMenu_HoldingDown=99
			SubMenu_HoldingDownDash=0
		end
		if not Pads.check(pad, PAD_DOWN) then
			SubMenu_HoldingDown=99
			SubMenu_HoldingDownDash=0
		end
		if SubMenu_Move ~= 3 then
			spinDisc()
			thmDrawBKGOL()
			if SubMenu_Move == 1 then
				Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
			elseif SubMenu_Moev == 3 then
				Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected+1].Comment, Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
			end
			SubMenu_BottomInfoText()
			Screen.waitVblankStart()
			oldpad = pad
			Screen.flip()
		end
	end
end

function SubMenu_fadeToBlack()
	for SubMenu_WaveByeBye = 1, 25 do
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB ~= SubMenuItemSelected then
				SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, SubMenuItem[SubMenu_iB].Name, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		spinDisc()
		thmDrawBKGOL()
		Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, infoColor)
		SubMenu_BottomInfoText()
		Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,SubMenu_WaveByeBye*10))
		SubMenu_DrawItem(152, 206, false, SubMenuItem[SubMenuItemSelected].Name, SubMenuItem[SubMenuItemSelected].Icon, SubMenuItem[SubMenuItemSelected].Description)
		Screen.waitVblankStart()
		Screen.flip()
	end
	for SubMenu_WaveByeBye = 1, 25 do
		Screen.clear()
		SubMenu_DrawItem(152, 206, false, SubMenuItem[SubMenuItemSelected].Name, SubMenuItem[SubMenuItemSelected].Icon, SubMenuItem[SubMenuItemSelected].Description)
		Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,SubMenu_WaveByeBye*10))
		Screen.waitVblankStart()
		Screen.flip()
	end
end

function SubMenu_fadeFromBlack()
	for SubMenu_WaveByeBye = 1, 25 do
		Screen.clear()
		SubMenu_DrawXEBUIInSubMenu()
		spinDisc()
		thmDrawBKGOL()
		Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, infoColor)
		if SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" then
			SubMenu_infoColor = infoColor
		else
			SubMenu_infoColor = Color.new(0, 0, 0, 0)
		end
		SubMenu_BottomInfoText()
		Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,255-SubMenu_WaveByeBye*10))
		Screen.waitVblankStart()
		Screen.flip()
	end
end

function SubMenu_VerifyThenLaunch(filesToLoad, tempIOPReset, tempIOPDisc, tempELFLoader)
	fileToLoadAlt = "NONE"
	tmpid = 1
	while fileToLoadAlt == "NONE" and tmpid <= #filesToLoad do
		if filesToLoad[tmpid] ~= "NONE" and filesToLoad[tmpid] ~= "" and filesToLoad[tmpid] ~= nil then
			if System.doesFileExist(System.currentDirectory()..filesToLoad[tmpid]) then
				fileToLoadAlt = System.currentDirectory()..filesToLoad[tmpid]
			else
				if string.sub(filesToLoad[tmpid],3,3) == "?" then
					X_MCA = filesToLoad[tmpid]
					X_MCB = filesToLoad[tmpid]
					X_MCA = X_MCA:gsub("mc?", "mc0")
					X_MCB = X_MCB:gsub("mc?", "mc1")
					if System.doesFileExist(X_MCA) then
						fileToLoadAlt = X_MCA
					elseif System.doesFileExist(X_MCB) then
						fileToLoadAlt = X_MCB
					end
				elseif System.doesFileExist(filesToLoad[tmpid]) then
					fileToLoadAlt = filesToLoad[tmpid]
				end
			end
		end
		tmpid = tmpid + 1
	end
	TempErrorMessageID = 0
	if fileToLoadAlt ~= "NONE" then
		if tempELFLoader == "AlternativeA" then
			LaunchELFAltA(fileToLoadAlt,0)
		elseif tempELFLoader == "AlternativeB" then
			LaunchELFAltB(fileToLoadAlt,0)
		elseif tempELFLoader == "AlternativeC" then
			LaunchELFAltC(fileToLoadAlt,0)
		elseif tempELFLoader == "AlternativeD" then
			LaunchELF(fileToLoadAlt,0,tempIOPReset,tempIOPDisc, 2)
		elseif tempELFLoader == "Default" then
			LaunchELF(fileToLoadAlt,0,tempIOPReset,tempIOPDisc, 1)
		else
			if string.sub(tempELFLoader,1,11) == "Alternative" then
				TempErrorMessageID = 142
			else
				TempErrorMessageID = 143
			end
			LaunchELF(fileToLoadAlt,0,tempIOPReset,tempIOPDisc, 1)
		end
	else
		TempErrorMessageID = 36
	end
	if TempErrorMessageID ~= 0 then
		ShowError(xebLang[TempErrorMessageID])
	end
	TempErrorMessageID = 0
	SubMenu_fadeFromBlack()
end

function SubMenu_VerifyThenLaunchLua(filesToLoad)
	fileToLoadAlt = "NONE"
	tmpid = 1
	H_ShowTheError = 0

	while fileToLoadAlt == "NONE" and tmpid <= #filesToLoad do
		if filesToLoad[tmpid] ~= "NONE" and filesToLoad[tmpid] ~= "" and filesToLoad[tmpid] ~= nil then
			if System.doesFileExist(System.currentDirectory()..filesToLoad[tmpid]) then
				fileToLoadAlt = System.currentDirectory()..filesToLoad[tmpid]
			else
				if string.sub(filesToLoad[tmpid],3,3) == "?" then
					X_MCA = filesToLoad[tmpid]
					X_MCB = filesToLoad[tmpid]
					X_MCA = X_MCA:gsub("mc?", "mc0")
					X_MCB = X_MCB:gsub("mc?", "mc1")
					if System.doesFileExist(X_MCA) then
						fileToLoadAlt = X_MCA
					elseif System.doesFileExist(X_MCB) then
						fileToLoadAlt = X_MCB
					end
				elseif System.doesFileExist(filesToLoad[tmpid]) then
					fileToLoadAlt = filesToLoad[tmpid]
				end
			end
		end
		tmpid = tmpid + 1
	end

	if fileToLoadAlt ~= "NONE" then
		Screen.waitVblankStart()
		oldpad = pad
		Screen.flip()
		fileToLoadAlt = fileToLoadAlt:gsub("\\", "/")
		xebLua_AppWorkingPath,xebLua_AppFilename,xebLua_AppExtension=SplitPath(fileToLoadAlt)
		dofile(fileToLoadAlt)
	else
		fadeToBlack()
		ShowError(xebLang[36])
		SubMenu_fadeFromBlack()
	end
end

function ContextMenu_GetTempScrollingValues()
	if ContextMenuItemSelected == ContextMenuItemTotal then
		AdjustItemY=(ContextMenuItemSelected-ContextMenuMaxItemsOnScreen+1)*24-24
		ItemNrFirst = 1 + ContextMenuItemSelected - ContextMenuMaxItemsOnScreen
		ItemNrLast = ContextMenuItemSelected
	elseif ContextMenuItemSelected >= ContextMenuMaxItemsOnScreen then
		AdjustItemY=(ContextMenuItemSelected-ContextMenuMaxItemsOnScreen+1)*24
		ItemNrFirst = 2 + ContextMenuItemSelected - ContextMenuMaxItemsOnScreen
		ItemNrLast = ContextMenuItemSelected + 1
	else
		AdjustItemY=0
		ItemNrFirst = 1
		ItemNrLast = ContextMenuMaxItemsOnScreen
	end
	if ContextMenuMaxItemsOnScreen > ContextMenuItemTotal then
		AdjustItemY=0
		ItemNrFirst = 1
		ItemNrLast = ContextMenuItemTotal
	end
end

function SubMenu_fadeToBlackContextMenu()
	ContextMenu_GetTempScrollingValues()
	for fade = 1, 25 do
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		SubMenu_DrawXEBUIInSubMenu()
		spinDisc()
		thmDrawBKGOL()
		Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, infoColor)
		for i = 1, howMuchRedrawTransparencyLayer do
			Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		end
		Graphics.drawImageExtended(themeInUse[-5], 542, 240, 0, 0, 325, 480, 325, 480, 0, 255)
		TempItemY=ContextMenuItemSelected*24+2
		Graphics.drawImageExtended(themeInUse[-4], 542, TempItemY-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
		for ItemToDraw = ItemNrFirst,ItemNrLast do
			TempItemY=ItemToDraw*24-AdjustItemY-8
			Font.ftPrint(fontSmall, 400, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
		end
		Font.ftPrint(fontSmall, 400, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
		Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,fade*10))
		Screen.waitVblankStart()
		oldpad = pad
		Screen.flip()
	end
end

XEBSubMenuDoFile=false
while XEBKeepInSubMenu do
	pad = Pads.get()
	Screen.clear()
	SubMenu_DrawXEBUIInSubMenu()
	if SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" then
		SubMenu_infoColor = infoColor
	else
		SubMenu_infoColor = 0
	end
	if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
		if SubMenuItem[SubMenuItemSelected].Type == "ELF" then
			SubMenu_fadeToBlack()

			-- launch
			SubMenu_VerifyThenLaunch(SubMenuItem[SubMenuItemSelected].Value, SubMenuItem[SubMenuItemSelected].IOPReset, SubMenuItem[SubMenuItemSelected].IOPDisc, SubMenuItem[SubMenuItemSelected].Loader)
		elseif SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" then
			SubMenu_fadeToBlack()
			ContextMenuItemSelected = SubMenuItem[SubMenuItemSelected].Value[0].Default

			-- launch
			SubMenu_VerifyThenLaunch(SubMenuItem[SubMenuItemSelected].Value[ContextMenuItemSelected].Value, SubMenuItem[SubMenuItemSelected].Value[ContextMenuItemSelected].IOPReset, SubMenuItem[SubMenuItemSelected].Value[ContextMenuItemSelected].IOPDisc, SubMenuItem[SubMenuItemSelected].Value[ContextMenuItemSelected].Loader)
		elseif SubMenuItem[SubMenuItemSelected].Type == "LUA" then
			XEBSubMenuDoFile=true
			XEBSubMenuDoFileB=SubMenuItem[SubMenuItemSelected].Value
			XEBKeepInSubMenu=false
		end

		pad = Pads.get()
		Screen.clear()
		SubMenu_DrawXEBUIInSubMenu()
	elseif Pads.check(pad, PAD_SUBMEN) and not Pads.check(oldpad, PAD_SUBMEN) and SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" then
		-- CONTEXT MENU
		XEBKeepInContextMenu="true"

		ContextMenu = nil
		ContextMenu = {}
		ContextMenu = SubMenuItem[SubMenuItemSelected].Value
		ContextMenuItemTotal = #ContextMenu
		ContextMenuItemSelected = ContextMenu[0].Default

		if ContextMenu[0].UseDescriptions then
			ContextMenuMaxItemsOnScreen = 13
			for i = 1, ContextMenuItemTotal do
				if ContextMenu[i].Description == nil then
					ContextMenu[i].Description = ""
				end
			end
		else
			ContextMenuMaxItemsOnScreen = 19
			for i = 1, ContextMenuItemTotal do
				ContextMenu[i].Description = ""
			end
		end

		ContextMenu_GetTempScrollingValues()

		for move = 1, 10 do
			pad = Pads.get()
			Screen.clear()
			SubMenu_DrawXEBUIInSubMenu()
			spinDisc()
			thmDrawBKGOL()
			Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, infoColor)
			if move == 1 then
				SubMenu_infoColor = infoColor
			elseif move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			elseif move == 3 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			elseif move == 4 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)
			end
			SubMenu_BottomInfoText()
		
			moveb=move*25
			movec=310-move*31
		
			for i = 1, howMuchRedrawTransparencyLayer do
				Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, moveb)
			end
			----------------------------------------------------------------------------
			Graphics.drawImageExtended(themeInUse[-5], 542+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
			TempItemY=ContextMenuItemSelected*24+2
			Graphics.drawImageExtended(themeInUse[-4], 542+movec, TempItemY-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
			for ItemToDraw = ItemNrFirst,ItemNrLast do
				TempItemY=ItemToDraw*24-AdjustItemY-8
				Font.ftPrint(fontSmall, 400+movec, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
			end
			Font.ftPrint(fontSmall, 400+movec, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
			----------------------------------------------------------------------------
			Screen.waitVblankStart()
			oldpad = pad
			Screen.flip()
		end
		while XEBKeepInContextMenu == "true" do
			pad = Pads.get()
			Screen.clear()
			SubMenu_DrawXEBUIInSubMenu()
			spinDisc()
			thmDrawBKGOL()
			Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, infoColor)
			for i = 1, howMuchRedrawTransparencyLayer do
				Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
			end
			----------------------------------------------------------------------------
			Graphics.drawImageExtended(themeInUse[-5], 542, 240, 0, 0, 325, 480, 325, 480, 0, 255)
			TempItemY=ContextMenuItemSelected*24+2
			Graphics.drawImageExtended(themeInUse[-4], 542, TempItemY-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
			for ItemToDraw = ItemNrFirst,ItemNrLast do
				TempItemY=ItemToDraw*24-AdjustItemY-8
				Font.ftPrint(fontSmall, 400, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
			end
			Font.ftPrint(fontSmall, 400, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
			----------------------------------------------------------------------------
			if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
				if ContextMenu[ContextMenuItemSelected].Type == "ELF" then
					SubMenu_fadeToBlackContextMenu()
					XEBKeepInContextMenu="none"
		
					-- launch
					SubMenu_VerifyThenLaunch(ContextMenu[ContextMenuItemSelected].Value, ContextMenu[ContextMenuItemSelected].IOPReset, ContextMenu[ContextMenuItemSelected].IOPDisc, ContextMenu[ContextMenuItemSelected].Loader)
				else
					XEBKeepInContextMenu="exit"
					XEBKeepInSubMenu=false
					XEBSubMenuDoFile=true
					XEBSubMenuDoFileB=ContextMenu[ContextMenuItemSelected].Value
				end
			end
			if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
				if ContextMenuItemSelected > 1 then
					ContextMenuItemSelected=ContextMenuItemSelected-1
					ContextMenu_GetTempScrollingValues()
				end
			end
			if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
				if ContextMenuItemSelected < ContextMenuItemTotal then
					ContextMenuItemSelected=ContextMenuItemSelected+1
					ContextMenu_GetTempScrollingValues()
				end
			end
			if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
				XEBKeepInContextMenu="exit"
			end
			Screen.waitVblankStart()
			oldpad = pad
			Screen.flip()
		end
		if XEBKeepInContextMenu == "exit" then
			for move = 1, 10 do
				pad = Pads.get()
				Screen.clear()
				SubMenu_DrawXEBUIInSubMenu()
				spinDisc()
				thmDrawBKGOL()
				Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, infoColor)
				if move == 7 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
				elseif move == 8 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
				elseif move == 9 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
				elseif move == 10 then
					SubMenu_infoColor = infoColor
				else
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)
				end
				SubMenu_BottomInfoText()

				moveb=move*25
				movec=move*31
		
				for i = 1, howMuchRedrawTransparencyLayer do
					Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255-moveb)
				end
				----------------------------------------------------------------------------
				Graphics.drawImageExtended(themeInUse[-5], 542+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
				TempItemY=ContextMenuItemSelected*24+2
				Graphics.drawImageExtended(themeInUse[-4], 542+movec, TempItemY-AdjustItemY, 0, 0, 325, 22, 325, 22, 0, 255)
				for ItemToDraw = ItemNrFirst,ItemNrLast do
					TempItemY=ItemToDraw*24-AdjustItemY-8
					Font.ftPrint(fontSmall, 400+movec, plusYValue+TempItemY, 0, 300, 64, ContextMenu[ItemToDraw].Name, baseColorFull)
				end
				Font.ftPrint(fontSmall, 400+movec, plusYValue+360, 0, 300, 120, ContextMenu[ContextMenuItemSelected].Description, baseColorFull)
				----------------------------------------------------------------------------
				Screen.waitVblankStart()
				oldpad = pad
				Screen.flip()
			end
		end
		ContextMenu = nil
		pad = Pads.get()
		Screen.clear()
		SubMenu_DrawXEBUIInSubMenu()
	elseif Pads.check(pad, PAD_UP) then
		if not Pads.check(oldpad, PAD_UP) then
			if SubMenuItemSelected ~= 1 then
				SubMenu_HoldingUp=1
				SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1
				SubMenu_AnimateUp()
				SubMenuItemSelected = SubMenuItemSelected - 1
			end
		elseif SubMenu_HoldingUp==17 and Pads.check(oldpad, PAD_UP) then
			if SubMenuItemSelected ~= 1 then
				SubMenu_HoldingUp=1
				SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1
				SubMenu_AnimateUp()
				SubMenuItemSelected = SubMenuItemSelected - 1
			end
		elseif SubMenu_HoldingUpDash>1 and Pads.check(oldpad, PAD_UP) then
			if SubMenuItemSelected ~= 1 then
				SubMenu_HoldingUp=1
				SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1
				SubMenu_AnimateUp()
				SubMenuItemSelected = SubMenuItemSelected - 1
			end
		end
		SubMenu_HoldingUp=SubMenu_HoldingUp+1
	elseif Pads.check(pad, PAD_DOWN) then
		if not Pads.check(oldpad, PAD_DOWN) then
			if SubMenuItemSelected ~= SubMenuItemTotal then
				SubMenu_HoldingDown=1
				SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1
				SubMenu_AnimateDown()
				SubMenuItemSelected = SubMenuItemSelected + 1
			end
		elseif SubMenu_HoldingDown==17 and Pads.check(oldpad, PAD_DOWN) then
			if SubMenuItemSelected ~= SubMenuItemTotal then
				SubMenu_HoldingUp=1
				SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1
				SubMenu_AnimateDown()
				SubMenuItemSelected = SubMenuItemSelected + 1
			end
		elseif SubMenu_HoldingDownDash>1 and Pads.check(oldpad, PAD_DOWN) then
			if SubMenuItemSelected ~= SubMenuItemTotal then
				SubMenu_HoldingDown=1
				SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1
				SubMenu_AnimateDown()
				SubMenuItemSelected = SubMenuItemSelected + 1
			end
		end
		SubMenu_HoldingDown=SubMenu_HoldingDown+1
	elseif Pads.check(pad, PAD_LEFT) and not Pads.check(oldpad, PAD_LEFT) then
		XEBKeepInSubMenu=false
	end
	if not Pads.check(pad, PAD_UP) then
		SubMenu_HoldingUp=99
		SubMenu_HoldingUpDash=0
	end
	if not Pads.check(pad, PAD_DOWN) then
		SubMenu_HoldingDown=99
		SubMenu_HoldingDownDash=0
	end
	if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
		XEBKeepInSubMenu=false
	end
	spinDisc()
	thmDrawBKGOL()
	Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, infoColor)
	SubMenu_BottomInfoText()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end

for SubMenu_i = 1, 3 do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ReverseFrame=4-SubMenu_i
	SubMenu_ItemPosition = -5
	for SubMenu_iB = SubMenuItemSelected-6, SubMenuItemSelected+5 do
		SubMenu_iB_Y = SubMenu_ItemPosition*71
		if SubMenu_iB == SubMenuItemSelected then
			SubMenu_DrawItemFrame(152, 206, false, SubMenuItem[SubMenu_iB].Name, SubMenu_ReverseFrame, baseColorFull, SubMenu_ColorFullZero, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		else
			SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135, true, SubMenuItem[SubMenu_iB].Name, SubMenu_ReverseFrame, baseColorFaded, SubMenu_ColorFadedZero, SubMenuItem[SubMenu_iB].Icon, SubMenuItem[SubMenu_iB].Description)
		end
		SubMenu_ItemPosition=SubMenu_ItemPosition+1
	end
	spinDisc()
	thmDrawBKGOL()
	if SubMenu_i == 1 then
		Font.ftPrint(fontSmall, 26, 430, 0, 704, 64, SubMenuItem[SubMenuItemSelected].Comment, Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5)))
	end
	if SubMenuItem[SubMenuItemSelected].Type == "ContextMenu" then
		if SubMenu_i == 1 then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
		elseif SubMenu_i == 2 then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
		else
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
		end
	end
	SubMenu_BottomInfoText()
	Screen.waitVblankStart()
	oldpad = pad
	Screen.flip()
end

TempSubMenuStore = nil

BackFromSubMenuIcon(actualCat,actualOption,true)
pad = Pads.get()
Screen.clear()
if backgroundFilter then
	Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
else
	Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
end
thmDrawBKG()
DrawInterface(actualCat,actualOption,true)
spinDisc()
thmDrawBKGOL()
oldpad = pad

if XEBSubMenuDoFile then
	SubMenu_VerifyThenLaunchLua(XEBSubMenuDoFileB, XEBSubMenuDoFileB, XEBSubMenuDoFileB)
end