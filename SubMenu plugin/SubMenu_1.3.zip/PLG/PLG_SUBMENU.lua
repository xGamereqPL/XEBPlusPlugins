-- SubMenu plugin 1.3 by xGamereqPL
PluginData = {}
PluginData.Type = "LuaScript"
PluginData.Category = 3
PluginData.Name = "Sub Menu"
PluginData.Description = "SubMenu plugin"
PluginData.Icon = 49
PluginData.Safe = true
PluginData.ValueA = "mass:/XEBPLUS/APPS/SubMenu/submenu.lua"
PluginData.ValueB = "APPS/SubMenu/submenu.lua"
PluginData.ValueC = "NONE"

--[[
SubMenu plugin 1.3 (2025-03-16)

SubMenu plugin creates "submenu" item in XEB+ interface, after selecting this item it goes into submenu with more items.
You don't have to edit APPS/SubMenu/submenu.lua, it automatically reads values from this PLG file.

SubMenu plugin supports 3 item types: ELF, LUA, ContextMenu.
You can add comment (at left bottom screen corner) for every submenu item.

ContextMenu allows to create version selection for item, you can launch default app version or select version from context menu.
You can add descriptions to items in context menu, but remember to enable UseDescriptions in configuration and use \n for new line.
Context menu can be opened with triangle button.

IOPReset, IOPDisc and Loader values are optional, only for ELF items.
If you set IOPReset/IOPDisc/Loader for submenu item that is ContextMenu (Type = "ContextMenu"), all items in this ContextMenu
 will use these settings, but if any item in ContextMenu have custom IOPReset/IOPDisc/Loader, it will use its own settings.


# SubMenu configuration:
 PluginData.SubMenu = {}
 PluginData.SubMenu[0] = {}
 PluginData.SubMenu[0].Default = 1 - default item after opening submenu


# ELF item template:
 PluginData.SubMenu[1] = {}
 PluginData.SubMenu[1].Name = "App name" ----------------- item name
 PluginData.SubMenu[1].Type = "ELF" ---------------------- item type
 PluginData.SubMenu[1].Description = "App description" --- item description
 PluginData.SubMenu[1].Comment = "App comment" ----------- OPTIONAL: item comment
 PluginData.SubMenu[1].Icon = 81 ------------------------- item icon
 PluginData.SubMenu[1].Value = {"APPS/SubMenu/APP.ELF"} -- file path
 PluginData.SubMenu[1].IOPReset = "Default" -------------- OPTIONAL: IOP reset method
 PluginData.SubMenu[1].IOPDisc = false ------------------- OPTIONAL: load CDVD driver after IOP reset
 PluginData.SubMenu[1].Loader = "Default" ---------------- OPTIONAL: ELF loader


# LUA item template:
 PluginData.SubMenu[1] = {}
 PluginData.SubMenu[1].Name = "App name" ----------------- item name
 PluginData.SubMenu[1].Type = "LUA" ---------------------- item type
 PluginData.SubMenu[1].Description = "App description" --- item description
 PluginData.SubMenu[1].Comment = "App comment" ----------- OPTIONAL: item comment
 PluginData.SubMenu[1].Icon = 81 ------------------------- item icon
 PluginData.SubMenu[1].Value = {"APPS/SubMenu/APP.lua"} -- file path


# ContextMenu item template:
 PluginData.SubMenu[1] = {}
 PluginData.SubMenu[1].Name = "App name" -------------------------- item name
 PluginData.SubMenu[1].Type = "ContextMenu" ----------------------- item type
 PluginData.SubMenu[1].Description = "App description" ------------ item description
 PluginData.SubMenu[1].Comment = "App comment" -------------------- OPTIONAL: item comment
 PluginData.SubMenu[1].Icon = 81 ---------------------------------- item icon
 PluginData.SubMenu[1].Value = {}
 PluginData.SubMenu[1].Value[0] = {}
 PluginData.SubMenu[1].Value[0].Default = 1 ----------------------- item launched by default or selected after opening context menu
 PluginData.SubMenu[1].Value[0].UseDescriptions = true ------------ enable or disable item descriptions at the bottom of the context menu
 
 PluginData.SubMenu[1].IOPReset = "Default" ----------------------- OPTIONAL: IOP reset method for all ELFs in context menu
 PluginData.SubMenu[1].IOPDisc = false ---------------------------- OPTIONAL: load CDVD driver after IOP reset for all ELFs in context menu
 PluginData.SubMenu[1].Loader = "Default" ------------------------- OPTIONAL: ELF loader for all ELFs in context menu

 PluginData.SubMenu[1].Value[1] = {}
 PluginData.SubMenu[1].Value[1].Name = "default version" ---------- context menu item name
 PluginData.SubMenu[1].Value[1].Type = "LUA" ---------------------- context menu item type
 PluginData.SubMenu[1].Value[1].Description = "App description" --- OPTIONAL: context menu item description
 PluginData.SubMenu[1].Value[1].Value = {"APPS/SubMenu/APP.lua"} -- context menu item file path
 
 PluginData.SubMenu[1].Value[2] = {}
 PluginData.SubMenu[1].Value[2].Name = "beta version" ------------- context menu item name
 PluginData.SubMenu[1].Value[2].Type = "ELF" ---------------------- context menu item type
 PluginData.SubMenu[1].Value[2].Description = "App description" --- OPTIONAL: context menu item description
 PluginData.SubMenu[1].Value[2].Value = {"APPS/SubMenu/APP.elf"} -- context menu file path
 PluginData.SubMenu[1].Value[2].IOPReset = "Default" -------------- OPTIONAL: IOP reset method for this context menu item
 PluginData.SubMenu[1].Value[2].IOPDisc = false ------------------- OPTIONAL: load CDVD driver after IOP reset for this context menu item
 PluginData.SubMenu[1].Value[2].Loader = "Default" ---------------- OPTIONAL: ELF loader for this context menu item


Every item in SubMenu can have multiple paths, for example:
 PluginData.SubMenu[1].Value = {"APPS/SubMenu/APP.lua", "mass:/XEBPLUS/APPS/SubMenu/APP.lua"}
Alternative syntax:
 PluginData.SubMenu[1].Value = {}
 PluginData.SubMenu[1].Value[1] = "APPS/SubMenu/APP.lua"
 PluginData.SubMenu[1].Value[2] = "mass:/XEBPLUS/APPS/SubMenu/APP.lua"

Multiple paths in ContextMenu:
 PluginData.SubMenu[1].Value[1].Value = {"APPS/SubMenu/APP.lua", "mass:/XEBPLUS/APPS/SubMenu/APP.lua"}
Alternative syntax:
 PluginData.SubMenu[1].Value[1].Value = {}
 PluginData.SubMenu[1].Value[1].Value[1] = "APPS/SubMenu/APP.lua"
 PluginData.SubMenu[1].Value[1].Value[2] = "mass:/XEBPLUS/APPS/SubMenu/APP.lua"
]]--

-- SubMenu configuration
PluginData.SubMenu = {}
PluginData.SubMenu[0] = {}
PluginData.SubMenu[0].Default = 1

-- item 1
PluginData.SubMenu[1] = {}
PluginData.SubMenu[1].Name = "App"
PluginData.SubMenu[1].Type = "LUA"
PluginData.SubMenu[1].Description = "Description"
PluginData.SubMenu[1].Icon = 81
PluginData.SubMenu[1].Value = {"APPS/SubMenu/test.lua"}