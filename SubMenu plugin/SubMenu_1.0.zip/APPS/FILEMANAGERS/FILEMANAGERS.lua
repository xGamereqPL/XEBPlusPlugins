-- Simple submenu plugin created by xGamer
-- Based on POPSY-X

GoToSubMenuIcon(actualCat,actualOption,true)
XEBKeepInSubMenu=true

-- Plugin configuration - configure application names, descriptions, icons and file paths
SubMenu_SelectedItem=1 -- item selected after entering the submenu
SubMenu_AppsTotal = 3 -- total items count
SubMenu_Apps = {};
SubMenu_Apps[1] = {};
SubMenu_Apps[1].Name = "LaunchELF 4.43a";
SubMenu_Apps[1].File = "mass:/XEBPLUS/APPS/FILEMANAGERS/wLaunchELF.elf"
SubMenu_Apps[1].Description = "File manager"
SubMenu_Apps[1].Icon = 113
SubMenu_Apps[2] = {};
SubMenu_Apps[2].Name = "uLaunchELF kHn";
SubMenu_Apps[2].File = "mass:/XEBPLUS/APPS/FILEMANAGERS/uLE_kHn.ELF"
SubMenu_Apps[2].Description = "File manager with 2TB HDD support"
SubMenu_Apps[2].Icon = 118
SubMenu_Apps[3] = {};
SubMenu_Apps[3].Name = "wLaunchELF 4.43x_isr";
SubMenu_Apps[3].File = "mass:/XEBPLUS/APPS/FILEMANAGERS/wLE_ISR.ELF"
SubMenu_Apps[3].Description = "File manager with exFAT support"
SubMenu_Apps[3].Icon = 116

function SubMenu_DrawItem(SubMenu_TempX, SubMenu_TempY, SubMenu_TempFaded, SubMenu_TempName, SubMenu_TempIDDraw, SubMenu_TempType) -- int, int, boolean, string, string
	for TempNumber =1, SubMenu_AppsTotal do
		if SubMenu_TempName == SubMenu_Apps[TempNumber].Name then
			SubMenu_AppsDescription = SubMenu_Apps[TempNumber].Description
		end
	end
	for TempNumber =1, SubMenu_AppsTotal do
		if SubMenu_TempName == SubMenu_Apps[TempNumber].Name then
			SubMenu_AppsIcon = SubMenu_Apps[TempNumber].Icon
		end
	end
	if SubMenu_TempIDDraw == "default" then
		SubMenu_IconToDraw = SubMenu_AppsIcon;
	else
		SubMenu_IconToDraw = SubMenu_AppsIcon;
	end
 	SubMenu_TempAdd=""
	if SubMenu_TempFaded then
		if SubMenu_TempName ~= "" then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, columnsFade)
			if SubMenu_IconToDraw == SubMenu_AppsIcon then
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_AppsDescription, baseColorFaded)
			else
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_AppsDescription, baseColorFaded)
			end
		end
		Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, baseColorFaded)
	else
		for TempNumber =1, SubMenu_AppsTotal do
			if SubMenu_TempName == SubMenu_Apps[TempNumber].Name then
				SubMenu_AppsDescription = SubMenu_Apps[TempNumber].Description
			end
		end
		for TempNumber =1, SubMenu_AppsTotal do
			if SubMenu_TempName == SubMenu_Apps[TempNumber].Name then
				SubMenu_AppsIcon = SubMenu_Apps[TempNumber].Icon
			end
		end
		if SubMenu_TempName ~= "" then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY)
			if SubMenu_IconToDraw == SubMenu_AppsIcon then
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_AppsDescription, baseColorFull)
			else
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_AppsDescription, baseColorFull)
			end
		end
		Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, baseColorFull)
	end
end

function SubMenu_DrawItemFrame(SubMenu_TempX, SubMenu_TempY, SubMenu_TempFaded, SubMenu_TempName, SubMenu_TempTheFrame, SubMenu_TempTheColorA, SubMenu_TempTheColorB, SubMenu_TempIDDraw, SubMenu_TempDescription) -- int, int, boolean/int, string, int, u32 color, u32 color, string
	for TempNumber =1, SubMenu_AppsTotal do
		if SubMenu_TempName == SubMenu_Apps[TempNumber].Name then
			SubMenu_AppsDescription = SubMenu_Apps[TempNumber].Description
		end
	end
	for TempNumber =1, SubMenu_AppsTotal do
		if SubMenu_TempName == SubMenu_Apps[TempNumber].Name then
			SubMenu_AppsIcon = SubMenu_Apps[TempNumber].Icon
		end
	end
	if SubMenu_TempIDDraw == "default" then
		SubMenu_IconToDraw = SubMenu_AppsIcon;
	else
		SubMenu_IconToDraw = SubMenu_AppsIcon;
	end
	SubMenu_TempAdd=""
	if SubMenu_TempName ~= "" then
		if SubMenu_TempFaded == true then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMin(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == false then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMinMax(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == 2 then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMax(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == 3 then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMaxFade(SubMenu_TempTheFrame))
		end
		if SubMenu_IconToDraw == SubMenu_AppsIcon then
			Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_AppsDescription, SubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
		else
			Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_AppsDescription, SubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
		end
	end
	Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, SubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
end

function SubMenu_ColorGetAnimationAlpha(SubMenu_TempFrame,SubMenu_TempColorA,SubMenu_TempColorB) -- int, u32 color, u32 color
	SubMenu_TempColorAA=Color.getA(SubMenu_TempColorA);
	SubMenu_TempColorBA=Color.getA(SubMenu_TempColorB);
	SubMenu_TempColorAR=Color.getR(SubMenu_TempColorA);
	SubMenu_TempColorBR=Color.getR(SubMenu_TempColorB);
	SubMenu_TempColorAG=Color.getG(SubMenu_TempColorA);
	SubMenu_TempColorBG=Color.getG(SubMenu_TempColorB);
	SubMenu_TempColorAB=Color.getB(SubMenu_TempColorA);
	SubMenu_TempColorBB=Color.getB(SubMenu_TempColorB);
	SubMenu_TempAlphaC=SubMenu_TempColorAA-SubMenu_TempColorBA;
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4;
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC;
	SubMenu_TempAlphaC=SubMenu_TempColorBA+SubMenu_TempAlphaC
	SubMenu_TempNextColorA=XEBMathRound(SubMenu_TempAlphaC);
	SubMenu_TempAlphaC=SubMenu_TempColorAR-SubMenu_TempColorBR;
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4;
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC;
	SubMenu_TempAlphaC=SubMenu_TempColorBR+SubMenu_TempAlphaC
	SubMenu_TempNextColorR=XEBMathRound(SubMenu_TempAlphaC);
	SubMenu_TempAlphaC=SubMenu_TempColorAG-SubMenu_TempColorBG;
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4;
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC;
	SubMenu_TempAlphaC=SubMenu_TempColorBG+SubMenu_TempAlphaC
	SubMenu_TempNextColorG=XEBMathRound(SubMenu_TempAlphaC);
	SubMenu_TempAlphaC=SubMenu_TempColorAB-SubMenu_TempColorBB;
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4;
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC;
	SubMenu_TempAlphaC=SubMenu_TempColorBB+SubMenu_TempAlphaC
	SubMenu_TempNextColorB=XEBMathRound(SubMenu_TempAlphaC);
	SubMenu_TempNewColor=Color.new(SubMenu_TempNextColorR,SubMenu_TempNextColorG,SubMenu_TempNextColorB,SubMenu_TempNextColorA);
	return SubMenu_TempNewColor;
end

function SubMenu_SpriteGetAnimationAlphaMin(SubMenu_TempFrame)
	SubMenu_TempAlpha=columnsFade;
	SubMenu_TempAlpha=SubMenu_TempAlpha/4;
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha;
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha);
	return SubMenu_TempAlpha;
end

function SubMenu_SpriteGetAnimationAlphaMax(SubMenu_TempFrame)
	SubMenu_TempAlpha=255;
	SubMenu_TempAlpha=SubMenu_TempAlpha-columnsFade
	SubMenu_TempAlpha=SubMenu_TempAlpha/4;
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha;
	SubMenu_TempAlpha=columnsFade+SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha);
	return SubMenu_TempAlpha;
end

function SubMenu_SpriteGetAnimationAlphaMaxFade(SubMenu_TempFrame)
	SubMenu_TempAlpha=columnsFade;
	SubMenu_TempAlpha=SubMenu_TempAlpha-255
	SubMenu_TempAlpha=SubMenu_TempAlpha/4;
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha;
	SubMenu_TempAlpha=255+SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha);
	return SubMenu_TempAlpha;
end

function SubMenu_SpriteGetAnimationAlphaMinMax(SubMenu_TempFrame)
	if SubMenu_TempFrame == 4 then
		SubMenu_TempAlpha=255;
	else
		SubMenu_TempAlpha=SubMenu_TempFrame*64
	end
	return SubMenu_TempAlpha;
end

SubMenu_ColorFullZero=Color.new(Color.getR(baseColorFull),Color.getG(baseColorFull),Color.getB(baseColorFull),0)
SubMenu_ColorFadedZero=Color.new(Color.getR(baseColorFaded),Color.getG(baseColorFaded),Color.getB(baseColorFaded),0)

if not SubMenu_IsThereAnError then
	
	for SubMenu_i = -7, 0 do
		SubMenu_Apps[SubMenu_i] = {};
		SubMenu_Apps[SubMenu_i].Name = "";
		SubMenu_Apps[SubMenu_i].ID = "";
		SubMenu_Apps[SubMenu_i].Description = "";
	end
	
	for SubMenu_i = SubMenu_AppsTotal+1, SubMenu_AppsTotal+7 do
		SubMenu_Apps[SubMenu_i] = {};
		SubMenu_Apps[SubMenu_i].Name = "";
		SubMenu_Apps[SubMenu_i].ID = "";
		SubMenu_Apps[SubMenu_i].Description = "";
	end
end

for SubMenu_i = 1, 3 do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	
	if SubMenu_ShowError then
	else
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenu_SelectedItem-6, SubMenu_SelectedItem+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SubMenu_SelectedItem then
				SubMenu_DrawItemFrame(152, 206, false, SubMenu_Apps[SubMenu_iB].Name, SubMenu_i, baseColorFull, SubMenu_ColorFullZero, Direct_ELF, Direct_ELF)
			else
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135, true, SubMenu_Apps[SubMenu_iB].Name, SubMenu_i, baseColorFaded, SubMenu_ColorFadedZero, Direct_ELF, Direct_ELF)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
	end
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
end

SubMenu_HoldingUp=99
SubMenu_HoldingUpDash=0
SubMenu_HoldingDown=99
SubMenu_HoldingDownDash=0

function SubMenu_AnimateUp()
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
	for SubMenu_Move = 1, 3 do
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_PositionUp = XEBMathRound(SubMenu_Move * 17.75)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenu_SelectedItem-6, SubMenu_SelectedItem+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SubMenu_SelectedItem then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135+SubMenu_PositionUp, 3, SubMenu_Apps[SubMenu_iB].Name, SubMenu_Move, baseColorFaded, baseColorFull, Direct_ELF, Direct_ELF)
			elseif SubMenu_iB == SubMenu_SelectedItem-1 then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135+SubMenu_PositionUp, 2, SubMenu_Apps[SubMenu_iB].Name, SubMenu_Move, baseColorFull, baseColorFaded, Direct_ELF, Direct_ELF)
			else
				SubMenu_DrawItem(152, SubMenu_iB_Y+135+SubMenu_PositionUp, true, SubMenu_Apps[SubMenu_iB].Name, Direct_ELF, Direct_ELF)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		if not Pads.check(pad, PAD_UP) then
			SubMenu_HoldingUp=99
			SubMenu_HoldingUpDash=0
		end
		if SubMenu_Move ~= 3 then
			spinDisc()
			thmDrawBKGOL()
			Screen.waitVblankStart()
			oldpad = pad;
			Screen.flip()
		end
	end
end

function SubMenu_AnimateDown()
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
	for SubMenu_Move = 1, 3 do
		SubMenu_MoveBack=4-SubMenu_Move
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_PositionDown = XEBMathRound(SubMenu_Move * 17.75)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenu_SelectedItem-6, SubMenu_SelectedItem+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SubMenu_SelectedItem then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135-SubMenu_PositionDown, 2, SubMenu_Apps[SubMenu_iB].Name, SubMenu_MoveBack, baseColorFull, baseColorFaded, Direct_ELF, Direct_ELF)
			elseif SubMenu_iB == SubMenu_SelectedItem+1 then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135-SubMenu_PositionDown, 3, SubMenu_Apps[SubMenu_iB].Name, SubMenu_MoveBack, baseColorFaded, baseColorFull, Direct_ELF, Direct_ELF)
			else
				SubMenu_DrawItem(152, SubMenu_iB_Y+135-SubMenu_PositionDown, true, SubMenu_Apps[SubMenu_iB].Name, Direct_ELF, Direct_ELF)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		if not Pads.check(oldpad, PAD_DOWN) then
			SubMenu_HoldingDown=99
			SubMenu_HoldingDownDash=0
		end
		if not Pads.check(pad, PAD_DOWN) then
			SubMenu_HoldingDown=99
			SubMenu_HoldingDownDash=0
		end
		if SubMenu_Move ~= 3 then
			spinDisc()
			thmDrawBKGOL()
			Screen.waitVblankStart()
			oldpad = pad;
			Screen.flip()
		end
	end
end

while XEBKeepInSubMenu do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	
	if SubMenu_ShowError then
	else
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenu_SelectedItem-6, SubMenu_SelectedItem+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SubMenu_SelectedItem then
				SubMenu_DrawItem(152, 206, false, SubMenu_Apps[SubMenu_iB].Name, Direct_ELF, Direct_ELF)
			else
				SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, SubMenu_Apps[SubMenu_iB].Name, Direct_ELF, Direct_ELF)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
			for SubMenu_WaveByeBye = 1, 25 do
				Screen.clear()
				if backgroundFilter then
					Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
				else
					Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
				end
				thmDrawBKG()
				DrawSubMenu(actualCat,actualOption,true)
				SubMenu_ItemPosition = -5
				for SubMenu_iB = SubMenu_SelectedItem-6, SubMenu_SelectedItem+5 do
					SubMenu_iB_Y = SubMenu_ItemPosition*71
					if SubMenu_iB ~= SubMenu_SelectedItem then
						SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, SubMenu_Apps[SubMenu_iB].Name, Direct_ELF, Direct_ELF)
					end
					SubMenu_ItemPosition=SubMenu_ItemPosition+1
				end
				spinDisc()
				thmDrawBKGOL()
				Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,SubMenu_WaveByeBye*10))
				SubMenu_DrawItem(152, 206, false, SubMenu_Apps[SubMenu_SelectedItem].Name, Direct_ELF, Direct_ELF)
				Screen.waitVblankStart()
				Screen.flip()
			end
			for SubMenu_WaveByeBye = 1, 25 do
				Screen.clear()
				SubMenu_DrawItem(152, 206, false, SubMenu_Apps[SubMenu_SelectedItem].Name, Direct_ELF, Direct_ELF)
				Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,SubMenu_WaveByeBye*10))
				Screen.waitVblankStart()
				Screen.flip()
			end
			LaunchELF(SubMenu_Apps[SubMenu_SelectedItem].File, 0, "Default", false, 1)

		elseif Pads.check(pad, PAD_UP) then
			if not Pads.check(oldpad, PAD_UP) then
				if SubMenu_SelectedItem ~= 1 then
					SubMenu_HoldingUp=1;
					SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1;
					SubMenu_AnimateUp()
					SubMenu_SelectedItem = SubMenu_SelectedItem - 1
				end
			elseif SubMenu_HoldingUp==17 and Pads.check(oldpad, PAD_UP) then
				if SubMenu_SelectedItem ~= 1 then
					SubMenu_HoldingUp=1;
					SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1;
					SubMenu_AnimateUp()
					SubMenu_SelectedItem = SubMenu_SelectedItem - 1
				end
			elseif SubMenu_HoldingUpDash>1 and Pads.check(oldpad, PAD_UP) then
				if SubMenu_SelectedItem ~= 1 then
					SubMenu_HoldingUp=1;
					SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1;
					SubMenu_AnimateUp()
					SubMenu_SelectedItem = SubMenu_SelectedItem - 1
				end
			end
			SubMenu_HoldingUp=SubMenu_HoldingUp+1;
		elseif Pads.check(pad, PAD_DOWN) then
			if not Pads.check(oldpad, PAD_DOWN) then
				if SubMenu_SelectedItem ~= SubMenu_AppsTotal then
					SubMenu_HoldingDown=1;
					SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1;
					SubMenu_AnimateDown()
					SubMenu_SelectedItem = SubMenu_SelectedItem + 1
				end
			elseif SubMenu_HoldingDown==17 and Pads.check(oldpad, PAD_DOWN) then
				if SubMenu_SelectedItem ~= SubMenu_AppsTotal then
					SubMenu_HoldingUp=1;
					SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1;
					SubMenu_AnimateDown()
					SubMenu_SelectedItem = SubMenu_SelectedItem + 1
				end
			elseif SubMenu_HoldingDownDash>1 and Pads.check(oldpad, PAD_DOWN) then
				if SubMenu_SelectedItem ~= SubMenu_AppsTotal then
					SubMenu_HoldingDown=1;
					SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1;
					SubMenu_AnimateDown()
					SubMenu_SelectedItem = SubMenu_SelectedItem + 1
				end
			end
			SubMenu_HoldingDown=SubMenu_HoldingDown+1;
		elseif Pads.check(pad, PAD_LEFT) and not Pads.check(oldpad, PAD_LEFT) then
			XEBKeepInSubMenu=false
		end
		if not Pads.check(pad, PAD_UP) then
			SubMenu_HoldingUp=99
			SubMenu_HoldingUpDash=0
		end
		if not Pads.check(pad, PAD_DOWN) then
			SubMenu_HoldingDown=99
			SubMenu_HoldingDownDash=0
		end
	end
	if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
		XEBKeepInSubMenu=false
	end
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
end

for SubMenu_i = 1, 3 do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ReverseFrame=4-SubMenu_i
	if SubMenu_ShowError then
	else
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SubMenu_SelectedItem-6, SubMenu_SelectedItem+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SubMenu_SelectedItem then
				SubMenu_DrawItemFrame(152, 206, false, SubMenu_Apps[SubMenu_iB].Name, SubMenu_ReverseFrame, baseColorFull, SubMenu_ColorFullZero, Direct_ELF, Direct_ELF)
			else
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135, true, SubMenu_Apps[SubMenu_iB].Name, SubMenu_ReverseFrame, baseColorFaded, SubMenu_ColorFadedZero, Direct_ELF, Direct_ELF)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
	end
	spinDisc()
	thmDrawBKGOL()
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
end

BackFromSubMenuIcon(actualCat,actualOption,true)
pad = Pads.get()
Screen.clear()
if backgroundFilter then
	Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
else
	Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
end
thmDrawBKG()
DrawInterface(actualCat,actualOption,true)
spinDisc()
thmDrawBKGOL()
oldpad = pad;