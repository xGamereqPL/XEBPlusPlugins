fadeToBlackItem()
ShowMessage("Test script", "Test message")
fadeFromBlack()