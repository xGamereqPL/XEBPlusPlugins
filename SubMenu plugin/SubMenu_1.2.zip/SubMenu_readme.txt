XEB+ SubMenu Plugin by xGamer

This plugin allows you to create applications groups.
You can edit applications list by editing APPS/FILEMANAGERS/FILEMANAGERS.lua

---- Changelog:

1.0 (26.02.2023):
- first release (based on POPSY-X)

1.1 (28.03.2023):
- updated functions
- new script for loading icon/description (now it works the same as loading name)
- code cleanup (file is now 2 kB smaller, removed unused code fragments)

1.2 (19.05.2023):
- checking if file exist before launching
- added LuaScript support
- added MultiELF support (version selection)
- fixed small issues