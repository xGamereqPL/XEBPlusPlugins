-- SubMenu plugin created by xGamer (version 1.2)
-- Based on POPSY-X

GoToSubMenuIcon(actualCat,actualOption,true)
XEBKeepInSubMenu=true
Item = nil
Item = {};


-- Supported item types:
-- SingleELF [ELF file]
-- LuaScript [LUA file]
-- MultiELF [ELF file + version selection]


----------------------- CUSTOM SETTINGS -------------------------
SelectedItem=3 -- item selected by default after entering the submenu
Item[1] = {};
Item[1].Name = "LaunchELF 4.43a";
Item[1].Type = "SingleELF";
Item[1].Description = "File manager";
Item[1].Icon = 113
Item[1].Value = "APPS/FILEMANAGERS/wLE_443a.ELF";

Item[2] = {};
Item[2].Name = "uLaunchELF kHn";
Item[2].Type = "SingleELF";
Item[2].Description = "File manager by krHACKen";
Item[2].Icon = 118
Item[2].Value = "APPS/FILEMANAGERS/uLE_kHn.ELF";

Item[3] = {};
Item[3].Name = "wLaunchELF ISR";
Item[3].Type = "MultiELF";
Item[3].Description = "File manager by El_Isra";
Item[3].Icon = 116
Item[3].Value = {};
Item[3].Value[0] = {};
Item[3].Value[0].Max = 2
Item[3].Value[0].Default = 1
Item[3].Value[1] = {};
Item[3].Value[1].Name = "wLE 4.43x_ISR (exFAT)";
Item[3].Value[1].File = "APPS/FILEMANAGERS/wLE_ISR.ELF";
Item[3].Value[2] = {};
Item[3].Value[2].Name = "wLE 4.43x_ISR (exFAT + DS34 + MX4SIO)";
Item[3].Value[2].File = "APPS/FILEMANAGERS/wLE_ISR_DS34_MX4SIO.ELF";

ItemTotal = #Item

function SubMenu_DrawItem(SubMenu_TempX, SubMenu_TempY, SubMenu_TempFaded, SubMenu_TempName, SubMenu_TempIcon, SubMenu_TempDescription) -- int, int, boolean, string, string
	SubMenu_IconToDraw = SubMenu_TempIcon;
	if SubMenu_TempFaded then
		if SubMenu_TempName ~= "" then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, columnsFade)
			if SubMenu_IconToDraw == SubMenu_TempIcon then
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFaded)
			else
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFaded)
			end
		end
		Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, baseColorFaded)
	else
		if SubMenu_TempName ~= "" then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY)
			if SubMenu_IconToDraw == SubMenu_TempIcon then
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFull)
			else
				Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, baseColorFull)
			end
		end
		Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, baseColorFull)
	end
end

function SubMenu_DrawItemFrame(SubMenu_TempX, SubMenu_TempY, SubMenu_TempFaded, SubMenu_TempName, SubMenu_TempTheFrame, SubMenu_TempTheColorA, SubMenu_TempTheColorB, SubMenu_TempIcon, SubMenu_TempDescription) -- int, int, boolean/int, string, int, u32 color, u32 color, string
	SubMenu_IconToDraw = SubMenu_TempIcon;
	if SubMenu_TempName ~= "" then
		if SubMenu_TempFaded == true then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMin(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == false then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMinMax(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == 2 then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMax(SubMenu_TempTheFrame))
		elseif SubMenu_TempFaded == 3 then
			Graphics.drawImage(themeInUse[SubMenu_IconToDraw], SubMenu_TempX, plusYValue+SubMenu_TempY, SubMenu_SpriteGetAnimationAlphaMaxFade(SubMenu_TempTheFrame))
		end
		if SubMenu_IconToDraw == SubMenu_TempIcon then
			Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, SubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
		else
			Font.ftPrint(fontSmall, SubMenu_TempX+70, plusYValue+SubMenu_TempY+32, 0, 512, 64, SubMenu_TempDescription, SubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
		end
	end
	Font.ftPrint(fontBig, SubMenu_TempX+69, plusYValue+SubMenu_TempY+16, 0, 512, 64, SubMenu_TempName, SubMenu_ColorGetAnimationAlpha(SubMenu_TempTheFrame,SubMenu_TempTheColorA,SubMenu_TempTheColorB))
end

function SubMenu_ColorGetAnimationAlpha(SubMenu_TempFrame,SubMenu_TempColorA,SubMenu_TempColorB) -- int, u32 color, u32 color
	SubMenu_TempColorAA=Color.getA(SubMenu_TempColorA);
	SubMenu_TempColorBA=Color.getA(SubMenu_TempColorB);
	SubMenu_TempColorAR=Color.getR(SubMenu_TempColorA);
	SubMenu_TempColorBR=Color.getR(SubMenu_TempColorB);
	SubMenu_TempColorAG=Color.getG(SubMenu_TempColorA);
	SubMenu_TempColorBG=Color.getG(SubMenu_TempColorB);
	SubMenu_TempColorAB=Color.getB(SubMenu_TempColorA);
	SubMenu_TempColorBB=Color.getB(SubMenu_TempColorB);
	SubMenu_TempAlphaC=SubMenu_TempColorAA-SubMenu_TempColorBA;
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4;
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC;
	SubMenu_TempAlphaC=SubMenu_TempColorBA+SubMenu_TempAlphaC
	SubMenu_TempNextColorA=XEBMathRound(SubMenu_TempAlphaC);
	SubMenu_TempAlphaC=SubMenu_TempColorAR-SubMenu_TempColorBR;
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4;
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC;
	SubMenu_TempAlphaC=SubMenu_TempColorBR+SubMenu_TempAlphaC
	SubMenu_TempNextColorR=XEBMathRound(SubMenu_TempAlphaC);
	SubMenu_TempAlphaC=SubMenu_TempColorAG-SubMenu_TempColorBG;
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4;
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC;
	SubMenu_TempAlphaC=SubMenu_TempColorBG+SubMenu_TempAlphaC
	SubMenu_TempNextColorG=XEBMathRound(SubMenu_TempAlphaC);
	SubMenu_TempAlphaC=SubMenu_TempColorAB-SubMenu_TempColorBB;
	SubMenu_TempAlphaC=SubMenu_TempAlphaC/4;
	SubMenu_TempAlphaC=SubMenu_TempFrame*SubMenu_TempAlphaC;
	SubMenu_TempAlphaC=SubMenu_TempColorBB+SubMenu_TempAlphaC
	SubMenu_TempNextColorB=XEBMathRound(SubMenu_TempAlphaC);
	SubMenu_TempNewColor=Color.new(SubMenu_TempNextColorR,SubMenu_TempNextColorG,SubMenu_TempNextColorB,SubMenu_TempNextColorA);
	return SubMenu_TempNewColor;
end

function SubMenu_SpriteGetAnimationAlphaMin(SubMenu_TempFrame)
	SubMenu_TempAlpha=columnsFade;
	SubMenu_TempAlpha=SubMenu_TempAlpha/4;
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha;
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha);
	return SubMenu_TempAlpha;
end

function SubMenu_SpriteGetAnimationAlphaMax(SubMenu_TempFrame)
	SubMenu_TempAlpha=255;
	SubMenu_TempAlpha=SubMenu_TempAlpha-columnsFade
	SubMenu_TempAlpha=SubMenu_TempAlpha/4;
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha;
	SubMenu_TempAlpha=columnsFade+SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha);
	return SubMenu_TempAlpha;
end

function SubMenu_SpriteGetAnimationAlphaMaxFade(SubMenu_TempFrame)
	SubMenu_TempAlpha=columnsFade;
	SubMenu_TempAlpha=SubMenu_TempAlpha-255
	SubMenu_TempAlpha=SubMenu_TempAlpha/4;
	SubMenu_TempAlpha=SubMenu_TempFrame*SubMenu_TempAlpha;
	SubMenu_TempAlpha=255+SubMenu_TempAlpha
	SubMenu_TempAlpha=XEBMathRound(SubMenu_TempAlpha);
	return SubMenu_TempAlpha;
end

function SubMenu_SpriteGetAnimationAlphaMinMax(SubMenu_TempFrame)
	if SubMenu_TempFrame == 4 then
		SubMenu_TempAlpha=255;
	else
		SubMenu_TempAlpha=SubMenu_TempFrame*64
	end
	return SubMenu_TempAlpha;
end

SubMenu_ColorFullZero=Color.new(Color.getR(baseColorFull),Color.getG(baseColorFull),Color.getB(baseColorFull),0)
SubMenu_ColorFadedZero=Color.new(Color.getR(baseColorFaded),Color.getG(baseColorFaded),Color.getB(baseColorFaded),0)

for SubMenu_i = -7, 0 do
	Item[SubMenu_i] = {};
	Item[SubMenu_i].Name = "";
	Item[SubMenu_i].Description = "";
end	
for SubMenu_i = ItemTotal+1, ItemTotal+7 do
	Item[SubMenu_i] = {};
	Item[SubMenu_i].Name = "";
	Item[SubMenu_i].Description = "";
end

SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)

for SubMenu_i = 1, 3 do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ItemPosition = -5
	for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
		SubMenu_iB_Y = SubMenu_ItemPosition*71
		if SubMenu_iB == SelectedItem then
			SubMenu_DrawItemFrame(152, 206, false, Item[SubMenu_iB].Name, SubMenu_i, baseColorFull, SubMenu_ColorFullZero, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
		else
			SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, SubMenu_i, baseColorFaded, SubMenu_ColorFadedZero, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
		end
		SubMenu_ItemPosition=SubMenu_ItemPosition+1
	end
	spinDisc()
	thmDrawBKGOL()
	if Item[SelectedItem].Type == "MultiELF" then
		if SubMenu_i == 1 then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
		elseif SubMenu_i == 2 then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
		else
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
		end
	end
	Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
end

SubMenu_HoldingUp=99
SubMenu_HoldingUpDash=0
SubMenu_HoldingDown=99
SubMenu_HoldingDownDash=0

function SubMenu_AnimateUp()
	spinDisc()
	thmDrawBKGOL()
	Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
	for SubMenu_Move = 1, 3 do
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_PositionUp = XEBMathRound(SubMenu_Move * 17.75)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SelectedItem then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135+SubMenu_PositionUp, 3, Item[SubMenu_iB].Name, SubMenu_Move, baseColorFaded, baseColorFull, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
			elseif SubMenu_iB == SelectedItem-1 then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135+SubMenu_PositionUp, 2, Item[SubMenu_iB].Name, SubMenu_Move, baseColorFull, baseColorFaded, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
			else
				SubMenu_DrawItem(152, SubMenu_iB_Y+135+SubMenu_PositionUp, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		if Item[SelectedItem].Type == "MultiELF" and Item[SelectedItem-1].Type == "MultiELF" then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.99))
		elseif Item[SelectedItem].Type == "MultiELF" and Item[SelectedItem-1].Type ~= "MultiELF" then
			if SubMenu_Move == 1 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			elseif SubMenu_Move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			end
		elseif Item[SelectedItem].Type ~= "MultiELF" and Item[SelectedItem-1].Type == "MultiELF" then
			if SubMenu_Move == 1 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			elseif SubMenu_Move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			end
		else
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)
		end
		Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
		if not Pads.check(pad, PAD_UP) then
			SubMenu_HoldingUp=99
			SubMenu_HoldingUpDash=0
		end
		if SubMenu_Move ~= 3 then
			spinDisc()
			thmDrawBKGOL()
			Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
			Screen.waitVblankStart()
			oldpad = pad;
			Screen.flip()
		end
	end
end

function SubMenu_AnimateDown()
	spinDisc()
	thmDrawBKGOL()
	Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
	for SubMenu_Move = 1, 3 do
		SubMenu_MoveBack=4-SubMenu_Move
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_PositionDown = XEBMathRound(SubMenu_Move * 17.75)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SelectedItem then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135-SubMenu_PositionDown, 2, Item[SubMenu_iB].Name, SubMenu_MoveBack, baseColorFull, baseColorFaded, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
			elseif SubMenu_iB == SelectedItem+1 then
				SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135-SubMenu_PositionDown, 3, Item[SubMenu_iB].Name, SubMenu_MoveBack, baseColorFaded, baseColorFull, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
			else
				SubMenu_DrawItem(152, SubMenu_iB_Y+135-SubMenu_PositionDown, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
		if Item[SelectedItem].Type == "MultiELF" and Item[SelectedItem+1].Type == "MultiELF" then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.99))
		elseif Item[SelectedItem].Type == "MultiELF" and Item[SelectedItem+1].Type ~= "MultiELF" then
			if SubMenu_Move == 1 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			elseif SubMenu_Move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			end
		elseif Item[SelectedItem].Type ~= "MultiELF" and Item[SelectedItem+1].Type == "MultiELF" then
			if SubMenu_Move == 1 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			elseif SubMenu_Move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			end
		else
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)
		end
		Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
		if not Pads.check(oldpad, PAD_DOWN) then
			SubMenu_HoldingDown=99
			SubMenu_HoldingDownDash=0
		end
		if not Pads.check(pad, PAD_DOWN) then
			SubMenu_HoldingDown=99
			SubMenu_HoldingDownDash=0
		end
		if SubMenu_Move ~= 3 then
			spinDisc()
			thmDrawBKGOL()
			Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
			Screen.waitVblankStart()
			oldpad = pad;
			Screen.flip()
		end
	end
end

function SubMenu_VerifyThenLaunch(fileToLoad)
	fileToLoadB = "NONE"
	if fileToLoad ~= "NONE" and fileToLoad ~= "" and fileToLoad ~= nil then
		if string.sub(fileToLoad,4,4) ~= ":" and string.sub(fileToLoad,5,5) ~= ":" then
			if System.doesFileExist(System.currentDirectory()..fileToLoad) then
				fileToLoadB = System.currentDirectory()..fileToLoad;
			end
		else
			if string.sub(fileToLoad,3,3) == "?" then
				X_MCA = fileToLoad
				X_MCB = fileToLoad
				X_MCA = X_MCA:gsub("mc?", "mc0")
				X_MCB = X_MCB:gsub("mc?", "mc1")
				if System.doesFileExist(X_MCA) then
					fileToLoadB = X_MCA;
				elseif System.doesFileExist(X_MCB) then
					fileToLoadB = X_MCB;
				end
			elseif System.doesFileExist(fileToLoad) then
				fileToLoadB = fileToLoad;
			end
		end
	end
	if fileToLoadB ~= "NONE" then
		LaunchELF(fileToLoadB, 0, "Default", false, 1)
	else
		ShowError(xebLang[36])
		for SubMenu_WaveByeBye = 1, 25 do
			Screen.clear()
			if backgroundFilter then
				Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
			else
				Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
			end
			thmDrawBKG()
			DrawSubMenu(actualCat,actualOption,true)
			SubMenu_ItemPosition = -5
			for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
				SubMenu_iB_Y = SubMenu_ItemPosition*71
				if SubMenu_iB == SelectedItem then
					SubMenu_DrawItem(152, 206, false, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
				else
					SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
				end
				SubMenu_ItemPosition=SubMenu_ItemPosition+1
			end
			spinDisc()
			thmDrawBKGOL()
			if Item[SelectedItem].Type == "MultiELF" then
				if SubMenu_WaveByeBye == 22 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
				elseif SubMenu_WaveByeBye == 23 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
				elseif SubMenu_WaveByeBye == 24 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
				elseif SubMenu_WaveByeBye == 25 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.99))
				else
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)
				end
			end
			Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
			Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,255-SubMenu_WaveByeBye*10))
			Screen.waitVblankStart()
			Screen.flip()
		end
	end
end

XEBSubMenuDoFile=false
while XEBKeepInSubMenu do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ItemPosition = -5
	for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
		SubMenu_iB_Y = SubMenu_ItemPosition*71
		if SubMenu_iB == SelectedItem then
			SubMenu_DrawItem(152, 206, false, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
		else
			SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
		end
		SubMenu_ItemPosition=SubMenu_ItemPosition+1
	end
	if Item[SelectedItem].Type == "MultiELF" then
		SubMenu_infoColor = infoColor
	else
		SubMenu_infoColor = 0
	end
	if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
		if Item[SelectedItem].Type == "SingleELF" then
			for SubMenu_WaveByeBye = 1, 25 do
				Screen.clear()
				if backgroundFilter then
					Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
				else
					Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
				end
				thmDrawBKG()
				DrawSubMenu(actualCat,actualOption,true)
				SubMenu_ItemPosition = -5
				for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
					SubMenu_iB_Y = SubMenu_ItemPosition*71
					if SubMenu_iB ~= SelectedItem then
						SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
					end
					SubMenu_ItemPosition=SubMenu_ItemPosition+1
				end
				spinDisc()
				thmDrawBKGOL()
				Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
				Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,SubMenu_WaveByeBye*10))
				SubMenu_DrawItem(152, 206, false, Item[SelectedItem].Name, Item[SelectedItem].Icon, Item[SelectedItem].Description)
				Screen.waitVblankStart()
				Screen.flip()
			end
			for SubMenu_WaveByeBye = 1, 25 do
				Screen.clear()
				SubMenu_DrawItem(152, 206, false, Item[SelectedItem].Name, Item[SelectedItem].Icon, Item[SelectedItem].Description)
				Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,SubMenu_WaveByeBye*10))
				Screen.waitVblankStart()
				Screen.flip()
			end
			SubMenu_VerifyThenLaunch(Item[SelectedItem].Value)
		elseif Item[SelectedItem].Type == "MultiELF" then
			for SubMenu_WaveByeBye = 1, 25 do
				Screen.clear()
				if backgroundFilter then
					Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
				else
					Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
				end
				thmDrawBKG()
				DrawSubMenu(actualCat,actualOption,true)
				SubMenu_ItemPosition = -5
				for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
					SubMenu_iB_Y = SubMenu_ItemPosition*71
					if SubMenu_iB ~= SelectedItem then
						SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
					end
					SubMenu_ItemPosition=SubMenu_ItemPosition+1
				end
				spinDisc()
				thmDrawBKGOL()
				Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
				Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,SubMenu_WaveByeBye*10))
				SubMenu_DrawItem(152, 206, false, Item[SelectedItem].Name, Item[SelectedItem].Icon, Item[SelectedItem].Description)
				Screen.waitVblankStart()
				Screen.flip()
			end
			for SubMenu_WaveByeBye = 1, 25 do
				Screen.clear()
				SubMenu_DrawItem(152, 206, false, Item[SelectedItem].Name, Item[SelectedItem].Icon, Item[SelectedItem].Description)
				Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,SubMenu_WaveByeBye*10))
				Screen.waitVblankStart()
				Screen.flip()
			end
			ContextMenu_SelectedItem = Item[SelectedItem].Value[0].Default
			SubMenu_VerifyThenLaunch(Item[SelectedItem].Value[ContextMenu_SelectedItem].File)
		elseif Item[SelectedItem].Type == "LuaScript" then
			XEBSubMenuDoFile=true
			XEBSubMenuDoFileB=Item[SelectedItem].Value
			XEBKeepInSubMenu=false
		end
	elseif Pads.check(pad, PAD_SUBMEN) and not Pads.check(oldpad, PAD_SUBMEN) and Item[SelectedItem].Type == "MultiELF" then
		XEBKeepInContextMenu="true"

		-- CUSTOM SETTINGS
		ContextMenu_AllItems=Item[SelectedItem].Value[0].Max
		ContextMenu_SelectedItem=Item[SelectedItem].Value[0].Default
		ContextMenu = nil;
		ContextMenu= {};
		for i = 1, ContextMenu_AllItems do
			ContextMenu[i]= {};
			ContextMenu[i].Name = Item[SelectedItem].Value[i].Name
			ContextMenu[i].File = Item[SelectedItem].Value[i].File
		end
		
		for move = 1, 10 do
			pad = Pads.get()
			Screen.clear()
			if backgroundFilter then
				Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
			else
				Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
			end
			thmDrawBKG()
			DrawSubMenu(actualCat,actualOption,true)
			SubMenu_ItemPosition = -5
			for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
				SubMenu_iB_Y = SubMenu_ItemPosition*71
				if SubMenu_iB == SelectedItem then
					SubMenu_DrawItem(152, 206, false, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
				else
					SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
				end
				SubMenu_ItemPosition=SubMenu_ItemPosition+1
			end
			spinDisc()
			thmDrawBKGOL()
			if move == 1 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.99))
			elseif move == 2 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
			elseif move == 3 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
			elseif move == 4 then
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
			else
				SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)
			end
			Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
		
			moveb=move*25
			movec=310-move*31
		
			for i = 1, howMuchRedrawTransparencyLayer do
				Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, moveb)
			end
			----------------------------------------------------------------------------
			Graphics.drawImageExtended(themeInUse[-5], 549+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
			TempY=8+ContextMenu_SelectedItem*24
			Graphics.drawImageExtended(themeInUse[-4], 549+movec, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
			for ItemToDraw = 1,ContextMenu_AllItems do
				TempY=ItemToDraw*24
				Font.ftPrint(fontSmall, 408+movec, plusYValue+TempY, 0, 400, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
			end
			----------------------------------------------------------------------------
			Screen.waitVblankStart()
			oldpad = pad;
			Screen.flip()
		end
		while XEBKeepInContextMenu == "true" do
			pad = Pads.get()
			Screen.clear()
			if backgroundFilter then
				Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
			else
				Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
			end
			thmDrawBKG()
			DrawSubMenu(actualCat,actualOption,true)
			SubMenu_ItemPosition = -5
			for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
				SubMenu_iB_Y = SubMenu_ItemPosition*71
				if SubMenu_iB == SelectedItem then
					SubMenu_DrawItem(152, 206, false, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
				else
					SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
				end
				SubMenu_ItemPosition=SubMenu_ItemPosition+1
			end
			spinDisc()
			thmDrawBKGOL()
			for i = 1, howMuchRedrawTransparencyLayer do
				Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
			end
			----------------------------------------------------------------------------
			Graphics.drawImageExtended(themeInUse[-5], 549, 240, 0, 0, 325, 480, 325, 480, 0, 255)
			TempY=8+ContextMenu_SelectedItem*24
			Graphics.drawImageExtended(themeInUse[-4], 549, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
			for ItemToDraw = 1,ContextMenu_AllItems do
				TempY=ItemToDraw*24
				Font.ftPrint(fontSmall, 408, plusYValue+TempY, 0, 400, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
			end
			----------------------------------------------------------------------------
			if Pads.check(pad, PAD_ACCEPT) and not Pads.check(oldpad, PAD_ACCEPT) then
				for fade = 1, 25 do
					pad = Pads.get()
					Screen.clear()
					if backgroundFilter then
						Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
					else
						Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
					end
					thmDrawBKG()
					DrawSubMenu(actualCat,actualOption,true)
					SubMenu_ItemPosition = -5
					for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
						SubMenu_iB_Y = SubMenu_ItemPosition*71
						if SubMenu_iB == SelectedItem then
							SubMenu_DrawItem(152, 206, false, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
						else
							SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
						end
						SubMenu_ItemPosition=SubMenu_ItemPosition+1
					end
					spinDisc()
					thmDrawBKGOL()
					for i = 1, howMuchRedrawTransparencyLayer do
						Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
					end
					----------------------------------------------------------------------------
					Graphics.drawImageExtended(themeInUse[-5], 549, 240, 0, 0, 325, 480, 325, 480, 0, 255)
					TempY=8+ContextMenu_SelectedItem*24
					Graphics.drawImageExtended(themeInUse[-4], 549, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
					for ItemToDraw = 1,ContextMenu_AllItems do
						TempY=ItemToDraw*24
						Font.ftPrint(fontSmall, 408, plusYValue+TempY, 0, 400, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
					end
					----------------------------------------------------------------------------
					Graphics.drawRect(352, 240, 704, 480, Color.new(0,0,0,fade*10))
					Screen.waitVblankStart()
					oldpad = pad;
					Screen.flip()
				end
				XEBKeepInContextMenu="none"
				SubMenu_VerifyThenLaunch(ContextMenu[ContextMenu_SelectedItem].File)
			end
			if Pads.check(pad, PAD_UP) and not Pads.check(oldpad, PAD_UP) then
				if ContextMenu_SelectedItem > 1 then
					ContextMenu_SelectedItem=ContextMenu_SelectedItem-1
				end
			end
			if Pads.check(pad, PAD_DOWN) and not Pads.check(oldpad, PAD_DOWN) then
				if ContextMenu_SelectedItem < ContextMenu_AllItems then
					ContextMenu_SelectedItem=ContextMenu_SelectedItem+1
				end
			end
			if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
				XEBKeepInContextMenu="exit"
			end
			Screen.waitVblankStart()
			oldpad = pad;
			Screen.flip()
		end
		if XEBKeepInContextMenu == "exit" then
			for move = 1, 10 do
				pad = Pads.get()
				Screen.clear()
				if backgroundFilter then
					Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
				else
					Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
				end
				thmDrawBKG()
				DrawSubMenu(actualCat,actualOption,true)
				SubMenu_ItemPosition = -5
				for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
					SubMenu_iB_Y = SubMenu_ItemPosition*71
					if SubMenu_iB == SelectedItem then
						SubMenu_DrawItem(152, 206, false, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
					else
						SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
					end
					SubMenu_ItemPosition=SubMenu_ItemPosition+1
				end
				spinDisc()
				thmDrawBKGOL()
				if move == 7 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
				elseif move == 8 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
				elseif move == 9 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
				elseif move == 10 then
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.99))
				else
					SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), 0)
				end
				Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
				moveb=move*25
				movec=move*31
			
				for i = 1, howMuchRedrawTransparencyLayer do
					Graphics.drawImageExtended(themeInUse[-3], 352, 240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255-moveb)
				end
				----------------------------------------------------------------------------
				Graphics.drawImageExtended(themeInUse[-5], 549+movec, 240, 0, 0, 325, 480, 325, 480, 0, 255)
				TempY=8+ContextMenu_SelectedItem*24
				Graphics.drawImageExtended(themeInUse[-4], 549+movec, TempY, 0, 0, 310, 22, 310, 22, 0, 255)
				for ItemToDraw = 1,ContextMenu_AllItems do
					TempY=ItemToDraw*24
					Font.ftPrint(fontSmall, 408+movec, plusYValue+TempY, 0, 400, 64, ContextMenu[ItemToDraw].Name, Color.new(255,255,255,255))
				end
				----------------------------------------------------------------------------
				Screen.waitVblankStart()
				oldpad = pad;
				Screen.flip()
			end
		end
		pad = Pads.get()
		Screen.clear()
		if backgroundFilter then
			Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
		else
			Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
		end
		thmDrawBKG()
		DrawSubMenu(actualCat,actualOption,true)
		SubMenu_ItemPosition = -5
		for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
			SubMenu_iB_Y = SubMenu_ItemPosition*71
			if SubMenu_iB == SelectedItem then
				SubMenu_DrawItem(152, 206, false, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
			else
				SubMenu_DrawItem(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
			end
			SubMenu_ItemPosition=SubMenu_ItemPosition+1
		end
	elseif Pads.check(pad, PAD_UP) then
		if not Pads.check(oldpad, PAD_UP) then
			if SelectedItem ~= 1 then
				SubMenu_HoldingUp=1;
				SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1;
				SubMenu_AnimateUp()
				SelectedItem = SelectedItem - 1
			end
		elseif SubMenu_HoldingUp==17 and Pads.check(oldpad, PAD_UP) then
			if SelectedItem ~= 1 then
				SubMenu_HoldingUp=1;
				SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1;
				SubMenu_AnimateUp()
				SelectedItem = SelectedItem - 1
			end
		elseif SubMenu_HoldingUpDash>1 and Pads.check(oldpad, PAD_UP) then
			if SelectedItem ~= 1 then
				SubMenu_HoldingUp=1;
				SubMenu_HoldingUpDash=SubMenu_HoldingUpDash+1;
				SubMenu_AnimateUp()
				SelectedItem = SelectedItem - 1
			end
		end
		SubMenu_HoldingUp=SubMenu_HoldingUp+1;
	elseif Pads.check(pad, PAD_DOWN) then
		if not Pads.check(oldpad, PAD_DOWN) then
			if SelectedItem ~= ItemTotal then
				SubMenu_HoldingDown=1;
				SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1;
				SubMenu_AnimateDown()
				SelectedItem = SelectedItem + 1
			end
		elseif SubMenu_HoldingDown==17 and Pads.check(oldpad, PAD_DOWN) then
			if SelectedItem ~= ItemTotal then
				SubMenu_HoldingUp=1;
				SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1;
				SubMenu_AnimateDown()
				SelectedItem = SelectedItem + 1
			end
		elseif SubMenu_HoldingDownDash>1 and Pads.check(oldpad, PAD_DOWN) then
			if SelectedItem ~= ItemTotal then
				SubMenu_HoldingDown=1;
				SubMenu_HoldingDownDash=SubMenu_HoldingDownDash+1;
				SubMenu_AnimateDown()
				SelectedItem = SelectedItem + 1
			end
		end
		SubMenu_HoldingDown=SubMenu_HoldingDown+1;
	elseif Pads.check(pad, PAD_LEFT) and not Pads.check(oldpad, PAD_LEFT) then
		XEBSubMenuDoFile=false
		XEBKeepInSubMenu=false
	end
	if not Pads.check(pad, PAD_UP) then
		SubMenu_HoldingUp=99
		SubMenu_HoldingUpDash=0
	end
	if not Pads.check(pad, PAD_DOWN) then
		SubMenu_HoldingDown=99
		SubMenu_HoldingDownDash=0
	end
	if Pads.check(pad, PAD_CANCEL) and not Pads.check(oldpad, PAD_CANCEL) then
		XEBSubMenuDoFile=false
		XEBKeepInSubMenu=false
	end
	spinDisc()
	thmDrawBKGOL()
	Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
end

for SubMenu_i = 1, 3 do
	pad = Pads.get()
	Screen.clear()
	if backgroundFilter then
		Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
	else
		Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
	end
	thmDrawBKG()
	DrawSubMenu(actualCat,actualOption,true)
	SubMenu_ReverseFrame=4-SubMenu_i
	SubMenu_ItemPosition = -5
	for SubMenu_iB = SelectedItem-6, SelectedItem+5 do
		SubMenu_iB_Y = SubMenu_ItemPosition*71
		if SubMenu_iB == SelectedItem then
			SubMenu_DrawItemFrame(152, 206, false, Item[SubMenu_iB].Name, SubMenu_ReverseFrame, baseColorFull, SubMenu_ColorFullZero, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
		else
			SubMenu_DrawItemFrame(152, SubMenu_iB_Y+135, true, Item[SubMenu_iB].Name, SubMenu_ReverseFrame, baseColorFaded, SubMenu_ColorFadedZero, Item[SubMenu_iB].Icon, Item[SubMenu_iB].Description)
		end
		SubMenu_ItemPosition=SubMenu_ItemPosition+1
	end
	spinDisc()
	thmDrawBKGOL()
	if Item[SelectedItem].Type == "MultiELF" then
		if SubMenu_i == 1 then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.75))
		elseif SubMenu_i == 2 then
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.5))
		else
			SubMenu_infoColor = Color.new(Color.getR(infoColor), Color.getG(infoColor), Color.getB(infoColor), XEBMathRound(Color.getA(infoColor)*0.25))
		end
	end
	Font.ftPrint(fontSmall, 352, plusYValue+453, 11, 512, 64, xebLang[57], SubMenu_infoColor)
	Screen.waitVblankStart()
	oldpad = pad;
	Screen.flip()
end

BackFromSubMenuIcon(actualCat,actualOption,true)
pad = Pads.get()
Screen.clear()
if backgroundFilter then
	Graphics.drawImageExtended(themeInUse[-1], 352, plusYValue+240, 0, 0, backgroundValueX, backgroundValueY, 704, 480, 0, 255)
else
	Graphics.drawImage(themeInUse[-1], 0, plusYValue+0)
end
thmDrawBKG()
DrawInterface(actualCat,actualOption,true)
spinDisc()
thmDrawBKGOL()
oldpad = pad;

if XEBSubMenuDoFile then
	VerifyThenLaunchLua(XEBSubMenuDoFileB, XEBSubMenuDoFileB, XEBSubMenuDoFileB)
end